package com.allinone.emulator.ui

import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.NetplayStatus
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.zip.CRC32

/**
 * Multiplayer online/LAN dengan rollback (gaya GGPO), 2 pemain.
 * Host = pemain 1, tamu = pemain 2. Kedua HP harus memakai ROM + core yang sama.
 */
class NetplayUi(
    private val act: Activity,
    private val retro: GLRetroView,
    private val rom: File,
    private val coreId: String,
    private val root: FrameLayout
) {
    private val main = Handler(Looper.getMainLooper())
    private var polling = false
    private var lastState = NetplayStatus.State.OFF

    private val overlay = TextView(act).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        textSize = 11f
        setPadding(14, 6, 14, 6)
        visibility = android.view.View.GONE
    }

    /** True selama game dikendalikan sesi netplay: simpan/muat state, reset, cheat, fast forward dimatikan. */
    val active: Boolean
        get() = lastState == NetplayStatus.State.SYNCING || lastState == NetplayStatus.State.RUNNING

    /** True bila ada sesi (menunggu / menyambung / jalan). */
    val inSession: Boolean get() = lastState != NetplayStatus.State.OFF && lastState != NetplayStatus.State.ENDED

    fun showMenu(show: (AlertDialog.Builder) -> Unit) {
        val items = if (inSession || lastState == NetplayStatus.State.ENDED)
            arrayOf("Hentikan multiplayer")
        else arrayOf("Host (jadi pemain 1)", "Gabung (jadi pemain 2)")
        show(AlertDialog.Builder(act).setTitle("Multiplayer rollback").setItems(items) { _, i ->
            if (inSession || lastState == NetplayStatus.State.ENDED) stop()
            else if (i == 0) hostDialog(show) else joinDialog(show)
        })
    }

    private fun hostDialog(show: (AlertDialog.Builder) -> Unit) {
        val ips = localIps()
        val delays = listOf(1, 2, 3, 4)
        val labels = delays.map { d ->
            when (d) {
                1 -> "1 frame (paling responsif, koneksi harus bagus)"
                2 -> "2 frame (bawaan, cocok untuk Wi-Fi/LAN)"
                3 -> "3 frame (internet cukup stabil)"
                else -> "4 frame (koneksi kurang stabil)"
            }
        }
        show(AlertDialog.Builder(act)
            // JANGAN pakai setMessage bersama setItems: Android menyembunyikan daftar pilihannya.
            .setTitle("Host: IP ${if (ips.isEmpty()) "(tidak terdeteksi)" else ips.joinToString(", ")} port $PORT\n" +
                (if (hasMesh()) "IP paling atas = VPN mesh (bisa dari data seluler/jarak jauh)\n" else "Beda jaringan? Aktifkan Tailscale di kedua HP\n") +
                "Pilih input delay (dipakai kedua pemain):")
            .setItems(labels.toTypedArray()) { _, i ->
                gameHash { hash ->
                    val ok = retro.netplayHost(PORT, hash, delays[i])
                    afterStart(ok)
                }
            }
            .setNegativeButton("Batal", null))
    }

    private fun joinDialog(show: (AlertDialog.Builder) -> Unit) {
        val et = EditText(act).apply {
            hint = "IP host: 192.168.x.x (Wi-Fi sama) / 100.x.x.x (Tailscale)"
            setSingleLine(true)
            setText(lastIp)
        }
        val box = FrameLayout(act).apply {
            val m = (20 * act.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        show(AlertDialog.Builder(act)
            .setTitle("Gabung ke host")
            .setMessage("Masukkan IP host (port $PORT dipakai otomatis; bisa juga ditulis ip:port). Beda jaringan/jarak jauh: pakai IP Tailscale host, dan Tailscale harus aktif di HP ini.")
            .setView(box)
            .setPositiveButton("Gabung") { _, _ ->
                val txt = et.text.toString().trim()
                if (txt.isEmpty()) return@setPositiveButton
                lastIp = txt
                val ip = txt.substringBefore(':')
                val port = txt.substringAfter(':', "").toIntOrNull() ?: PORT
                gameHash { hash -> afterStart(retro.netplayJoin(ip, port, hash, 2)) }
            }
            .setNegativeButton("Batal", null))
    }

    /** Sidik jari game: CRC32 ROM digabung nama core. Harus sama di kedua HP. */
    private fun gameHash(onReady: (Int) -> Unit) {
        Toast.makeText(act, "Menyiapkan multiplayer…", Toast.LENGTH_SHORT).show()
        Thread {
            val crc = CRC32()
            try {
                rom.inputStream().use { s ->
                    val buf = ByteArray(64 * 1024)
                    while (true) { val n = s.read(buf); if (n <= 0) break; crc.update(buf, 0, n) }
                }
            } catch (_: Exception) {}
            val coreName = File(coreId).name.substringAfterLast('/')
            val h = (crc.value.toInt()) xor coreName.hashCode()
            main.post { onReady(h) }
        }.start()
    }

    private fun afterStart(ok: Boolean) {
        if (!ok) {
            val e = retro.netplayStatus().error
            Toast.makeText(act, errorText(e), Toast.LENGTH_LONG).show()
            retro.netplayStop()
            return
        }
        if (overlay.parent == null) {
            root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }
        startPolling()
    }

    fun stop() {
        polling = false
        try { retro.netplayStop() } catch (_: Exception) {}
        lastState = NetplayStatus.State.OFF
        overlay.visibility = android.view.View.GONE
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        main.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val st = try { retro.netplayStatus() } catch (_: Exception) { null }
                if (st != null) render(st)
                if (polling) main.postDelayed(this, 500)
            }
        })
    }

    private fun render(st: NetplayStatus) {
        val prev = lastState
        lastState = st.state
        overlay.visibility = android.view.View.VISIBLE
        overlay.text = when (st.state) {
            NetplayStatus.State.HOST_WAITING ->
                "Menunggu pemain 2… IP: ${localIps().joinToString(", ")}:$PORT"
            NetplayStatus.State.CLIENT_CONNECTING -> "Menyambung ke host…"
            NetplayStatus.State.SYNCING -> "Sinkronisasi game…"
            NetplayStatus.State.RUNNING ->
                "P${st.localPlayer + 1} · ping ${st.pingMs} ms · rollback ${st.lastRollbackFrames}f" +
                    if (st.desync) " · DESYNC!" else ""
            else -> ""
        }
        if (st.state == NetplayStatus.State.ENDED && prev != NetplayStatus.State.ENDED) {
            Toast.makeText(act, errorText(st.error) + "\nGame dilanjutkan sendiri.", Toast.LENGTH_LONG).show()
            stop()
        }
    }

    private fun errorText(e: NetplayStatus.Error) = when (e) {
        NetplayStatus.Error.GAME_MISMATCH -> "Game/core berbeda: kedua HP harus memakai ROM dan core yang sama."
        NetplayStatus.Error.CONNECT -> "Tidak bisa tersambung ke host (cek IP, port $PORT, dan jaringan; beda jaringan butuh VPN mesh aktif di kedua HP)."
        NetplayStatus.Error.TIMEOUT -> "Koneksi terputus (tidak ada balasan)."
        NetplayStatus.Error.VERSION -> "Versi multiplayer berbeda."
        NetplayStatus.Error.STATE_TOO_BIG -> "Core ini tidak cocok untuk rollback (state terlalu besar)."
        NetplayStatus.Error.SOCKET -> "Port $PORT tidak bisa dibuka (sedang dipakai?)."
        NetplayStatus.Error.PEER_LEFT -> "Lawan keluar dari multiplayer."
        NetplayStatus.Error.NONE -> "Multiplayer berhenti."
    }

    /** IP Tailscale (100.64.0.0/10) atau antarmuka tun*, yaitu VPN mesh. */
    private fun isMesh(name: String, ip: String): Boolean {
        val p = ip.split('.').mapNotNull { it.toIntOrNull() }
        val tailscale = p.size == 4 && p[0] == 100 && p[1] in 64..127
        return tailscale || name.startsWith("tun")
    }

    private fun allIps(): List<Pair<String, Boolean>> = try {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp }.flatMap { ni ->
            ni.inetAddresses.toList()
                .filter { it is Inet4Address && !it.isLoopbackAddress }
                .mapNotNull { a -> a.hostAddress?.takeIf { it.isNotEmpty() }?.let { it to isMesh(ni.name, it) } }
        }
    } catch (_: Exception) { emptyList() }

    /** IP VPN mesh lebih dulu supaya yang tampil pertama adalah yang bisa dipakai lintas jaringan. */
    private fun localIps(): List<String> = allIps().sortedByDescending { it.second }.map { it.first }

    private fun hasMesh(): Boolean = allIps().any { it.second }

    companion object {
        const val PORT = 7755
        private var lastIp = ""
    }
}
