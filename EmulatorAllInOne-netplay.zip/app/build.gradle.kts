plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.allinone.emulator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.allinone.emulator"
        minSdk = 21            // Android 5.0
        targetSdk = 34
        versionCode = 17
        versionName = "1.2"
    }

    // APK dipisah per ABI (x86 dibuang): satu APK berisi semua core x 4 ABI terlalu besar dan gagal ditulis.
    // Pakai APK arm64-v8a untuk HP modern, armeabi-v7a untuk HP 32-bit.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = false
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Core libretro dimuat lewat path, jadi .so harus diekstrak ke nativeLibraryDir
    packaging { jniLibs { useLegacyPackaging = true } }
}

// Cek versi terbaru di https://jitpack.io/#Swordfish90/LibretroDroid
val libretroDroidVersion = "0.13.0"

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Baca arsip .7z dan .rar (Java murni; .zip sudah bawaan Java)
    implementation("org.apache.commons:commons-compress:1.21")
    implementation("org.tukaani:xz:1.9")
    implementation("com.github.junrar:junrar:7.5.5")
    implementation(project(":libretrodroid"))   // LibretroDroid 0.13.2 + netplay rollback (lihat scripts/setup_libretrodroid_netplay.sh)

    // Terjemahan dialog: OCR + penerjemah on-device (ML Kit). Cek versi terbaru bila gagal resolve.
    implementation("com.google.mlkit:text-recognition:16.0.1")            // Latin
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")
}
