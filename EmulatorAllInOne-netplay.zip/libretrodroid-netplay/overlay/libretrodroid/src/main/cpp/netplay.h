/*
 * Rollback netplay (gaya GGPO) untuk LibretroDroid. 2 pemain, IPv4.
 *
 * Alur singkat:
 *  - TCP: handshake (cek game/core sama) + kirim save state awal host -> client.
 *  - UDP: tukar input tiap frame (redundan, tahan packet hilang).
 *  - Tiap frame: simpan state, jalankan frame dengan input lawan PREDIKSI (ulang input terakhir),
 *    bila input asli lawan datang dan beda -> load state lama dan simulasi ulang (tanpa gambar/suara).
 */
#ifndef LIBRETRODROID_NETPLAY_H
#define LIBRETRODROID_NETPLAY_H

#include <atomic>
#include <cstdint>
#include <deque>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <netinet/in.h>

namespace libretrodroid {

class Netplay {
public:
    enum Status {
        OFF = 0,
        HOST_WAITING = 1,
        CLIENT_CONNECTING = 2,
        SYNCING = 3,
        RUNNING = 4,
        ENDED = 5
    };

    enum Error {
        ERR_NONE = 0,
        ERR_GAME_MISMATCH = 1,
        ERR_CONNECT = 2,
        ERR_TIMEOUT = 3,
        ERR_VERSION = 4,
        ERR_STATE_TOO_BIG = 5,
        ERR_SOCKET = 6,
        ERR_PEER_LEFT = 7
    };

    struct CoreHooks {
        std::function<size_t()> stateSize;
        std::function<bool(void *, size_t)> save;
        std::function<bool(const void *, size_t)> load;
        // Jalankan SATU frame core. visible=false: jangan keluarkan gambar/suara (simulasi ulang).
        std::function<void(bool visible)> run;
    };

    static constexpr int RING = 16;          // jumlah state yang disimpan
    static constexpr int MAX_PREDICTION = 8; // maks frame yang boleh ditebak
    static constexpr int WINDOW = 64;        // ring input per frame (harus pangkat 2)
    static constexpr size_t MAX_STATE_BYTES = 8 * 1024 * 1024;

    // Hanya untuk pengujian: simulasi lag & packet loss pada pengiriman UDP.
    int debugLossPercent = 0;
    int debugLatencyMs = 0;

    Netplay(CoreHooks hooks, uint16_t port, uint32_t gameHash, int inputDelay);
    ~Netplay();

    // Harus dipanggil dari thread emulasi (memanggil hooks.stateSize).
    bool startHost();
    bool startJoin(const std::string &hostIp);
    void stop();

    // True selama core hanya boleh digerakkan oleh tick() (SYNCING/RUNNING).
    bool controlsCore() const;

    // Dipanggil dari thread emulasi sekali per frame. Mengembalikan true bila satu frame
    // tampil dijalankan (false = sedang menunggu / stall).
    bool tick(uint16_t localMask);

    // Input yang dilihat core saat retro_run (device JOYPAD saja).
    int16_t coreInput(unsigned port, unsigned id) const;

    int status() const { return status_.load(); }
    int error() const { return error_.load(); }
    int pingMs() const { return pingMs_.load(); }
    int lastRollbackFrames() const { return lastRollback_.load(); }
    bool desync() const { return desync_.load(); }
    int localPlayer() const { return localPlayer_; } // 0 host, 1 client
    int currentFrame() const { return cur_; }
    int verifiedFrame() const { return verified_; }

private:
    struct Slot {
        int32_t frame = -1;
        uint16_t value = 0;
    };

    // --- jaringan ---
    bool openUdp(bool bindPort);
    void netThreadHost();
    void netThreadClient(std::string ip);
    void monitorTcp();
    void fail(int err);
    void sendInputPacket();
    void pumpOutgoing();
    void rawSend(const std::vector<uint8_t> &pkt);
    void receivePackets();
    void handlePacket(const uint8_t *p, size_t n, const sockaddr_in &from);

    // --- rollback ---
    void beginRunning();
    void resimulateFrom(int frame);
    uint16_t remoteFor(int frame) const;
    bool remoteKnown(int frame, uint16_t &v) const;
    void applyInputs(int frame);
    void maybeChecksum();

    static uint32_t nowMs();

    CoreHooks hooks_;
    uint16_t port_;
    uint32_t gameHash_;
    int delay_;
    size_t stateBytes_ = 0;
    int localPlayer_ = 0;

    std::atomic<int> status_{OFF};
    std::atomic<int> error_{ERR_NONE};
    std::atomic<int> pingMs_{0};
    std::atomic<int> lastRollback_{0};
    std::atomic<bool> desync_{false};
    std::atomic<bool> stopFlag_{false};

    // socket
    int udp_ = -1;
    int tcp_ = -1;
    int listen_ = -1;
    sockaddr_in peer_{};
    std::atomic<bool> peerKnown_{false};
    uint32_t session_ = 0;
    std::thread netThread_;

    // sinkronisasi thread jaringan <-> thread emulasi
    std::mutex mu_;
    std::vector<uint8_t> blob_;
    std::atomic<bool> needSnapshot_{false};
    std::atomic<bool> snapshotReady_{false};
    std::atomic<bool> blobReady_{false};
    std::atomic<bool> loaded_{false};
    std::atomic<bool> startFlag_{false};

    // state rollback (thread emulasi)
    int cur_ = 0;       // frame berikutnya yang akan dijalankan
    int verified_ = -1; // semua frame <= ini sudah dijalankan dengan input asli
    int remoteConfirmed_ = -1;
    int peerAck_ = -1;  // frame input lokal tertinggi yang sudah diterima lawan
    int peerFrame_ = 0;
    int peerAdv_ = 0;
    int stallCooldown_ = 0;
    uint32_t lastRecvMs_ = 0;
    uint32_t lastPeerSendMs_ = 0;
    uint32_t lastSendMs_ = 0;
    Slot local_[WINDOW];
    Slot remote_[WINDOW];
    Slot used_[WINDOW];
    int stateFrame_[RING];
    std::vector<std::vector<uint8_t>> states_;
    uint16_t inputs_[2] = {0, 0};

    // checksum
    int32_t checkFrame_ = -1;
    uint32_t checkHash_ = 0;
    int32_t myHashFrame_[8];
    uint32_t myHash_[8];
    int lastCheckedFrame_ = -60;

    struct Delayed {
        uint32_t due;
        std::vector<uint8_t> data;
    };
    std::deque<Delayed> delayed_;
};

} // namespace libretrodroid

#endif // LIBRETRODROID_NETPLAY_H
