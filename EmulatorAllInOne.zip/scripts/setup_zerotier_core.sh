#!/usr/bin/env bash
# OPSIONAL: menyiapkan mesin ZeroTier (core + pembungkus JNI) supaya VPN ZeroTier bisa berjalan DI DALAM aplikasi ini.
# Hasil: app/src/main/jniLibs/<abi>/libZeroTierOneJNI.so  dan  app/zt-sdk/java/com/zerotier/sdk/*.java
# Bila skrip ini gagal, build tetap lanjut TANPA ZeroTier tertanam (workflow memakai continue-on-error).
# Lisensi: ZeroTier memakai BSL 1.1 (gratis untuk non-komersial). Baca LICENSE.txt di repositori ZeroTierOne sebelum merilis.
# Env: ZT_TAGS="1.14.2 1.14.0 1.12.2" (tag dicoba berurutan)  ABIS="arm64-v8a armeabi-v7a"
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
TAGS="${ZT_TAGS:-1.14.2 1.14.0 1.12.2}"
ABIS="${ABIS:-arm64-v8a armeabi-v7a}"
SRC="$ROOT/zerotier-src"
OUT="$ROOT/app/src/main/jniLibs"
SDK="$ROOT/app/zt-sdk/java"

rm -rf "$SRC" "$SDK"
for TAG in $TAGS; do
  if git clone --depth 1 --branch "$TAG" https://github.com/zerotier/ZeroTierOne.git "$SRC"; then echo "ZeroTierOne tag $TAG"; break; fi
done
[ -d "$SRC/java" ] || { echo "Gagal mengunduh ZeroTierOne (tag: $TAGS)"; exit 1; }

# Ringkasan API Java (untuk mencocokkan ZtCore.kt bila tanda tangan metode berbeda antarversi)
mkdir -p "$ROOT/zerotier-api"
grep -rhE "^\s*(public|interface|enum|class)" "$SRC/java/src/com/zerotier/sdk" > "$ROOT/zerotier-api/api.txt" || true
echo "== struktur java/ ==" | tee "$ROOT/zerotier-api/layout.txt"
(cd "$SRC/java" && find . -maxdepth 3 -not -path './.git*' | sort) | tee -a "$ROOT/zerotier-api/layout.txt"

NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [ -z "$NDK" ] && [ -n "${ANDROID_HOME:-}" ]; then NDK="$(ls -d "$ANDROID_HOME"/ndk/* 2>/dev/null | sort -V | tail -n1 || true)"; fi
[ -x "$NDK/ndk-build" ] || { echo "ndk-build tidak ditemukan (NDK=$NDK)"; exit 1; }

MK="$SRC/java/jni/Android.mk"
[ -f "$MK" ] || { echo "java/jni/Android.mk tidak ada di versi ini; lihat zerotier-api/layout.txt"; exit 1; }
APPMK=()
[ -f "$SRC/java/jni/Application.mk" ] && APPMK=(NDK_APPLICATION_MK="$SRC/java/jni/Application.mk")

"$NDK/ndk-build" -j"$(nproc)" \
  NDK_PROJECT_PATH="$SRC/java" APP_BUILD_SCRIPT="$MK" "${APPMK[@]}" \
  APP_ABI="$ABIS" APP_PLATFORM=android-21 \
  NDK_OUT="$SRC/obj" NDK_LIBS_OUT="$SRC/libs"

for abi in $ABIS; do
  so="$(find "$SRC/libs/$abi" -name 'libZeroTierOneJNI.so' | head -n1 || true)"
  [ -n "$so" ] || { echo "libZeroTierOneJNI.so tidak dihasilkan untuk $abi"; ls -R "$SRC/libs" || true; exit 1; }
  mkdir -p "$OUT/$abi" && cp "$so" "$OUT/$abi/"
done

mkdir -p "$SDK/com/zerotier" && cp -r "$SRC/java/src/com/zerotier/sdk" "$SDK/com/zerotier/"

echo "ZeroTier core siap: $(ls "$OUT"/*/libZeroTierOneJNI.so | tr '\n' ' ')"
