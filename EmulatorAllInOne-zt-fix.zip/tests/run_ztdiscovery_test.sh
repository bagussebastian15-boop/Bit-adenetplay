#!/usr/bin/env bash
# Uji penemuan server lewat siaran ZeroTier (paket pengumuman, daftar server), tanpa Android.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
if command -v javac >/dev/null 2>&1; then JAVAC=(javac); else JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
"${JAVAC[@]}" -d "$OUT" app/src/main/java/com/allinone/emulator/net/EthBridge.java app/src/main/java/com/allinone/emulator/net/ZtDiscovery.java tests/java/com/allinone/emulator/net/ZtDiscoveryTest.java
java -cp "$OUT" com.allinone.emulator.net.ZtDiscoveryTest
