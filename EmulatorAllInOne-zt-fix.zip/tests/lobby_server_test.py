#!/usr/bin/env python3
"""Uji server lobby: penandaan jaringan (ZeroTier/Tailscale/LAN/internet) + alur daftar/heartbeat/tutup lewat HTTP."""
import ipaddress
import json
import os
import sys
import threading
import urllib.request
import urllib.error

os.environ["PROBE"] = "0"
os.environ["ZEROTIER_NETS"] = "10.147.17.0/24,192.168.191.0/24"
os.environ["OFFICIAL_FILE"] = os.path.join(os.path.dirname(__file__), "_official_test.json")
os.environ["NETWORKS_FILE"] = os.path.join(os.path.dirname(__file__), "_networks_test.json")
os.environ["REQUESTS_FILE"] = os.path.join(os.path.dirname(__file__), "_requests_test.json")
os.environ["ADMIN_KEY"] = "kunci-uji"
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "server"))

with open(os.environ["OFFICIAL_FILE"], "w") as f:
    json.dump([
        {"name": "ZT resmi", "host": "10.147.17.5", "port": 7755, "title": "Game", "console": "SNES"},
        {"name": "Tanda manual", "host": "172.16.0.9", "port": 7755, "title": "Game", "console": "GBA", "zerotier": True},
        {"name": "Tailscale", "host": "100.100.1.1", "port": 7755, "title": "Game", "console": "GENESIS"},
    ], f)

with open(os.environ["NETWORKS_FILE"], "w", encoding="utf-8") as f:
    json.dump([{"id": "8d1c312afa20d47e", "name": "Bit©ade"}, {"id": "bukan-id", "name": "buruk"}], f, ensure_ascii=False)

import lobby_server as L  # noqa: E402

A = ipaddress.ip_address
fails = 0


def check(name, got, want):
    global fails
    ok = got == want
    fails += not ok
    print(("ok   " if ok else "GAGAL"), name, "" if ok else "-> %r (harusnya %r)" % (got, want))


check("zerotier by range", L.net_kind(A("10.147.17.8")), "zerotier")
check("zerotier 192.168.191", L.net_kind(A("192.168.191.4")), "zerotier")
check("tailscale", L.net_kind(A("100.101.5.5")), "tailscale")
check("lan", L.net_kind(A("192.168.1.20")), "lan")
check("internet", L.net_kind(A("8.8.8.8")), "internet")
check("hint zerotier di luar rentang", L.net_kind(A("172.16.0.9"), "zerotier"), "zerotier")
check("hint diabaikan utk IP publik", L.net_kind(A("8.8.8.8"), "zerotier"), "internet")

srv = L.ThreadingHTTPServer(("127.0.0.1", 0), L.H)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
base = "http://127.0.0.1:%d" % port


def call(method, path, body=None, key=None):
    hdr = {"Content-Type": "application/json"}
    if key:
        hdr["X-Admin-Key"] = key
    req = urllib.request.Request(base + path, method=method,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers=hdr)
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


st, r = call("POST", "/api/rooms", {"console": "SNES", "title": "Mario", "ip": "10.147.17.9", "owner": "A"})
check("daftar ZeroTier ok", st, 200)
tok = r["token"]
st, r = call("POST", "/api/rooms", {"console": "SNES", "title": "Mario2", "ip": "172.16.0.9", "vpn": "zerotier"})
check("daftar dengan hint ok", st, 200)
st, r = call("POST", "/api/rooms", {"console": "SNES", "title": "X", "ip": "8.8.8.8"})
check("IP publik manual ditolak", st, 400)

st, r = call("GET", "/api/rooms")
nets = sorted(x["net"] for x in r["rooms"])
check("rooms net", nets, ["zerotier", "zerotier"])
check("official net", [x["net"] for x in r["official"]], ["zerotier", "zerotier", "tailscale"])

st, _ = call("POST", "/api/rooms/heartbeat", {"token": tok, "players": 2})
check("heartbeat", st, 200)
st, _ = call("POST", "/api/rooms/close", {"token": tok})
check("tutup", st, 200)
st, r = call("GET", "/api/rooms")
check("sisa 1 room", len(r["rooms"]), 1)

# ---- jaringan ZeroTier + persetujuan
st, r = call("GET", "/api/rooms")
check("daftar jaringan (id tak valid disaring)", [n["name"] for n in r["networks"]], ["Bit©ade"])
NID, NODE = "8d1c312afa20d47e", "cd3c5e3a69"
st, r = call("POST", "/api/networks/request", {"network": "ffffffffffffffff", "node": NODE})
check("jaringan tak dikenal ditolak", st, 400)
st, r = call("POST", "/api/networks/request", {"network": NID, "node": "xyz"})
check("node id salah ditolak", st, 400)
st, r = call("POST", "/api/networks/request", {"network": NID, "node": NODE.upper(), "owner": "Budi"})
check("minta akses", (st, r["status"]), (200, "pending"))
st, r = call("POST", "/api/networks/status", {"network": NID, "node": NODE})
check("status pending", r["status"], "pending")
st, r = call("GET", "/api/admin/requests")
check("admin tanpa kunci ditolak", st, 403)
st, r = call("GET", "/api/admin/requests", key="salah")
check("admin kunci salah ditolak", st, 403)
st, r = call("GET", "/api/admin/requests", key="kunci-uji")
check("admin lihat antrean", (st, [p["node"] for p in r["pending"]], "from" in r["pending"][0]), (200, [NODE], False))
st, r = call("POST", "/api/admin/decide", {"network": NID, "node": NODE, "approve": True})
check("decide tanpa kunci ditolak", st, 403)
st, r = call("POST", "/api/admin/decide", {"network": NID, "node": NODE, "approve": True}, key="kunci-uji")
check("setujui", (st, r["status"]), (200, "approved"))
st, r = call("POST", "/api/networks/status", {"network": NID, "node": NODE})
check("status approved", r["status"], "approved")
st, r = call("GET", "/api/admin/requests", key="kunci-uji")
check("antrean kosong", r["pending"], [])

for k in ("OFFICIAL_FILE", "NETWORKS_FILE", "REQUESTS_FILE"):
    try:
        os.remove(os.environ[k])
    except OSError:
        pass
print("SEMUA LULUS" if not fails else "%d GAGAL" % fails)
sys.exit(1 if fails else 0)
