package com.allinone.emulator.net;

import java.util.List;

/** Uji penemuan server lewat siaran: host mengumumkan, pemain lain menerima, tanpa Android dan tanpa ZeroTier. */
public class ZtDiscoveryTest {
    static int fails = 0;

    static void check(String name, Object got, Object want) {
        boolean ok = got == null ? want == null : got.equals(want);
        if (!ok) fails++;
        System.out.println((ok ? "ok    " : "GAGAL ") + name + (ok ? "" : " -> " + got + " (harusnya " + want + ")"));
    }

    static int ip(String s) { return EthBridge.parseIp(s); }

    public static void main(String[] args) {
        int host = ip("10.102.103.211"), me = ip("10.102.103.50");

        check("belum mengumumkan -> tidak ada paket", ZtDiscovery.buildPacket(host, 24), null);
        ZtDiscovery.announce("Bagus - Mortal Kombat", "Mortal Kombat", "ARCADE_MAME", "Bagus", 7755, 2);
        byte[] pkt = ZtDiscovery.buildPacket(host, 24);
        check("paket dibuat", pkt != null, true);
        check("tujuan = siaran subnet /24", ZtDiscovery.ipStr(EthBridge.ipToInt(pkt, 16)), "10.102.103.255");
        check("tujuan = siaran subnet /16", ZtDiscovery.ipStr(EthBridge.ipToInt(ZtDiscovery.buildPacket(host, 16), 16)), "10.102.255.255");
        check("prefix /32 -> 255.255.255.255", ZtDiscovery.ipStr(EthBridge.ipToInt(ZtDiscovery.buildPacket(host, 32), 16)), "255.255.255.255");
        check("sumber = IP host", ZtDiscovery.ipStr(EthBridge.ipToInt(pkt, 12)), "10.102.103.211");
        check("protokol UDP", pkt[9] & 0xff, 17);

        // checksum header IPv4 harus valid: jumlah seluruh word (termasuk checksum) = 0xffff
        int sum = 0;
        for (int i = 0; i < 20; i += 2) sum += ((pkt[i] & 0xff) << 8) | (pkt[i + 1] & 0xff);
        while ((sum >>> 16) != 0) sum = (sum & 0xffff) + (sum >>> 16);
        check("checksum header IPv4 valid", sum, 0xffff);

        long t = 1_000_000;
        check("paket sendiri diabaikan tapi dihabiskan", ZtDiscovery.handle(pkt, host, t), true);
        check("tidak masuk daftar sendiri", ZtDiscovery.servers(t).size(), 0);

        check("pemain lain menerima", ZtDiscovery.handle(pkt, me, t), true);
        List<ZtDiscovery.Server> l = ZtDiscovery.servers(t);
        check("satu server terdaftar", l.size(), 1);
        ZtDiscovery.Server s = l.get(0);
        check("alamat host", s.host + ":" + s.port, "10.102.103.211:7755");
        check("nama/judul/konsol/pemilik", s.name + "|" + s.title + "|" + s.console + "|" + s.owner,
            "Bagus - Mortal Kombat|Mortal Kombat|ARCADE_MAME|Bagus");
        check("pemain 1/2", s.players + "/" + s.max, "1/2");

        ZtDiscovery.setPlayers(2);
        ZtDiscovery.handle(ZtDiscovery.buildPacket(host, 24), me, t + 3000);
        check("pembaruan, bukan duplikat", ZtDiscovery.servers(t + 3000).size() + " " + ZtDiscovery.servers(t + 3000).get(0).players, "1 2");

        check("masih ada sebelum kedaluwarsa", ZtDiscovery.servers(t + 3000 + ZtDiscovery.TTL_MS).size(), 1);
        check("hilang setelah kedaluwarsa", ZtDiscovery.servers(t + 3001 + ZtDiscovery.TTL_MS).size(), 0);

        // paket bukan milik kita
        byte[] other = ZtDiscovery.buildPacket(host, 24).clone();
        other[22] = 0x1E; other[23] = 0x4B;                         // port tujuan lain
        check("port lain tidak dihabiskan", ZtDiscovery.handle(other, me, t), false);
        check("frame pendek tidak dihabiskan", ZtDiscovery.handle(new byte[10], me, t), false);
        check("null tidak dihabiskan", ZtDiscovery.handle(null, me, t), false);

        // paket rusak / isi aneh tidak boleh membuat server palsu atau melempar galat
        byte[] junk = ZtDiscovery.udpPacket(ip("10.102.103.9"), -1, 7756, 7756, "AIOSRV1\nport=99999\ntitle=x\nconsole=y\n".getBytes());
        check("port tidak sah ditolak", ZtDiscovery.handle(junk, me, t) + " " + ZtDiscovery.servers(t).size(), "true 0");
        byte[] nomagic = ZtDiscovery.udpPacket(ip("10.102.103.9"), -1, 7756, 7756, "hello".getBytes());
        check("tanpa tanda pengenal tidak dihabiskan", ZtDiscovery.handle(nomagic, me, t), false);

        // banjir: maksimal 64 server
        for (int i = 1; i <= 100; i++) {
            ZtDiscovery.stopAnnounce();
            ZtDiscovery.announce("S" + i, "Game", "SNES", "x", 7755, 2);
            ZtDiscovery.handle(ZtDiscovery.buildPacket(ip("10.102.103." + (i + 100)), 24), me, t);
        }
        check("dibatasi 64 server", ZtDiscovery.servers(t).size(), 64);

        ZtDiscovery.stopAnnounce();
        check("berhenti mengumumkan", ZtDiscovery.isAnnouncing(), false);

        System.out.println(fails == 0 ? "SEMUA LULUS" : fails + " GAGAL");
        if (fails != 0) System.exit(1);
    }
}
