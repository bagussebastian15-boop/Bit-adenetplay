package com.zerotier.sdk;
import java.net.InetSocketAddress;
import java.util.ArrayList;
public class VirtualNetworkConfig {
    public long mac; public String name; public VirtualNetworkStatus status; public int mtu; public ArrayList<InetSocketAddress> addrs = new ArrayList<>();
    public long getMac() { return mac; }
    public String getName() { return name; }
    public VirtualNetworkStatus getStatus() { return status; }
    public int getMtu() { return mtu; }
    public ArrayList<InetSocketAddress> getAssignedAddresses() { return addrs; }
}
