package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.max

/**
 * Latar bergambar (neon arcade Bit©ade) untuk game arcade (MAME / dingdong).
 *
 * Cara kerjanya sama dengan [GameBackgroundView]: dipasang DI ATAS layar game, tetapi bagian tempat gambar game
 * berada dibiarkan kosong, jadi game tampil normal (ukuran tidak diubah) dan gambar hanya mengisi area di luarnya.
 * Gambar (landscape 16:9, logo Bit©ade di kiri atas, bingkai neon di tengah) diskalakan menutupi seluruh layar.
 * Bila layar lebih lebar dari 16:9, bagian yang terpotong lebih banyak diambil dari bawah supaya logo tetap terlihat.
 */
class ArcadeBackgroundView(
    ctx: Context,
    private val game: View,
    bgRes: Int,
    private val aspect: Float = 4f / 3f,
    private val vAnchor: Float = 0.15f   // bagian potongan vertikal yang diambil dari atas (0 = potong bawah saja)
) : View(ctx) {
    private val bmp: Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, bgRes)
    } catch (_: Throwable) { null }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint().apply { color = Color.rgb(3, 3, 30) }
    private val hole = RectF()
    private val dst = RectF()
    private val parts = Array(4) { RectF() }

    init {
        game.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> invalidate() }
    }

    private fun gameRect(out: RectF) {
        if (game.width <= 0 || game.height <= 0) { out.setEmpty(); return }
        val sx = game.scaleX; val sy = game.scaleY
        var bw = game.width * sx
        var bh = game.height * sy
        val cx = game.left + game.width / 2f + game.translationX
        val cy = game.top + game.height / 2f + game.translationY
        if (sx == 1f && sy == 1f) {
            if (bw / bh > aspect) bw = bh * aspect else bh = bw / aspect
        }
        out.set(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        gameRect(hole)
        hole.intersect(0f, 0f, w, h)
        if (hole.isEmpty) hole.set(w / 2f, h / 2f, w / 2f, h / 2f)

        parts[0].set(0f, 0f, w, hole.top)
        parts[1].set(0f, hole.bottom, w, h)
        parts[2].set(0f, hole.top, hole.left, hole.bottom)
        parts[3].set(hole.right, hole.top, w, hole.bottom)

        val b = bmp
        if (b != null) {
            val s = max(w / b.width, h / b.height)
            val dw = b.width * s; val dh = b.height * s
            val top = -(dh - h) * vAnchor
            dst.set((w - dw) / 2f, top, (w + dw) / 2f, top + dh)
        }
        for (p in parts) {
            if (p.isEmpty) continue
            c.save()
            c.clipRect(p)
            if (b != null) c.drawBitmap(b, null, dst, paint) else c.drawRect(p, fill)
            c.restore()
        }
    }
}
