package com.allinone.emulator.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.allinone.emulator.net.ZeroTierVpnService
import com.allinone.emulator.net.ZtEngine
import com.allinone.emulator.net.ZtState
import com.allinone.emulator.net.ZtStore

/**
 * Layar ZeroTier tertanam (setara aplikasi ZeroTier One): tambah jaringan lewat Network ID, nyalakan/matikan per jaringan,
 * izin data seluler, Node ID dan status. VPN-nya berjalan di dalam aplikasi ini (ZeroTierVpnService).
 * Dibuka dari lobby (tombol Gabung) dengan EXTRA_ADD_ID / EXTRA_ADD_NAME untuk langsung menambah + menyalakan satu jaringan.
 */
class ZeroTierActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ADD_ID = "zt_add_id"
        const val EXTRA_ADD_NAME = "zt_add_name"
    }

    private lateinit var list: ListView
    private lateinit var info: TextView
    private lateinit var footer: TextView
    private var nets: List<ZtStore.Net> = emptyList()
    private var lastSig = ""
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) ZeroTierVpnService.start(this)
        else Toast.makeText(this, "Izin VPN ditolak, ZeroTier tidak bisa berjalan", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@ZeroTierActivity).apply { text = "ZeroTier"; textSize = 18f })
            addView(TextView(this@ZeroTierActivity).apply {
                text = "Maksimal satu jaringan 10 orang"
                textSize = 12f
                maxLines = 2
                setPadding(dp(12), 0, dp(8), 0)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        bar.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply { text = "Tambah jaringan"; setOnClickListener { addDialog() } })
        bar.addView(Button(this).apply { text = "Uji koneksi"; setOnClickListener { diagDialog() } })
        bar.addView(Button(this).apply { text = "Pengaturan"; setOnClickListener { settingsDialog() } })

        info = TextView(this).apply { setPadding(dp(16), dp(4), dp(16), dp(4)); visibility = View.GONE }
        list = ListView(this)
        footer = TextView(this).apply { setPadding(dp(16), dp(8), dp(16), dp(8)); setOnClickListener { copyNodeId() } }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(info)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(footer)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)

        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> nets.getOrNull(pos)?.let { netMenu(it) } }

        if (!ZtEngine.available()) {
            info.visibility = View.VISIBLE
            info.text = "Mesin ZeroTier tidak ikut di build ini, jadi VPN tertanam belum bisa dipakai. " +
                "Lihat README (bagian ZeroTier tertanam) dan artifact zerotier-api di GitHub Actions. " +
                "Sementara itu pakai aplikasi ZeroTier One biasa."
        }

        intent.getStringExtra(EXTRA_ADD_ID)?.let { id ->
            intent.removeExtra(EXTRA_ADD_ID)
            if (ZtStore.add(this, id, intent.getStringExtra(EXTRA_ADD_NAME).orEmpty())) activate()
        }
    }

    override fun onResume() { super.onResume(); ticker.run() }
    override fun onPause() { handler.removeCallbacks(ticker); super.onPause() }

    // ------------------------------------------------------------------ aksi

    /** Minta izin VPN (sekali), lalu nyalakan/sinkronkan layanan. */
    private fun activate() {
        if (!ZtEngine.available()) { toast("Mesin ZeroTier tidak ikut di build ini"); refresh(); return }
        val prep = VpnService.prepare(this)
        if (prep != null) vpnPermission.launch(prep) else ZeroTierVpnService.start(this)
        refresh()
    }

    /** Uji jalur ke HP teman: masukkan IP ZeroTier-nya (yang tampil di layar host, mis. 10.102.103.211). */
    private fun diagDialog() {
        val svc = ZeroTierVpnService.instance
        if (svc == null || !ZtState.running) { toast("Nyalakan jaringan ZeroTier dulu (toggle di daftar)"); return }
        val ipBox = EditText(this).apply { hint = "IP ZeroTier teman, mis. 10.102.103.211"; setSingleLine(true) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(ipBox)
        }
        AlertDialog.Builder(this).setTitle("Uji koneksi ke teman").setView(box)
            .setPositiveButton("Uji") { _, _ ->
                val txt = ipBox.text.toString().trim()
                val ip = try { com.allinone.emulator.net.EthBridge.parseIp(txt) } catch (_: Exception) { null }
                if (ip == null) { toast("IP tidak valid"); return@setPositiveButton }
                toast("Menguji… tunggu sampai ±15 detik")
                Thread {
                    val res = try { svc.diagnose(ip) } catch (t: Throwable) { "Uji gagal: ${t.javaClass.simpleName}: ${t.message}" }
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        AlertDialog.Builder(this).setTitle("Hasil uji koneksi").setMessage(res)
                            .setPositiveButton("Salin") { _, _ -> copy("Hasil uji", res, "Hasil disalin") }
                            .setNegativeButton("Tutup", null).show()
                    }
                }.start()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun addDialog() {
        val idBox = EditText(this).apply { hint = "Network ID (16 karakter)"; setSingleLine(true) }
        val nameBox = EditText(this).apply { hint = "Nama (opsional)"; setSingleLine(true) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(idBox); addView(nameBox)
        }
        AlertDialog.Builder(this).setTitle("Tambah jaringan").setView(box)
            .setPositiveButton("Tambah") { _, _ ->
                if (ZtStore.add(this, idBox.text.toString(), nameBox.text.toString().trim())) activate()
                else toast("Network ID harus 16 karakter heksadesimal (0-9, a-f)")
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun settingsDialog() {
        val cell = CheckBox(this).apply {
            text = "Izinkan data seluler"
            isChecked = ZtStore.allowCellular(this@ZeroTierActivity)
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        AlertDialog.Builder(this).setTitle("Pengaturan ZeroTier").setView(cell)
            .setMessage("Bawaan mati agar kuota tidak terpakai diam-diam. Berlaku saat ZeroTier dinyalakan.")
            .setPositiveButton("Simpan") { _, _ -> ZtStore.setAllowCellular(this, cell.isChecked) }
            .setNegativeButton("Batal", null)
            .setNeutralButton("Matikan semua") { _, _ ->
                ZtStore.list(this).forEach { ZtStore.setOn(this, it.id, false) }   // supaya pemulihan otomatis tidak menyalakannya lagi
                ZeroTierVpnService.stop(this)
                lastSig = ""; refresh()
            }
            .show()
    }

    private fun netMenu(n: ZtStore.Net) {
        val items = if (ZtStore.isDefault(n.id)) arrayOf("Salin Network ID") else arrayOf("Salin Network ID", "Hapus jaringan")
        AlertDialog.Builder(this).setTitle(n.name)
            .setItems(items) { _, i ->
                if (i == 0) copy("Network ID", n.id, "Network ID disalin")
                else {
                    ZtStore.remove(this, n.id)
                    ZeroTierVpnService.start(this)       // sinkron: keluar dari jaringan, berhenti bila tak ada yang aktif
                    refresh()
                }
            }.setNegativeButton("Tutup", null).show()
    }

    private fun copyNodeId() {
        val id = ZtStore.nodeId(this)
        if (id.isBlank()) toast("Node ID dibuat saat ZeroTier pertama kali dinyalakan") else copy("Node ID", id, "Node ID disalin")
    }

    private fun copy(label: String, text: String, msg: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
        toast(msg)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------------ tampilan

    private fun statusText(id: String, on: Boolean): String {
        if (!on) return "Mati"
        val n = ZtState.nets[id] ?: return if (ZtState.running) "Menghubungkan…" else "Menunggu layanan VPN…"
        return when (n.status) {
            "OK" -> if (n.ip.isEmpty()) "Tersambung (belum ada IP)"
                else if (ZtState.online) "Tersambung · IP ${n.ip}"
                else "Belum online · IP ${n.ip} (data tersimpan, menunggu terhubung ke server ZeroTier)"
            "ACCESS_DENIED" -> "Belum di-Auth: centang Auth untuk Node ID HP ini (${ZtStore.nodeId(this).ifBlank { "?" }}) di my.zerotier.com"
            "NOT_FOUND" -> "Jaringan tidak ditemukan"
            "REQUESTING_CONFIGURATION" -> "Meminta konfigurasi…"
            else -> n.status
        }
    }

    private var lastHeal = 0L

    /**
     * Pemulihan: ada jaringan yang menyala tapi layanan VPN tidak berjalan (perintah start hilang saat dimatikan-dihidupkan cepat,
     * atau layanan dimatikan sistem). Dinyalakan lagi otomatis, paling cepat tiap 4 detik, hanya bila izin VPN sudah ada dan tidak ada galat.
     */
    private fun selfHeal() {
        if (ZtState.running || ZtState.error.isNotEmpty() || !ZtEngine.available()) return
        if (ZtStore.list(this).none { it.on }) return
        val now = System.currentTimeMillis()
        if (now - lastHeal < 4000) return
        lastHeal = now
        if (VpnService.prepare(this) == null) ZeroTierVpnService.start(this)
    }

    private fun refresh() {
        selfHeal()
        nets = ZtStore.list(this)
        val sig = nets.joinToString("|") { "${it.id}:${it.name}:${it.on}:${statusText(it.id, it.on)}" }
        if (sig != lastSig) { lastSig = sig; adapter.notifyDataSetChanged() }
        val node = ZtStore.nodeId(this).ifBlank { "(belum dibuat)" }
        val state = if (ZtState.running) (if (ZtState.online) "ONLINE" else "OFFLINE") else "MATI"
        val st = ZeroTierVpnService.instance?.stats()
        footer.text = "Node ID $node   $state" + (if (st != null) "\n$st" else "") +
            (if (ZtState.running && !ZtState.online) "\nOFFLINE: HP belum terhubung ke server ZeroTier. Bila UDP masuk tetap 0, jaringan/operator ini memblokir UDP; coba Wi-Fi lain. Mesin dimulai ulang otomatis tiap 40 detik." else "") +
            (if (ZtState.error.isNotEmpty()) "\n${ZtState.error}" else "") +
            (if (ZtState.lastLog.isNotEmpty()) "\nLog mesin: ${ZtState.lastLog}" else "")
        if (nets.isEmpty() && ZtEngine.available()) {
            info.visibility = View.VISIBLE
            info.text = "Belum ada jaringan. Tekan Tambah jaringan lalu isi Network ID."
        } else if (ZtEngine.available()) info.visibility = View.GONE
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = nets.size
        override fun getItem(position: Int) = nets[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val n = nets[position]
            val row = LinearLayout(this@ZeroTierActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(10), dp(16), dp(10))
            }
            val text = LinearLayout(this@ZeroTierActivity).apply { orientation = LinearLayout.VERTICAL }
            text.addView(TextView(this@ZeroTierActivity).apply { this.text = n.name; textSize = 16f })
            text.addView(TextView(this@ZeroTierActivity).apply { this.text = n.id; textSize = 12f })
            text.addView(TextView(this@ZeroTierActivity).apply { this.text = statusText(n.id, n.on); textSize = 13f })
            row.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Switch(this@ZeroTierActivity).apply {
                isChecked = n.on
                setOnCheckedChangeListener { _, on ->
                    ZtStore.setOn(this@ZeroTierActivity, n.id, on)
                    if (on) activate() else ZeroTierVpnService.start(this@ZeroTierActivity)   // sinkron: keluar / berhenti
                }
            })
            return row
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
