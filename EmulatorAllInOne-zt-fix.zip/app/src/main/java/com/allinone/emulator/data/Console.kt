package com.allinone.emulator.data

/** Sistem yang didukung. `core` = nama file library core di nativeLibraryDir. */
enum class Console(val label: String, val core: String, val extensions: Set<String>) {
    GBA("Game Boy Advance", "libmgba_libretro_android.so", setOf("gba")),
    SNES("Super Nintendo (SNES)", "libsnes9x_libretro_android.so", setOf("sfc", "smc", "fig", "swc")),
    GENESIS("Sega Genesis / Mega Drive", "libgenesis_plus_gx_libretro_android.so", setOf("md", "gen", "smd", "bin")),
    /** Core arcade bawaan: semua file .zip arcade masuk library dengan core ini. */
    ARCADE_MAME("Arcade (MAME 2010)", "libmame2010_libretro_android.so", setOf("zip")),
    /**
     * Pilihan core kedua untuk game arcade yang sama (muncul saat tekan lama game arcade di library).
     * Tidak punya ekstensi/folder ROM sendiri: memakai file zip di folder arcade MAME, jadi set ROM-nya harus cocok dengan FBNeo.
     */
    ARCADE_FBNEO("Arcade (FBNeo)", "libfbneo_libretro_android.so", emptySet()),
    /** Core arcade tambahan (pilihan tekan lama): memakai zip yang sama di folder arcade, set ROM-nya mengikuti versi core masing-masing. */
    ARCADE_FBA2012("Arcade (FB Alpha 2012)", "libfbalpha2012_libretro_android.so", emptySet()),
    ARCADE_MAME2000("Arcade (MAME 2000, set 0.37b5)", "libmame2000_libretro_android.so", emptySet()),
    ARCADE_MAME2003("Arcade (MAME 2003, set 0.78)", "libmame2003_libretro_android.so", emptySet()),
    ARCADE_MAME2003P("Arcade (MAME 2003-Plus, set 0.78+)", "libmame2003_plus_libretro_android.so", emptySet());

    val isArcade: Boolean get() = name.startsWith("ARCADE_")

    /** Akhiran nama file save/state per core (format state tiap core tidak sama). Kosong untuk non-arcade. */
    val saveTag: String get() = when (this) {
        ARCADE_MAME -> ".mame2010"
        ARCADE_FBNEO -> ".fbneo"
        ARCADE_FBA2012 -> ".fba2012"
        ARCADE_MAME2000 -> ".mame2000"
        ARCADE_MAME2003 -> ".mame2003"
        ARCADE_MAME2003P -> ".mame2003p"
        else -> ""
    }

    companion object {
        /** .7z dan .rar ikut dianggap "arsip" yang awalnya masuk ke folder arcade, lalu isinya dibaca dan dipilah ke konsol yang tepat. */
        fun fromExtension(ext: String): Console? =
            values().firstOrNull { ext in it.extensions } ?: if (ext == "7z" || ext == "rar") ARCADE_MAME else null
    }
}
