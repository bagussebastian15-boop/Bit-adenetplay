package com.allinone.emulator.ui

import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.LobbyApi
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.NetplayStatus
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.zip.CRC32

/**
 * Multiplayer online/LAN dengan rollback (gaya GGPO), 2 pemain.
 * Host = pemain 1, tamu = pemain 2. Kedua HP harus memakai ROM + core yang sama.
 */
class NetplayUi(
    private val act: Activity,
    private val retro: GLRetroView,
    private val rom: File,
    private val coreId: String,
    private val root: FrameLayout
) {
    private val main = Handler(Looper.getMainLooper())
    private var polling = false
    private var lastState = NetplayStatus.State.OFF

    private val overlay = TextView(act).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        textSize = 11f
        setPadding(14, 6, 14, 6)
        visibility = android.view.View.GONE
    }

    /** True selama game dikendalikan sesi netplay: simpan/muat state, reset, cheat, fast forward dimatikan. */
    val active: Boolean
        get() = lastState == NetplayStatus.State.SYNCING || lastState == NetplayStatus.State.RUNNING

    /** True bila ada sesi (menunggu / menyambung / jalan). */
    val inSession: Boolean get() = lastState != NetplayStatus.State.OFF && lastState != NetplayStatus.State.ENDED

    fun showMenu(show: (AlertDialog.Builder) -> Unit) {
        val items = if (inSession || lastState == NetplayStatus.State.ENDED)
            arrayOf("Hentikan multiplayer")
        else arrayOf("Host (jadi pemain 1)", "Gabung (jadi pemain 2)")
        show(AlertDialog.Builder(act).setTitle("Multiplayer rollback").setItems(items) { _, i ->
            if (inSession || lastState == NetplayStatus.State.ENDED) stop()
            else if (i == 0) hostDialog(show) else joinDialog(show)
        })
    }

    // ---------------------------------------------------------------- multiplayer online (lobby)

    private var lobbyUrl = ""
    private var lobbyToken: String? = null
    private var lastBeat = 0L

    /** Dipanggil otomatis dari menu Multiplayer Online: jadi host, lalu tampilkan server di daftar lobby. */
    fun autoHost(
        delay: Int, lobbyUrl: String, room: String, publicIp: String,
        title: String, consoleName: String, owner: String, vpn: String = ""
    ) {
        gameHash { hash ->
            val ok = retro.netplayHost(PORT, hash, delay)
            afterStart(ok)
            if (!ok || lobbyUrl.isBlank()) return@gameHash
            this.lobbyUrl = lobbyUrl
            val nr = LobbyApi.NewRoom(room, title, consoleName, PORT, delay, owner, publicIp, vpn)
            Thread {
                try {
                    val token = LobbyApi.register(lobbyUrl, nr)
                    lobbyToken = token
                    lastBeat = System.currentTimeMillis()
                    main.post { Toast.makeText(act, "Server \"$room\" tampil di daftar Multiplayer Online", Toast.LENGTH_LONG).show() }
                } catch (e: LobbyApi.Rejected) {
                    main.post { Toast.makeText(act, "Tidak masuk daftar: ${e.message}\nPemain lain masih bisa gabung lewat IP.", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    main.post { Toast.makeText(act, "Lobby tidak terjangkau: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    /** Dipanggil otomatis dari menu Multiplayer Online: gabung ke server yang dipilih (alamat boleh berupa nama domain). */
    fun autoJoin(host: String, port: Int) {
        Toast.makeText(act, "Menyambung ke $host…", Toast.LENGTH_SHORT).show()
        Thread {
            // Native hanya menerima IPv4 angka, jadi nama domain di-resolve dulu di sini
            val ip = try {
                InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }?.hostAddress
            } catch (_: Exception) { null }
            main.post {
                if (ip == null) {
                    Toast.makeText(act, "Alamat server tidak ditemukan: $host", Toast.LENGTH_LONG).show()
                } else {
                    gameHash { hash -> afterStart(retro.netplayJoin(ip, port, hash, 2)) }
                }
            }
        }.start()
    }

    private fun lobbyBeat(st: NetplayStatus) {
        val token = lobbyToken ?: return
        val now = System.currentTimeMillis()
        if (now - lastBeat < 15_000) return
        lastBeat = now
        val players = if (st.state == NetplayStatus.State.SYNCING || st.state == NetplayStatus.State.RUNNING) 2 else 1
        val url = lobbyUrl
        Thread { try { LobbyApi.heartbeat(url, token, players) } catch (_: Exception) {} }.start()
    }

    private fun lobbyClose() {
        val token = lobbyToken ?: return
        lobbyToken = null
        val url = lobbyUrl
        Thread { try { LobbyApi.close(url, token) } catch (_: Exception) {} }.start()
    }

    private fun hostDialog(show: (AlertDialog.Builder) -> Unit) {
        val ips = localIps()
        val delays = listOf(1, 2, 3, 4, 5, 6)
        val labels = delays.map { d ->
            when (d) {
                1 -> "1 frame (paling responsif, koneksi harus bagus)"
                2 -> "2 frame (bawaan, cocok untuk Wi-Fi/LAN)"
                3 -> "3 frame (internet cukup stabil)"
                4 -> "4 frame (koneksi kurang stabil)"
                5 -> "5 frame (ZeroTier/VPN, disarankan)"
                else -> "6 frame (ZeroTier lewat relay / ping tinggi)"
            }
        }
        show(AlertDialog.Builder(act)
            // JANGAN pakai setMessage bersama setItems: Android menyembunyikan daftar pilihannya.
            .setTitle("Host: IP ${if (ips.isEmpty()) "(tidak terdeteksi)" else ips.joinToString(", ")} port $PORT\nPilih input delay (dipakai kedua pemain):")
            .setItems(labels.toTypedArray()) { _, i ->
                gameHash { hash ->
                    val ok = retro.netplayHost(PORT, hash, delays[i])
                    afterStart(ok)
                }
            }
            .setNegativeButton("Batal", null))
    }

    private fun joinDialog(show: (AlertDialog.Builder) -> Unit) {
        val et = EditText(act).apply {
            hint = "IP host, mis. 192.168.1.5"
            setSingleLine(true)
            setText(lastIp)
        }
        val box = FrameLayout(act).apply {
            val m = (20 * act.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        show(AlertDialog.Builder(act)
            .setTitle("Gabung ke host")
            .setMessage("Masukkan IP host (port $PORT dipakai otomatis; bisa juga ditulis ip:port).")
            .setView(box)
            .setPositiveButton("Gabung") { _, _ ->
                val txt = et.text.toString().trim()
                if (txt.isEmpty()) return@setPositiveButton
                lastIp = txt
                val ip = txt.substringBefore(':')
                val port = txt.substringAfter(':', "").toIntOrNull() ?: PORT
                gameHash { hash -> afterStart(retro.netplayJoin(ip, port, hash, 2)) }
            }
            .setNegativeButton("Batal", null))
    }

    /** Sidik jari game: CRC32 ROM digabung nama core. Harus sama di kedua HP. */
    private fun gameHash(onReady: (Int) -> Unit) {
        Toast.makeText(act, "Menyiapkan multiplayer…", Toast.LENGTH_SHORT).show()
        Thread {
            val crc = CRC32()
            try {
                rom.inputStream().use { s ->
                    val buf = ByteArray(64 * 1024)
                    while (true) { val n = s.read(buf); if (n <= 0) break; crc.update(buf, 0, n) }
                }
            } catch (_: Exception) {}
            val coreName = File(coreId).name.substringAfterLast('/')
            val h = (crc.value.toInt()) xor coreName.hashCode()
            main.post { onReady(h) }
        }.start()
    }

    private fun afterStart(ok: Boolean) {
        if (!ok) {
            val e = retro.netplayStatus().error
            Toast.makeText(act, errorText(e), Toast.LENGTH_LONG).show()
            retro.netplayStop()
            return
        }
        if (overlay.parent == null) {
            root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }
        startPolling()
    }

    fun stop() {
        polling = false
        lobbyClose()
        try { retro.netplayStop() } catch (_: Exception) {}
        lastState = NetplayStatus.State.OFF
        overlay.visibility = android.view.View.GONE
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        main.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val st = try { retro.netplayStatus() } catch (_: Exception) { null }
                if (st != null) render(st)
                if (polling) main.postDelayed(this, 500)
            }
        })
    }

    private fun render(st: NetplayStatus) {
        val prev = lastState
        lastState = st.state
        lobbyBeat(st)
        overlay.visibility = android.view.View.VISIBLE
        overlay.text = when (st.state) {
            NetplayStatus.State.HOST_WAITING ->
                "Menunggu pemain 2… IP: ${localIps().joinToString(", ")}:$PORT"
            NetplayStatus.State.CLIENT_CONNECTING -> "Menyambung ke host…"
            NetplayStatus.State.SYNCING -> "Sinkronisasi game…"
            NetplayStatus.State.RUNNING ->
                "P${st.localPlayer + 1} · ping ${st.pingMs} ms · rollback ${st.lastRollbackFrames}f" +
                    if (st.desync) " · DESYNC!" else ""
            else -> ""
        }
        if (st.state == NetplayStatus.State.ENDED && prev != NetplayStatus.State.ENDED) {
            Toast.makeText(act, errorText(st.error) + "\nGame dilanjutkan sendiri.", Toast.LENGTH_LONG).show()
            stop()
        }
    }

    private fun errorText(e: NetplayStatus.Error) = when (e) {
        NetplayStatus.Error.GAME_MISMATCH -> "Game/core berbeda: kedua HP harus memakai ROM dan core yang sama."
        NetplayStatus.Error.CONNECT -> "Tidak bisa tersambung ke host (cek IP, port $PORT, dan jaringan)."
        NetplayStatus.Error.TIMEOUT -> "Koneksi terputus (tidak ada balasan)."
        NetplayStatus.Error.VERSION -> "Versi multiplayer berbeda."
        NetplayStatus.Error.STATE_TOO_BIG -> "Core ini tidak cocok untuk rollback (state terlalu besar)."
        NetplayStatus.Error.SOCKET -> "Port $PORT tidak bisa dibuka (sedang dipakai?)."
        NetplayStatus.Error.PEER_LEFT -> "Lawan keluar dari multiplayer."
        NetplayStatus.Error.NONE -> "Multiplayer berhenti."
    }

    private fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && !it.isLoopbackAddress }.map { it.hostAddress ?: "" }
            .filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }

    companion object {
        const val PORT = 7755
        private var lastIp = ""
    }
}
