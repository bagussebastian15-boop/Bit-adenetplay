package com.allinone.emulator.net

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.math.BigInteger
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * VPN ZeroTier di dalam aplikasi (pengganti aplikasi ZeroTier One).
 *
 * Alur: ZtEngine (node ZeroTier) <-> EthBridge (ARP, IP<->Ethernet) <-> TUN milik VpnService <-> soket netplay biasa.
 * Karena TUN adalah antarmuka jaringan sungguhan, kode netplay (soket TCP/UDP biasa) TIDAK diubah.
 * VPN dibatasi hanya untuk aplikasi ini (addAllowedApplication) dan hanya rentang IP jaringan ZeroTier (addRoute),
 * jadi internet dan aplikasi lain tidak terganggu. Catatan Android: hanya satu VPN yang bisa aktif pada satu waktu.
 */
class ZeroTierVpnService : VpnService(), ZtEngine.Listener {

    companion object {
        private const val TAG = "ZeroTierVpn"
        private const val ACTION_START = "com.allinone.emulator.zt.START"   // juga berarti "sinkronkan daftar jaringan"
        private const val ACTION_STOP = "com.allinone.emulator.zt.STOP"

        fun start(ctx: Context) { ctx.startService(Intent(ctx, ZeroTierVpnService::class.java).setAction(ACTION_START)) }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, ZeroTierVpnService::class.java).setAction(ACTION_STOP)) }

        fun nwidOf(id: String): Long = BigInteger(id, 16).toLong()
        fun idOf(nwid: Long): String = String.format("%016x", nwid)

        private fun ipStr(ip: Int) = "${ip ushr 24}.${(ip shr 16) and 255}.${(ip shr 8) and 255}.${ip and 255}"
        private fun maskOf(prefix: Int) = if (prefix <= 0) 0 else -1 shl (32 - minOf(prefix, 32))
    }

    private data class Assigned(val ip: Int, val prefix: Int, val mac: Long, val mtu: Int)

    private val exec = Executors.newSingleThreadExecutor()
    private val lock = Any()
    private val outLock = Any()
    private val bridges = ConcurrentHashMap<Long, EthBridge>()
    private val assigned = LinkedHashMap<Long, Assigned>()
    private val joined = HashSet<String>()
    @Volatile private var engine: ZtEngine? = null
    private var tun: ParcelFileDescriptor? = null
    private var tunOut: FileOutputStream? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val stopping = intent?.action == ACTION_STOP
        exec.execute { if (stopping) shutdown() else startOrSync() }
        return START_NOT_STICKY
    }

    override fun onRevoke() { exec.execute { shutdown() } }      // pemain mematikan VPN lewat pengaturan sistem

    override fun onDestroy() {
        exec.execute { teardown() }
        exec.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ mulai / sinkron / berhenti

    private fun fail(msg: String) {
        Log.w(TAG, msg)
        ZtState.error = msg
        teardown()
        stopSelf()
    }

    @Suppress("DEPRECATION")
    private fun onCellular(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo?.type == ConnectivityManager.TYPE_MOBILE
    }

    private fun startOrSync() {
        val wanted = ZtStore.list(this).filter { it.on }
        if (wanted.isEmpty()) { shutdown(); return }

        if (engine == null) {
            if (!ZtEngine.available()) { fail("Mesin ZeroTier tidak ikut di build ini. ${ZtEngine.unavailableReason()}"); return }
            if (!ZtStore.allowCellular(this) && onCellular()) { fail("Data seluler dimatikan di pengaturan ZeroTier (aktifkan lalu coba lagi)"); return }
            val e = ZtEngine(ZtStore.dataDir(this), { s -> protect(s) }, this)
            try { e.start() } catch (t: Throwable) { fail("Gagal memulai ZeroTier: ${t.message}"); return }
            engine = e
            ZtState.running = true
            ZtState.error = ""
            ZtState.nodeId = e.nodeId()
            startAnnouncer(e)
        }
        val e = engine ?: return

        val want = wanted.map { it.id }.toSet()
        for (id in joined.toList()) if (id !in want) {                  // jaringan dimatikan / dihapus
            e.leave(nwidOf(id)); joined.remove(id); ZtState.nets.remove(id); dropNet(nwidOf(id))
        }
        for (n in wanted) if (joined.add(n.id)) {
            ZtState.nets[n.id] = ZtState.Net(n.name, "REQUESTING_CONFIGURATION", "")
            e.join(nwidOf(n.id))
        }
    }

    private fun shutdown() {
        teardown()
        stopSelf()
    }

    private fun teardown() {
        engine?.stop()
        engine = null
        synchronized(lock) { closeTun(); bridges.clear(); assigned.clear() }
        joined.clear()
        ZtDiscovery.clearFound()
        ZtState.reset()
    }

    // ------------------------------------------------------------------ callback dari ZtEngine

    override fun onNetwork(nwid: Long, name: String?, status: String?, mac: Long, ip: Int, prefix: Int, mtu: Int) {
        val id = idOf(nwid)
        if (status == "REMOVED") { ZtState.nets.remove(id); dropNet(nwid); return }
        val stored = ZtStore.list(this).firstOrNull { it.id == id }?.name.orEmpty()
        ZtState.nets[id] = ZtState.Net(name.orEmpty().ifBlank { stored.ifBlank { id } }, status.orEmpty(), if (ip != 0) ipStr(ip) else "")
        if (ip == 0 || prefix !in 1..32) { dropNet(nwid); return }
        val a = Assigned(ip, prefix, mac, mtu)
        synchronized(lock) {
            if (assigned[nwid] == a) return
            assigned[nwid] = a
            bridges[nwid] = EthBridge(mac, ip, prefix,
                { dst, src, type, payload -> engine?.sendFrame(nwid, src, dst, type, payload) },
                { buf, off, len -> writeTun(buf, off, len) })
        }
        engine?.subscribeArp(nwid, ip)
        rebuildTun()
    }

    override fun onFrame(nwid: Long, srcMac: Long, dstMac: Long, etherType: Int, frame: ByteArray) {
        // Paket pengumuman server (siaran) dipakai habis di sini, tidak diteruskan ke TUN
        if (etherType == EthBridge.ETH_IPV4 && ZtDiscovery.handle(frame, bridges[nwid]?.ip() ?: 0, System.currentTimeMillis())) return
        bridges[nwid]?.fromNet(srcMac, dstMac, etherType, frame)
    }

    // ------------------------------------------------------------------ pengumuman server (siaran)

    /** Selama mesin hidup: bila host sedang mengumumkan server, kirim siaran ke tiap jaringan yang sudah punya IP. */
    private fun startAnnouncer(e: ZtEngine) {
        Thread({
            while (engine === e) {
                try { announceOnce(e) } catch (t: Throwable) { Log.w(TAG, "announce: $t") }
                try { Thread.sleep(ZtDiscovery.INTERVAL_MS) } catch (_: InterruptedException) { break }
            }
        }, "zt-announce").apply { isDaemon = true }.start()
    }

    private fun announceOnce(e: ZtEngine) {
        if (!ZtDiscovery.isAnnouncing()) return
        val snap = synchronized(lock) { assigned.toList() }
        for ((nwid, a) in snap) {
            val pkt = ZtDiscovery.buildPacket(a.ip, a.prefix) ?: continue
            e.sendFrame(nwid, a.mac, EthBridge.BROADCAST, EthBridge.ETH_IPV4, pkt)
        }
    }

    override fun onOnline(online: Boolean) { ZtState.online = online }

    override fun onLog(msg: String) { Log.d(TAG, msg) }

    private fun dropNet(nwid: Long) {
        val had = synchronized(lock) {
            val b = bridges.remove(nwid) != null
            val a = assigned.remove(nwid) != null
            b || a
        }
        if (had) rebuildTun()
    }

    // ------------------------------------------------------------------ TUN

    private fun rebuildTun() {
        synchronized(lock) { rebuildTunLocked() }
    }

    private fun rebuildTunLocked() {
        val list = assigned.values.toList()
        if (list.isEmpty()) { closeTun(); return }
        val b = Builder().setSession("ZeroTier")
        var mtu = 2800
        for (a in list) {
            b.addAddress(ipStr(a.ip), a.prefix)
            b.addRoute(ipStr(a.ip and maskOf(a.prefix)), a.prefix)
            mtu = minOf(mtu, a.mtu)
        }
        b.setMtu(mtu.coerceIn(1280, 2800))
        try { b.addAllowedApplication(packageName) } catch (_: PackageManager.NameNotFoundException) { }
        b.setBlocking(true)
        val fd = try { b.establish() } catch (t: Exception) { Log.w(TAG, "establish: $t"); null }
        if (fd == null) { ZtState.error = "Izin VPN belum diberikan atau VPN lain sedang aktif"; return }
        ZtState.error = ""
        closeTun()
        tun = fd
        tunOut = FileOutputStream(fd.fileDescriptor)
        startReader(fd)
    }

    private fun closeTun() {
        try { tun?.close() } catch (_: IOException) { }
        tun = null
        synchronized(outLock) { tunOut = null }
    }

    private fun writeTun(buf: ByteArray, off: Int, len: Int) {
        synchronized(outLock) { try { tunOut?.write(buf, off, len) } catch (_: IOException) { } }
    }

    private fun startReader(fd: ParcelFileDescriptor) {
        Thread({
            val inp = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(65535)
            try {
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    for (br in bridges.values) if (br.accepts(buf, n)) { br.fromTun(buf, n); break }
                }
            } catch (_: IOException) { }
        }, "zt-tun").apply { isDaemon = true }.start()
    }
}
