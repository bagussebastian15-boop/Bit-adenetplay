package com.allinone.emulator.net

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.io.FileOutputStream
import java.io.IOException
import java.math.BigInteger
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * VPN ZeroTier di dalam aplikasi (pengganti aplikasi ZeroTier One).
 *
 * Alur: ZtEngine (node ZeroTier) <-> EthBridge (ARP, IP<->Ethernet) <-> TUN milik VpnService <-> soket netplay biasa.
 * Karena TUN adalah antarmuka jaringan sungguhan, kode netplay (soket TCP/UDP biasa) TIDAK diubah.
 * VPN dibatasi hanya untuk aplikasi ini (addAllowedApplication) dan hanya rentang IP jaringan ZeroTier (addRoute),
 * jadi internet dan aplikasi lain tidak terganggu. Catatan Android: hanya satu VPN yang bisa aktif pada satu waktu.
 */
class ZeroTierVpnService : VpnService(), ZtEngine.Listener {

    companion object {
        private const val TAG = "ZeroTierVpn"
        private const val ACTION_START = "com.allinone.emulator.zt.START"   // juga berarti "sinkronkan daftar jaringan"
        private const val ACTION_STOP = "com.allinone.emulator.zt.STOP"

        fun start(ctx: Context) { ctx.startService(Intent(ctx, ZeroTierVpnService::class.java).setAction(ACTION_START)) }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, ZeroTierVpnService::class.java).setAction(ACTION_STOP)) }

        private const val ECHO_PORT = 7757      // gema UDP kecil untuk uji koneksi (Layar ZeroTier -> Uji koneksi)
        @Volatile var instance: ZeroTierVpnService? = null
        /** Satu antrean untuk SEMUA instance layanan: perintah start berikutnya tidak pernah ditolak walau instance lama sedang ditutup. */
        private val exec = Executors.newSingleThreadExecutor()

        fun nwidOf(id: String): Long = BigInteger(id, 16).toLong()
        fun idOf(nwid: Long): String = String.format("%016x", nwid)

        private fun ipStr(ip: Int) = "${ip ushr 24}.${(ip shr 16) and 255}.${(ip shr 8) and 255}.${ip and 255}"
        private fun maskOf(prefix: Int) = if (prefix <= 0) 0 else -1 shl (32 - minOf(prefix, 32))
    }

    private data class Assigned(val ip: Int, val prefix: Int, val mac: Long, val mtu: Int)

    private val lock = Any()
    private val outLock = Any()
    private val bridges = ConcurrentHashMap<Long, EthBridge>()
    private val assigned = LinkedHashMap<Long, Assigned>()
    private val joined = HashSet<String>()
    @Volatile private var engine: ZtEngine? = null
    private var tun: ParcelFileDescriptor? = null
    private var tunOut: FileOutputStream? = null
    /** startId perintah yang sedang diproses; stopSelf(id) hanya berlaku bila belum ada perintah start yang lebih baru (mencegah layanan menutup diri tepat saat pemain menyalakan lagi). */
    @Volatile private var cmdId = 0

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val stopping = intent?.action == ACTION_STOP
        val id = startId
        exec.execute { cmdId = id; if (stopping) shutdown() else startOrSync() }
        return START_NOT_STICKY
    }

    override fun onRevoke() { exec.execute { teardown(); stopSelf() } }      // pemain mematikan VPN lewat pengaturan sistem

    override fun onDestroy() {
        if (instance === this) instance = null      // jangan menimpa instance baru bila yang lama baru ditutup belakangan
        exec.execute { teardown() }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ mulai / sinkron / berhenti

    private fun fail(msg: String) {
        Log.w(TAG, msg)
        ZtState.error = msg
        teardown()
        stopSelf(cmdId)
    }

    @Suppress("DEPRECATION")
    private fun onCellular(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo?.type == ConnectivityManager.TYPE_MOBILE
    }

    private fun startOrSync() {
        val wanted = ZtStore.list(this).filter { it.on }
        if (wanted.isEmpty()) { shutdown(); return }

        if (engine == null) {
            if (!ZtEngine.available()) { fail("Mesin ZeroTier tidak ikut di build ini. ${ZtEngine.unavailableReason()}"); return }
            if (!ZtStore.allowCellular(this) && onCellular()) { fail("Data seluler dimatikan di pengaturan ZeroTier (aktifkan lalu coba lagi)"); return }
            val e = ZtEngine(ZtStore.dataDir(this), { s -> protect(s) }, this)
            try { e.start() } catch (t: Throwable) { fail("Gagal memulai ZeroTier: ${t.message}"); return }
            engine = e
            ZtState.running = true
            ZtState.error = ""
            ZtState.nodeId = e.nodeId()
            ZtDiscovery.setSelf(com.allinone.emulator.data.Settings(this).playerName, ZtState.nodeId)
            startAnnouncer(e)
        }
        val e = engine ?: return

        val want = wanted.map { it.id }.toSet()
        for (id in joined.toList()) if (id !in want) {                  // jaringan dimatikan / dihapus
            e.leave(nwidOf(id)); joined.remove(id); ZtState.nets.remove(id); dropNet(nwidOf(id))
        }
        for (n in wanted) if (joined.add(n.id)) {
            ZtState.nets[n.id] = ZtState.Net(n.name, "REQUESTING_CONFIGURATION", "")
            e.join(nwidOf(n.id))
        }
    }

    private fun shutdown() {
        teardown()
        stopSelf(cmdId)
    }

    private fun teardown() {
        engine?.stop()
        engine = null
        try { echo?.close() } catch (_: Exception) { }
        echo = null
        synchronized(lock) { closeTun(); bridges.clear(); assigned.clear() }
        joined.clear()
        // Status global hanya direset oleh instance yang masih berlaku; penutupan instance lama tidak boleh menghapus status instance baru
        if (instance === this || instance == null) {
            ZtDiscovery.clearFound()
            ZtDiscovery.clearSelf()
            ZtState.reset()
        }
    }

    // ------------------------------------------------------------------ callback dari ZtEngine

    override fun onNetwork(nwid: Long, name: String?, status: String?, mac: Long, ip: Int, prefix: Int, mtu: Int) {
        val id = idOf(nwid)
        if (status == "REMOVED") { ZtState.nets.remove(id); dropNet(nwid); return }
        val stored = ZtStore.list(this).firstOrNull { it.id == id }?.name.orEmpty()
        ZtState.nets[id] = ZtState.Net(name.orEmpty().ifBlank { stored.ifBlank { id } }, status.orEmpty(), if (ip != 0) ipStr(ip) else "")
        if (ip == 0 || prefix !in 1..32) { dropNet(nwid); return }
        val a = Assigned(ip, prefix, mac, mtu)
        synchronized(lock) {
            if (assigned[nwid] == a) return
            assigned[nwid] = a
            bridges[nwid] = EthBridge(mac, ip, prefix,
                { dst, src, type, payload -> engine?.sendFrame(nwid, src, dst, type, payload) },
                { buf, off, len -> writeTun(buf, off, len) })
        }
        engine?.subscribeArp(nwid, ip)
        engine?.subscribeBroadcast(nwid)
        startEcho()
        rebuildTun()
    }

    override fun onFrame(nwid: Long, srcMac: Long, dstMac: Long, etherType: Int, frame: ByteArray) {
        ZtState.framesIn++
        // Paket pengumuman server (siaran) dipakai habis di sini, tidak diteruskan ke TUN
        if (etherType == EthBridge.ETH_IPV4 && ZtDiscovery.handle(frame, bridges[nwid]?.ip() ?: 0, System.currentTimeMillis())) return
        bridges[nwid]?.fromNet(srcMac, dstMac, etherType, frame)
    }

    // ------------------------------------------------------------------ uji koneksi (diagnosis)

    @Volatile private var echo: DatagramSocket? = null

    /** Soket gema: membalas "ZTPING" dengan "ZTPONG" supaya HP lain bisa menguji jalur penuh lewat VPN ini. */
    private fun startEcho() {
        if (echo != null) return
        try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            s.bind(InetSocketAddress(ECHO_PORT))
            echo = s
            Thread({
                val buf = ByteArray(64)
                val p = DatagramPacket(buf, buf.size)
                while (true) {
                    try {
                        p.length = buf.size
                        s.receive(p)
                        if (p.length >= 6 && String(buf, 0, 6) == "ZTPING") {
                            val r = "ZTPONG".toByteArray()
                            s.send(DatagramPacket(r, r.size, p.socketAddress))
                        }
                    } catch (_: IOException) { break }
                }
            }, "zt-echo").apply { isDaemon = true }.start()
        } catch (t: Exception) { Log.w(TAG, "echo: $t") }
    }

    /**
     * Uji jalur ke satu IP ZeroTier, bertahap supaya kelihatan lapisan mana yang macet. BLOKIR (sampai ±15 detik):
     * panggil dari thread latar. 1) mesin online? 2) peer terlihat? 3) ARP dijawab? 4) UDP pulang-pergi lewat VPN?
     */
    fun diagnose(target: Int): String {
        val sb = StringBuilder()
        sb.append("1. Mesin ZeroTier: ").append(if (ZtState.online) "ONLINE" else "OFFLINE (belum terhubung ke server root ZeroTier)").append('\n')
        val br = bridges.values.firstOrNull { it.covers(target) }
        if (br == null) {
            return sb.append("\nIP ${ipStr(target)} di luar rentang jaringan ZeroTier Anda, atau jaringan Anda belum dapat IP. " +
                "Cek layar ZeroTier: jaringan harus OK dan punya IP.").toString()
        }
        engine?.peerSummary()?.let { sb.append("2. Peer: ").append(it).append('\n') }
        sb.append("   Frame masuk dari jaringan: ").append(ZtState.framesIn).append('\n')

        var mac = 0L
        for (i in 0 until 6) {
            br.probe(target)
            try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
            mac = br.macOf(target)
            if (mac != 0L) break
        }
        if (mac == 0L) {
            return sb.append("3. ARP: TIDAK ADA JAWABAN dari ${ipStr(target)}\n\n" +
                "HP itu tidak terjangkau lewat ZeroTier. Periksa di HP itu: ZeroTier ONLINE dan punya IP ini, sudah di-Auth di my.zerotier.com, " +
                "data seluler diizinkan (Pengaturan ZeroTier), dan aplikasi ZeroTier One asli dimatikan.").toString()
        }
        sb.append("3. ARP: jawaban diterima (MAC ").append(String.format("%012x", mac)).append(")\n")

        var rtt = -1L
        var err = ""
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 1500
                val ping = "ZTPING".toByteArray()
                val to = InetAddress.getByAddress(byteArrayOf((target ushr 24).toByte(), (target shr 16).toByte(), (target shr 8).toByte(), target.toByte()))
                for (i in 0 until 3) {
                    if (rtt >= 0) break
                    val t0 = System.nanoTime()
                    s.send(DatagramPacket(ping, ping.size, to, ECHO_PORT))
                    try {
                        val r = DatagramPacket(ByteArray(16), 16)
                        s.receive(r)
                        if (String(r.data, 0, r.length) == "ZTPONG") rtt = (System.nanoTime() - t0) / 1_000_000
                    } catch (_: SocketTimeoutException) { }
                }
            }
        } catch (t: Exception) { err = t.javaClass.simpleName + ": " + t.message }
        if (rtt >= 0) {
            sb.append("4. UDP lewat VPN: OK, ").append(rtt).append(" ms\n\n")
                .append("Jalur ZeroTier ke HP itu beres. Kalau gabung multiplayer tetap gagal, masalahnya di lapisan game (port 7755, ROM/core beda, atau ping terlalu tinggi: coba input delay 5-6 frame).")
        } else {
            sb.append("4. UDP lewat VPN: TIDAK ADA BALASAN").append(if (err.isNotEmpty()) " ($err)" else "").append("\n\n")
                .append("Jalur ZeroTier hidup (ARP dijawab), tapi paket data tidak pulang. Kemungkinan: HP itu belum memakai build ini (gema belum ada), ")
                .append("VPN di salah satu HP tidak aktif, atau TUN tidak meneruskan paket. Coba uji dari HP satunya juga.")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ pengumuman server (siaran)

    /** Selama mesin hidup: bila host sedang mengumumkan server, kirim siaran ke tiap jaringan yang sudah punya IP. */
    private fun startAnnouncer(e: ZtEngine) {
        Thread({
            while (engine === e) {
                try { announceOnce(e) } catch (t: Throwable) { Log.w(TAG, "announce: $t") }
                try { Thread.sleep(ZtDiscovery.INTERVAL_MS) } catch (_: InterruptedException) { break }
            }
        }, "zt-announce").apply { isDaemon = true }.start()
    }

    private fun announceOnce(e: ZtEngine) {
        // Nama pemain bisa diganti di Pengaturan kapan saja, jadi dibaca ulang tiap siaran
        if (ZtDiscovery.hasSelf()) ZtDiscovery.setSelf(com.allinone.emulator.data.Settings(this).playerName, ZtState.nodeId)
        val snap = synchronized(lock) { assigned.toList() }
        for ((nwid, a) in snap) {
            // Kehadiran: selalu disiarkan selama ZeroTier menyala, supaya pemain lain melihat kita tanpa perlu membuat server
            ZtDiscovery.buildPresencePacket(a.ip, a.prefix)?.let { e.sendFrame(nwid, a.mac, EthBridge.BROADCAST, EthBridge.ETH_IPV4, it) }
            // Pengumuman server: hanya saat kita host
            val pkt = ZtDiscovery.buildPacket(a.ip, a.prefix) ?: continue
            e.sendFrame(nwid, a.mac, EthBridge.BROADCAST, EthBridge.ETH_IPV4, pkt)
            ZtDiscovery.noteSent()
        }
    }

    override fun onOnline(online: Boolean) { ZtState.online = online }

    override fun onLog(msg: String) { Log.d(TAG, msg); ZtState.lastLog = msg.take(160) }

    /** Ringkasan peer (jumlah root + anggota jaringan yang terlihat) untuk layar diagnosis, atau null bila tidak tersedia. */
    fun peerInfo(): String? = try { engine?.peerSummary()?.lineSequence()?.firstOrNull() } catch (_: Throwable) { null }

    private fun dropNet(nwid: Long) {
        val had = synchronized(lock) {
            val b = bridges.remove(nwid) != null
            val a = assigned.remove(nwid) != null
            b || a
        }
        if (had) rebuildTun()
    }

    // ------------------------------------------------------------------ TUN

    private fun rebuildTun() {
        synchronized(lock) { rebuildTunLocked() }
    }

    private fun rebuildTunLocked() {
        val list = assigned.values.toList()
        if (list.isEmpty()) { closeTun(); return }
        val b = Builder().setSession("ZeroTier")
        var mtu = 2800
        for (a in list) {
            b.addAddress(ipStr(a.ip), a.prefix)
            b.addRoute(ipStr(a.ip and maskOf(a.prefix)), a.prefix)
            mtu = minOf(mtu, a.mtu)
        }
        b.setMtu(mtu.coerceIn(1280, 2800))
        try { b.addAllowedApplication(packageName) } catch (_: PackageManager.NameNotFoundException) { }
        b.setBlocking(true)
        val fd = try { b.establish() } catch (t: Exception) { Log.w(TAG, "establish: $t"); null }
        if (fd == null) { ZtState.error = "Izin VPN belum diberikan atau VPN lain sedang aktif"; return }
        ZtState.error = ""
        closeTun()
        tun = fd
        tunOut = FileOutputStream(fd.fileDescriptor)
        startReader(fd)
    }

    private fun closeTun() {
        try { tun?.close() } catch (_: IOException) { }
        tun = null
        synchronized(outLock) { tunOut = null }
    }

    private fun writeTun(buf: ByteArray, off: Int, len: Int) {
        synchronized(outLock) { try { tunOut?.write(buf, off, len) } catch (_: IOException) { } }
    }

    private fun startReader(fd: ParcelFileDescriptor) {
        Thread({
            val inp = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(65535)
            try {
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    for (br in bridges.values) if (br.accepts(buf, n)) { br.fromTun(buf, n); break }
                }
            } catch (_: IOException) { }
        }, "zt-tun").apply { isDaemon = true }.start()
    }
}
