package com.allinone.emulator.translate

import java.io.File

/**
 * Kamus tulisan menu awal game (judul/menu utama/opsi). Tulisan menu biasanya satu-dua kata sehingga penerjemah
 * mesin sering salah ("スタート" -> "awal", "オプション" -> "pilihan"); kamus ini memberi padanan yang lazim di game.
 *
 * Pencocokan: hiragana dilipat ke katakana, hanya huruf/angka yang dibandingkan (spasi, kursor ▶, tanda baca dibuang,
 * huruf Latin dibesarkan), lalu dicocokkan persis; bila tidak ada, dicoba toleransi salah baca OCR 1-2 huruf.
 * Kamus pribadi: baris di glosarium_ja.txt (jepang=padanan) ikut dipakai untuk pencocokan persis.
 */
object MenuGlossary {

    private val RAW = """
        スタート=Mulai
        ゲームスタート=Mulai Game
        ゲームをはじめる=Mulai Game
        ゲームかいし=Mulai Game
        ニューゲーム=Game Baru
        NEW GAME=Game Baru
        はじめから=Mulai dari Awal
        さいしょから=Mulai dari Awal
        最初から=Mulai dari Awal
        つづきから=Lanjutkan
        続きから=Lanjutkan
        つづける=Lanjutkan
        続ける=Lanjutkan
        コンティニュー=Lanjutkan
        CONTINUE=Lanjutkan
        ロード=Muat
        ロードゲーム=Muat Game
        LOAD=Muat
        LOAD GAME=Muat Game
        セーブ=Simpan
        SAVE=Simpan
        SAVE GAME=Simpan Game
        オートセーブ=Simpan Otomatis
        セーブデータ=Data Simpanan
        データ=Data
        データをけす=Hapus Data
        データをけします=Hapus Data
        オプション=Opsi
        OPTION=Opsi
        OPTIONS=Opsi
        せってい=Pengaturan
        設定=Pengaturan
        コンフィグ=Pengaturan
        CONFIG=Pengaturan
        SETTINGS=Pengaturan
        メニュー=Menu
        MENU=Menu
        もどる=Kembali
        戻る=Kembali
        BACK=Kembali
        やめる=Berhenti
        止める=Berhenti
        おわる=Selesai
        終わる=Selesai
        ゲームをおわる=Keluar dari Game
        EXIT=Keluar
        QUIT=Keluar
        はい=Ya
        いいえ=Tidak
        YES=Ya
        NO=Tidak
        OK=OK
        キャンセル=Batal
        CANCEL=Batal
        けってい=Pilih
        決定=Pilih
        ステータス=Status
        アイテム=Item
        どうぐ=Perlengkapan
        そうび=Perlengkapan
        マップ=Peta
        ヘルプ=Bantuan
        HELP=Bantuan
        ストーリー=Cerita
        ストーリーモード=Mode Cerita
        ミニゲーム=Minigame
        モード=Mode
        ひとりで=Sendirian
        ふたりで=Berdua
        1人用=1 Pemain
        2人用=2 Pemain
        たいせん=Pertarungan
        対戦=Pertarungan
        れんしゅう=Latihan
        練習=Latihan
        サウンド=Suara
        SOUND=Suara
        おんがく=Musik
        音楽=Musik
        ボリューム=Volume
        スピード=Kecepatan
        ステレオ=Stereo
        モノラル=Mono
        ON=Hidup
        OFF=Mati
        むずかしさ=Tingkat Kesulitan
        難易度=Tingkat Kesulitan
        かんたん=Mudah
        簡単=Mudah
        ふつう=Normal
        普通=Normal
        むずかしい=Sulit
        難しい=Sulit
        EASY=Mudah
        NORMAL=Normal
        HARD=Sulit
        ハイスコア=Skor Tertinggi
        ランキング=Peringkat
        スコア=Skor
        パスワード=Kata Sandi
        PASSWORD=Kata Sandi
        コピー=Salin
        けす=Hapus
        消す=Hapus
        ギャラリー=Galeri
        おまけ=Bonus
        クレジット=Kredit
        CREDITS=Kredit
        ずかん=Ensiklopedia
        図鑑=Ensiklopedia
        START=Mulai
        START GAME=Mulai Game
        GAME START=Mulai Game
        CONFIGURATION=Pengaturan
        PLAYER SELECT=Pilih Pemain
        1 PLAYER=1 Pemain
        2 PLAYERS=2 Pemain
        ONE PLAYER=1 Pemain
        TWO PLAYERS=2 Pemain
        VERSUS=Versus
        ARCADE=Arcade
        TRAINING=Latihan
        PRACTICE=Latihan
        STORY MODE=Mode Cerita
        SOUND TEST=Uji Suara
        MUSIC=Musik
        CONTROLS=Kontrol
        CONTROLLER=Kontroler
        LANGUAGE=Bahasa
        DIFFICULTY=Tingkat Kesulitan
        RESUME=Lanjutkan
        RESTART=Mulai Ulang
        RETRY=Coba Lagi
        PAUSE=Jeda
        EXTRAS=Ekstra
        GAME OVER=Permainan Berakhir
        HIGH SCORE=Skor Tertinggi
        HIGH SCORES=Skor Tertinggi
        PASSWORD ENTRY=Masukkan Kata Sandi
        LICENSED BY NINTENDO=Berlisensi oleh Nintendo
        PRESS START=Tekan Start
        PUSH START=Tekan Start
        PUSH START BUTTON=Tekan Tombol Start
        PRESS START BUTTON=Tekan Tombol Start
        スタートボタンをおしてください=Tekan Tombol Start
        スタートボタンをおしてね=Tekan Tombol Start
    """.trimIndent()

    private fun fold(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = if (ch in '\u3041'..'\u3096') (ch.code + 0x60).toChar() else ch      // hiragana -> katakana
            if (c.isLetterOrDigit()) sb.append(c.uppercaseChar())
        }
        return sb.toString()
    }

    private val table: Map<String, String> by lazy {
        val m = LinkedHashMap<String, String>()
        for (line in RAW.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = fold(line.substring(0, i))
            if (k.isNotEmpty() && k !in m) m[k] = line.substring(i + 1).trim()
        }
        m
    }

    /** Padanan menu untuk teks ini, atau null bila bukan tulisan menu yang dikenal. */
    fun lookup(text: String, userFile: File?): String? {
        val key = fold(text)
        if (key.isEmpty()) return null
        // kamus pribadi dulu (persis)
        for ((k, v) in JaPrep.userRules(userFile)) if (fold(k) == key) return v
        table[key]?.let { return it }
        // toleransi salah baca OCR: 1 huruf untuk kata >= 5 huruf, 2 huruf untuk >= 9 huruf
        val tol = when { key.length >= 9 -> 2; key.length >= 5 -> 1; else -> 0 }
        if (tol == 0) return null
        var best: String? = null
        var bestD = tol + 1
        for ((k, v) in table) {
            if (kotlin.math.abs(k.length - key.length) > tol) continue
            val d = distance(k, key, tol)
            if (d < bestD) { bestD = d; best = v }
        }
        return best
    }

    private fun distance(a: String, b: String, limit: Int): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > limit) return limit + 1
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }
}
