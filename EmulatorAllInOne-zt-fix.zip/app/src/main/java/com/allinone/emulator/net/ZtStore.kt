package com.allinone.emulator.net

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Daftar jaringan ZeroTier yang ditambahkan pemain + pengaturan VPN tertanam. */
object ZtStore {
    data class Net(val id: String, var name: String, var on: Boolean)

    private fun p(c: Context) = c.getSharedPreferences("zerotier", Context.MODE_PRIVATE)

    fun isNetworkId(s: String) = Regex("^[0-9a-f]{16}$").matches(s)

    fun list(c: Context): MutableList<Net> {
        val out = ArrayList<Net>()
        try {
            val a = JSONArray(p(c).getString("networks", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.optString("id")
                if (isNetworkId(id)) out += Net(id, o.optString("name", id), o.optBoolean("on", true))
            }
        } catch (_: Exception) { }
        return out
    }

    fun save(c: Context, l: List<Net>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("on", it.on)) }
        p(c).edit().putString("networks", a.toString()).apply()
    }

    /** Menambah jaringan (atau menghidupkan lagi bila sudah ada). false bila Network ID tidak valid. */
    fun add(c: Context, id: String, name: String): Boolean {
        val nid = id.trim().lowercase()
        if (!isNetworkId(nid)) return false
        val l = list(c)
        val cur = l.firstOrNull { it.id == nid }
        if (cur != null) { cur.on = true; if (name.isNotBlank()) cur.name = name } else l += Net(nid, name.ifBlank { nid }, true)
        save(c, l)
        return true
    }

    fun setOn(c: Context, id: String, on: Boolean) {
        val l = list(c); l.firstOrNull { it.id == id }?.on = on; save(c, l)
    }

    fun remove(c: Context, id: String) = save(c, list(c).filter { it.id != id })

    /** Izinkan ZeroTier berjalan lewat data seluler (bawaan: mati, seperti ZeroTier One). */
    fun allowCellular(c: Context): Boolean = p(c).getBoolean("cellular", false)

    fun setAllowCellular(c: Context, v: Boolean) = p(c).edit().putBoolean("cellular", v).apply()

    fun dataDir(c: Context) = File(c.filesDir, "zerotier")

    /** Node ID milik aplikasi ini (kosong bila ZeroTier tertanam belum pernah dijalankan). */
    fun nodeId(c: Context): String = ZtState.nodeId.ifBlank { ZtEngine.peekNodeId(dataDir(c)) }
}
