package com.allinone.emulator.net;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Penemuan server otomatis lewat siaran (broadcast) di jaringan ZeroTier, tanpa lobby / server perantara.
 *
 * Host mengirim paket UDP kecil ke alamat siaran subnet ZeroTier (mis. 10.102.103.255) tiap beberapa detik;
 * pemain lain di jaringan yang sama menerimanya dan servernya muncul sendiri di daftar Multiplayer Online.
 *
 * Paket dikirim dan diterima LANGSUNG sebagai frame Ethernet lewat mesin ZeroTier (bukan lewat soket Android),
 * karena TUN milik VpnService tidak menjamin siaran subnet sampai ke soket. Frame dikirim sebagai IPv4 biasa
 * (ethertype 0x0800) supaya lolos aturan bawaan jaringan ZeroTier (yang hanya mengizinkan IPv4, ARP, IPv6).
 * Dipisah dari kode Android supaya bisa diuji di komputer (tests/run_ztdiscovery_test.sh).
 */
public final class ZtDiscovery {
    private ZtDiscovery() { }

    /** Port UDP tujuan paket pengumuman (bukan port game 7755; tidak ada soket yang membukanya). */
    public static final int PORT = 7756;
    public static final long INTERVAL_MS = 3_000;
    /** Server dianggap hilang bila tidak terdengar selama ini (± 3 kali interval). */
    public static final long TTL_MS = 10_000;
    private static final int MAX_SERVERS = 64;      // batas supaya anggota jaringan yang iseng tidak bisa membanjiri daftar
    private static final String MAGIC = "AIOSRV1";

    /** Pengumuman milik kita (host). */
    public static final class Announce {
        public final String name, title, console, owner;
        public final int port, max;
        volatile int players = 1;
        Announce(String name, String title, String console, String owner, int port, int max) {
            this.name = clean(name, 40); this.title = clean(title, 80); this.console = clean(console, 24);
            this.owner = clean(owner, 30); this.port = port; this.max = max;
        }
    }

    /** Server milik orang lain yang terdengar di jaringan. */
    public static final class Server {
        public final String host, name, title, console, owner;
        public final int port, players, max;
        public final long seen;
        Server(String host, String name, String title, String console, String owner, int port, int players, int max, long seen) {
            this.host = host; this.name = name; this.title = title; this.console = console; this.owner = owner;
            this.port = port; this.players = players; this.max = max; this.seen = seen;
        }
        public String key() { return host + ":" + port; }
    }

    private static final java.util.concurrent.atomic.AtomicLong sent = new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.atomic.AtomicLong heard = new java.util.concurrent.atomic.AtomicLong();

    /** Berapa kali siaran dikirim oleh kita / berapa paket pengumuman milik orang lain yang terdengar (untuk diagnosis). */
    public static long sentCount() { return sent.get(); }
    public static long heardCount() { return heard.get(); }
    public static void noteSent() { sent.incrementAndGet(); }

    private static volatile Announce mine;
    private static final Map<String, Server> found = new ConcurrentHashMap<>();

    // ------------------------------------------------------------------ sisi host

    public static void announce(String name, String title, String console, String owner, int port, int max) {
        mine = new Announce(name, title, console, owner, port, max);
    }

    public static void setPlayers(int players) {
        Announce a = mine;
        if (a != null) a.players = players;
    }

    public static void stopAnnounce() { mine = null; }

    public static boolean isAnnouncing() { return mine != null; }

    /** Paket IPv4+UDP siap kirim (tujuan = alamat siaran subnet), atau null bila tidak sedang mengumumkan. */
    public static byte[] buildPacket(int srcIp, int prefix) {
        Announce a = mine;
        if (a == null) return null;
        String text = MAGIC + "\n"
            + "name=" + a.name + "\n" + "title=" + a.title + "\n" + "console=" + a.console + "\n"
            + "owner=" + a.owner + "\n" + "port=" + a.port + "\n" + "players=" + a.players + "\n" + "max=" + a.max + "\n";
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        return udpPacket(srcIp, broadcastOf(srcIp, prefix), PORT, PORT, data);
    }

    /** Alamat siaran subnet; untuk prefix di luar 1..31 dipakai 255.255.255.255. */
    public static int broadcastOf(int ip, int prefix) {
        if (prefix <= 0 || prefix >= 32) return -1;
        int mask = -1 << (32 - prefix);
        return ip | ~mask;
    }

    static byte[] udpPacket(int src, int dst, int srcPort, int dstPort, byte[] data) {
        int udpLen = 8 + data.length;
        int total = 20 + udpLen;
        byte[] p = new byte[total];
        p[0] = 0x45;                                   // IPv4, header 20 byte
        p[2] = (byte) (total >> 8); p[3] = (byte) total;
        p[6] = 0x40;                                   // Don't Fragment
        p[8] = 64;                                     // TTL
        p[9] = 17;                                     // UDP
        putInt(p, 12, src); putInt(p, 16, dst);
        int sum = 0;
        for (int i = 0; i < 20; i += 2) sum += ((p[i] & 0xff) << 8) | (p[i + 1] & 0xff);
        while ((sum >>> 16) != 0) sum = (sum & 0xffff) + (sum >>> 16);
        int ck = ~sum & 0xffff;
        p[10] = (byte) (ck >> 8); p[11] = (byte) ck;
        p[20] = (byte) (srcPort >> 8); p[21] = (byte) srcPort;
        p[22] = (byte) (dstPort >> 8); p[23] = (byte) dstPort;
        p[24] = (byte) (udpLen >> 8); p[25] = (byte) udpLen;   // checksum UDP 0 = tidak dipakai (sah di IPv4)
        System.arraycopy(data, 0, p, 28, data.length);
        return p;
    }

    // ------------------------------------------------------------------ sisi pemain

    /**
     * Dipanggil untuk setiap frame IPv4 yang masuk dari jaringan. True bila frame itu paket pengumuman kita
     * (dipakai habis di sini, tidak diteruskan ke TUN); false bila bukan.
     */
    public static boolean handle(byte[] f, int ownIp, long now) {
        if (f == null || f.length < 28 || (f[0] >> 4) != 4) return false;
        int ihl = (f[0] & 0x0f) * 4;
        if (ihl < 20 || f.length < ihl + 8 || (f[9] & 0xff) != 17) return false;
        int dport = ((f[ihl + 2] & 0xff) << 8) | (f[ihl + 3] & 0xff);
        if (dport != PORT) return false;
        int udpLen = ((f[ihl + 4] & 0xff) << 8) | (f[ihl + 5] & 0xff);
        int end = Math.min(f.length, ihl + udpLen);
        if (udpLen < 8 || end <= ihl + 8) return true;           // paket kita tapi rusak: buang
        int src = getInt(f, 12);
        if (src == ownIp || src == 0) return true;                // gema dari diri sendiri
        String[] lines = new String(f, ihl + 8, end - ihl - 8, StandardCharsets.UTF_8).split("\n");
        if (lines.length == 0 || !MAGIC.equals(lines[0])) return false;
        String name = "", title = "", console = "", owner = "";
        int port = 0, players = 1, max = 2;
        for (int i = 1; i < lines.length; i++) {
            int eq = lines[i].indexOf('=');
            if (eq <= 0) continue;
            String k = lines[i].substring(0, eq), v = lines[i].substring(eq + 1);
            switch (k) {
                case "name": name = clean(v, 40); break;
                case "title": title = clean(v, 80); break;
                case "console": console = clean(v, 24); break;
                case "owner": owner = clean(v, 30); break;
                case "port": port = toInt(v, 0); break;
                case "players": players = toInt(v, 1); break;
                case "max": max = toInt(v, 2); break;
                default: break;
            }
        }
        if (port < 1 || port > 65535 || title.isEmpty() || console.isEmpty()) return true;
        max = Math.max(1, Math.min(max, 8));
        players = Math.max(0, Math.min(players, max));
        heard.incrementAndGet();
        Server s = new Server(ipStr(src), name.isEmpty() ? title : name, title, console, owner, port, players, max, now);
        if (found.size() >= MAX_SERVERS && !found.containsKey(s.key())) return true;
        found.put(s.key(), s);
        return true;
    }

    /** Server yang masih terdengar, urut nama. */
    public static List<Server> servers(long now) {
        List<Server> out = new ArrayList<>();
        for (Iterator<Server> it = found.values().iterator(); it.hasNext(); ) {
            Server s = it.next();
            if (now - s.seen > TTL_MS) it.remove(); else out.add(s);
        }
        Collections.sort(out, new Comparator<Server>() {
            @Override public int compare(Server a, Server b) { return a.name.compareToIgnoreCase(b.name); }
        });
        return out;
    }

    public static void clearFound() { found.clear(); }

    // ------------------------------------------------------------------ util

    private static String clean(String s, int max) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    private static int toInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }

    private static void putInt(byte[] b, int off, int v) {
        b[off] = (byte) (v >>> 24); b[off + 1] = (byte) (v >>> 16); b[off + 2] = (byte) (v >>> 8); b[off + 3] = (byte) v;
    }

    private static int getInt(byte[] b, int off) {
        return ((b[off] & 0xff) << 24) | ((b[off + 1] & 0xff) << 16) | ((b[off + 2] & 0xff) << 8) | (b[off + 3] & 0xff);
    }

    public static String ipStr(int ip) {
        return (ip >>> 24) + "." + ((ip >> 16) & 255) + "." + ((ip >> 8) & 255) + "." + (ip & 255);
    }
}
