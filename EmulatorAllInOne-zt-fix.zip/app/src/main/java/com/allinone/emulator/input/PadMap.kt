package com.allinone.emulator.input

import android.content.Context
import android.view.KeyEvent
import com.allinone.emulator.data.Console

/**
 * Pemetaan tombol controller eksternal (per sistem) beserta kombo.
 *
 * Satu tombol fisik bisa dipasang ke SATU tombol game (pemetaan ulang) atau ke BEBERAPA tombol game sekaligus (kombo:
 * semua ditekan serentak, dilepas serentak). Tombol fisik yang dipasang tidak lagi diteruskan apa adanya; tombol yang
 * tidak dipasang tetap diteruskan seperti biasa. Pintasan aplikasi ([KeyMap]) didahulukan.
 *
 * Disimpan sebagai token (nama tombol di tata letak layar, mis. "A+B"), bukan kode tombol, supaya tetap benar bila
 * tabel kode diubah. Tabel token di bawah HARUS sama dengan tabel di VirtualPadView (tata letak layar tiap sistem).
 * Arah D-pad yang dilaporkan sebagai sumbu (hat) bukan tombol, jadi tidak bisa dipetakan ulang; tombol arah sebagai
 * tujuan (kombo) tetap bisa.
 */
object PadMap {
    /** Naik tiap ada perubahan: activity memuat ulang pemetaan bila angka ini berubah. */
    @Volatile var version = 0
        private set

    val GROUPS = listOf("GBA", "SNES", "GENESIS", "ARCADE")

    fun group(c: Console): String = if (c.isArcade) "ARCADE" else if (c.isNds) "NDS" else c.name

    fun groupLabel(g: String) = when (g) {
        "GBA" -> "Game Boy Advance"
        "SNES" -> "Super Nintendo (SNES)"
        "GENESIS" -> "Sega Genesis / Mega Drive"
        else -> "Arcade (MAME / FBNeo)"
    }

    private val ARROWS = mapOf(
        "↑" to KeyEvent.KEYCODE_DPAD_UP, "↓" to KeyEvent.KEYCODE_DPAD_DOWN,
        "←" to KeyEvent.KEYCODE_DPAD_LEFT, "→" to KeyEvent.KEYCODE_DPAD_RIGHT
    )

    private val GBA_KEYS = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_A, "B" to KeyEvent.KEYCODE_BUTTON_B,
        "L" to KeyEvent.KEYCODE_BUTTON_L1, "R" to KeyEvent.KEYCODE_BUTTON_R1,
        "SEL" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START
    ) + ARROWS

    private val SNES_KEYS = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_A, "B" to KeyEvent.KEYCODE_BUTTON_B,
        "X" to KeyEvent.KEYCODE_BUTTON_X, "Y" to KeyEvent.KEYCODE_BUTTON_Y,
        "L" to KeyEvent.KEYCODE_BUTTON_L1, "R" to KeyEvent.KEYCODE_BUTTON_R1,
        "SELECT" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START
    ) + ARROWS

    private val GENESIS_KEYS = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_Y, "B" to KeyEvent.KEYCODE_BUTTON_B, "C" to KeyEvent.KEYCODE_BUTTON_A,
        "X" to KeyEvent.KEYCODE_BUTTON_L1, "Y" to KeyEvent.KEYCODE_BUTTON_X, "Z" to KeyEvent.KEYCODE_BUTTON_R1,
        "MODE" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START
    ) + ARROWS

    private val ARCADE_KEYS = mapOf(
        "A" to KeyEvent.KEYCODE_BUTTON_B, "B" to KeyEvent.KEYCODE_BUTTON_A, "C" to KeyEvent.KEYCODE_BUTTON_R1,
        "X" to KeyEvent.KEYCODE_BUTTON_Y, "Y" to KeyEvent.KEYCODE_BUTTON_X, "Z" to KeyEvent.KEYCODE_BUTTON_L1,
        "KOIN" to KeyEvent.KEYCODE_BUTTON_SELECT, "START" to KeyEvent.KEYCODE_BUTTON_START
    ) + ARROWS

    /** Token tombol game yang bisa dipilih sebagai tujuan, berurutan seperti tata letak layar. */
    fun tokens(g: String): List<String> = when (g) {
        "GBA" -> VirtualPadView.GBA_COMBO_KEYS
        "SNES" -> VirtualPadView.SNES_COMBO_KEYS
        "GENESIS" -> VirtualPadView.GENESIS_COMBO_KEYS
        else -> VirtualPadView.ARCADE_COMBO_KEYS
    }

    private fun table(g: String) = when (g) {
        "GBA" -> GBA_KEYS
        "SNES" -> SNES_KEYS
        "GENESIS" -> GENESIS_KEYS
        else -> ARCADE_KEYS
    }

    private fun p(c: Context) = c.applicationContext.getSharedPreferences("padmap", Context.MODE_PRIVATE)

    /** Daftar pemetaan satu sistem: (kode tombol fisik, isi "A+B"). */
    fun entries(c: Context, g: String): List<Pair<Int, String>> =
        p(c).all.mapNotNull { (k, v) ->
            if (!k.startsWith("$g:") || v !is String) null
            else k.substringAfter(':').toIntOrNull()?.let { it to v }
        }.sortedBy { it.first }

    /** Isi pemetaan tombol fisik [phys], atau null bila belum dipasang. */
    fun specFor(c: Context, g: String, phys: Int): String? = p(c).getString("$g:$phys", null)

    /** Pasang [phys] ke token [spec] ("A" = pemetaan ulang, "A+B" = kombo). Kosong/tak valid = hapus. */
    fun set(c: Context, g: String, phys: Int, spec: String) {
        val clean = spec.split('+').map { it.trim() }.filter { it in table(g) }.distinct().joinToString("+")
        if (clean.isEmpty()) remove(c, g, phys) else { p(c).edit().putString("$g:$phys", clean).apply(); version++ }
    }

    fun remove(c: Context, g: String, phys: Int) { p(c).edit().remove("$g:$phys").apply(); version++ }

    fun clear(c: Context, g: String) {
        val e = p(c).edit()
        p(c).all.keys.filter { it.startsWith("$g:") }.forEach { e.remove(it) }
        e.apply(); version++
    }

    /** Kode tombol game (libretro) untuk token [token], atau null bila tidak ada. */
    fun gameKey(g: String, token: String): Int? = table(g)[token]

    /**
     * Tombol fisik bawaan yang menekan token [token]. Genesis: fungsi Y di controller ditukar, dan tombol fisik X
     * dan A saling tukar (fisik A = Genesis A, fisik X = Genesis C).
     */
    private fun defaultPhys(g: String, token: String): Int? {
        if (g == "GENESIS") when (token) {
            "A" -> return KeyEvent.KEYCODE_BUTTON_A
            "C" -> return KeyEvent.KEYCODE_BUTTON_X
            "Y" -> return KeyEvent.KEYCODE_BUTTON_Y
        }
        return table(g)[token]
    }

    /**
     * Pasang tombol fisik [phys] ke satu tombol game [token] (pemetaan ulang). Pemetaan tunggal lain untuk token yang
     * sama dihapus, jadi tiap tombol game hanya punya satu tombol fisik buatan pengguna. Tombol fisik bawaan token
     * itu otomatis tidak lagi menekannya (lihat [load]).
     */
    fun bindToken(c: Context, g: String, token: String, phys: Int) {
        entries(c, g).filter { it.second == token && it.first != phys }.forEach { remove(c, g, it.first) }
        set(c, g, phys, token)
    }

    /** Kembalikan tombol game [token] ke bawaan: hapus pemetaan tunggal buatan pengguna untuk token itu. */
    fun resetToken(c: Context, g: String, token: String) {
        entries(c, g).filter { it.second == token }.forEach { remove(c, g, it.first) }
    }

    /** Tombol fisik yang sekarang menekan token [token] (untuk ditampilkan), berdasarkan pemetaan hasil [load]. */
    fun physFor(c: Context, g: String, token: String): List<Int> {
        val key = table(g)[token] ?: return emptyList()
        return load(c, g).filter { (_, targets) -> key in targets }.keys.sorted()
    }

    /**
     * Pemetaan siap pakai untuk satu sistem: kode tombol fisik -> kode tombol game. Berisi pemetaan bawaan semua
     * tombol game, lalu ditimpa pemetaan buatan pengguna. Array kosong = tombol fisik itu tidak menekan apa pun.
     */
    fun load(c: Context, g: String): Map<Int, IntArray> {
        val t = table(g)
        val out = HashMap<Int, IntArray>()
        for ((tok, key) in t) defaultPhys(g, tok)?.let { out[it] = intArrayOf(key) }
        val custom = entries(c, g)
        val customKeys = custom.map { it.first }.toSet()
        for ((phys, spec) in custom) {
            val toks = spec.split('+').map { it.trim() }.filter { it in t }.distinct()
            val keys = toks.mapNotNull { t[it] }.distinct()
            if (keys.isEmpty()) continue
            out[phys] = keys.toIntArray()
            // Token yang dipasang ke tombol lain: tombol bawaannya tidak lagi menekan token itu
            if (toks.size == 1) {
                val d = defaultPhys(g, toks[0])
                if (d != null && d != phys && d !in customKeys) out[d] = intArrayOf()
            }
        }
        return out
    }

    /**
     * Penerus tombol: meneruskan tekan/lepas tombol fisik ke tombol game sesuai pemetaan. Tombol game yang ditahan oleh
     * lebih dari satu tombol fisik baru dilepas setelah semuanya dilepas. Yang dilepas mengikuti catatan saat ditekan,
     * jadi mengubah pemetaan saat tombol sedang ditahan tidak membuat tombol game tersangkut.
     */
    class Router(private val send: (action: Int, key: Int, port: Int) -> Unit) {
        private class Held(val port: Int, val targets: IntArray)
        private val held = HashMap<Long, Held>()
        private val count = HashMap<Long, Int>()

        private fun id(a: Int, b: Int) = (a.toLong() shl 32) or (b.toLong() and 0xFFFFFFFFL)

        fun handle(action: Int, deviceId: Int, phys: Int, port: Int, map: Map<Int, IntArray>) {
            val hk = id(deviceId, phys)
            if (action == KeyEvent.ACTION_DOWN) {
                if (held.containsKey(hk)) return
                val targets = map[phys] ?: intArrayOf(phys)
                held[hk] = Held(port, targets)
                for (t in targets) {
                    val ck = id(port, t)
                    val n = count[ck] ?: 0
                    count[ck] = n + 1
                    if (n == 0) send(KeyEvent.ACTION_DOWN, t, port)
                }
            } else if (action == KeyEvent.ACTION_UP) {
                val h = held.remove(hk) ?: Held(port, map[phys] ?: intArrayOf(phys))
                for (t in h.targets) {
                    val ck = id(h.port, t)
                    val n = (count[ck] ?: 0) - 1
                    if (n <= 0) { count.remove(ck); send(KeyEvent.ACTION_UP, t, h.port) } else count[ck] = n
                }
            }
        }
    }
}
