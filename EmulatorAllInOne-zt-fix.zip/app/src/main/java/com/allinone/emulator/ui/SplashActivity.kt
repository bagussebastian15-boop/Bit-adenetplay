package com.allinone.emulator.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.allinone.emulator.R

/** Layar pembuka: logo Bit©ade tampil 3 detik, lalu lanjut ke perpustakaan game. */
class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val goNext = Runnable {
        startActivity(Intent(this, LibraryActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(ImageView(this@SplashActivity).apply {
                setImageResource(R.drawable.splash_logo)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(pad, pad, pad, pad)
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        })
        // Activity ini terkunci landscape; bila sempat dibuat ulang, jadwal lama sudah dibatalkan di onDestroy, jadi pasang lagi
        handler.postDelayed(goNext, 3000L)
    }

    override fun onDestroy() {
        handler.removeCallbacks(goNext)
        super.onDestroy()
    }
}
