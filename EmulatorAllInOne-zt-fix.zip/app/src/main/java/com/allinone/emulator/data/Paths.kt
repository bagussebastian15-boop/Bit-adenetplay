package com.allinone.emulator.data

import android.content.Context
import java.io.File

/** Semua data ada di folder app (Android/data/<paket>/files), tanpa izin penyimpanan khusus. */
object Paths {
    private fun root(c: Context): File = c.getExternalFilesDir(null) ?: c.filesDir
    private fun dir(c: Context, name: String) = File(root(c), name).apply { mkdirs() }

    fun roms(c: Context, console: Console) = dir(c, "roms/${console.name.lowercase()}")
    fun system(c: Context) = dir(c, "system")   // BIOS
    fun saves(c: Context) = dir(c, "saves")
    fun states(c: Context) = dir(c, "states")
    fun cheats(c: Context) = dir(c, "cheats")
    fun glossaryJa(c: Context) = File(root(c), "glosarium_ja.txt")   // glosarium Jepang pribadi (jepang=padanan)
    fun glyphBank(c: Context) = File(root(c), "font_bank.txt")   // tabel bentuk huruf font game yang dipelajari otomatis
    fun glossary(c: Context) = File(root(c), "slang_user.txt")   // kamus slang pribadi (slang=padanan baku)
}
