package com.allinone.emulator.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.LobbyApi
import com.allinone.emulator.data.RomLibrary
import com.allinone.emulator.data.Settings
import com.allinone.emulator.net.ZtDiscovery
import com.allinone.emulator.net.ZtEngine
import com.allinone.emulator.net.ZtState
import com.allinone.emulator.net.ZtStore
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Menu "Multiplayer Online": daftar server resmi (dari lobby) + server buatan pemain, tombol Gabung.
 * Daftar hanya menunjukkan ALAMAT; permainannya tetap peer-to-peer lewat netplay rollback.
 */
class LobbyActivity : AppCompatActivity() {

    private sealed class Item {
        data class Header(val text: String) : Item()
        data class Row(val room: LobbyApi.Room) : Item()
        data class Net(val net: LobbyApi.Network) : Item()
        /** Pemain lain di jaringan ZeroTier. serverKey != null = sedang host (ketuk = gabung); null = belum main (ketuk = ajak main). */
        data class Player(val ip: String, val name: String, val info: String, val serverKey: String?) : Item()
    }

    private lateinit var settings: Settings
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var items: List<Item> = emptyList()
    private var loading = false
    private var listing: LobbyApi.Listing? = null     // hasil terakhir dari lobby (null = belum ada / gagal)
    private var statusMsg = ""
    private val ui = Handler(Looper.getMainLooper())
    // Server di jaringan ZeroTier terdengar lewat siaran, jadi daftar disegarkan sendiri tiap 2 detik
    private val tick = object : Runnable {
        override fun run() { rebuild(); checkInvites(); ui.postDelayed(this, 2000) }
    }
    private val seenInvites = HashSet<String>()      // ajakan yang sudah ditampilkan (kunci server), supaya tidak muncul berulang
    private var inviteDialog: AlertDialog? = null
    private lateinit var approvalBtn: Button
    private var waitingNode = false   // true setelah membuka ZeroTier One untuk menyalin Node ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "Multiplayer Online"; textSize = 18f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply { text = "Buat server"; setOnClickListener { createServer() } })
        bar.addView(Button(this).apply { text = "Segarkan"; setOnClickListener { load() } })
        bar.addView(Button(this).apply { text = "ZeroTier"; setOnClickListener { startActivity(Intent(this@LobbyActivity, ZeroTierActivity::class.java)) } })
        approvalBtn = Button(this).apply { text = "Persetujuan"; setOnClickListener { approvals() } }
        bar.addView(approvalBtn)
        bar.addView(Button(this).apply { text = "Atur"; setOnClickListener { settingsDialog() } })

        list = ListView(this)
        status = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val body = FrameLayout(this)
        body.addView(list)
        body.addView(status, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)

        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            when (val it = items.getOrNull(pos)) {
                is Item.Row -> showRoom(it.room)
                is Item.Net -> showNetwork(it.net)
                is Item.Player -> onPlayer(it)
                else -> {}
            }
        }
    }

    override fun onResume() {
        super.onResume()
        approvalBtn.visibility = if (settings.adminKey.isBlank()) View.GONE else View.VISIBLE
        if (settings.lobbyUrl.isBlank()) {
            showStatus("Alamat lobby server belum diisi.\nTekan \"Atur\" lalu isi alamatnya.\n\nTombol Buat Server tetap bisa dipakai tanpa alamat lobby. Server di jaringan ZeroTier yang sama tampil otomatis di sini; di luar itu, bagikan IP-nya langsung ke teman.")
        } else load()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    // ---------------------------------------------------------------- daftar server

    private fun load() {
        val url = settings.lobbyUrl
        if (url.isBlank()) { settingsDialog(); return }
        if (loading) return
        loading = true
        listing = null
        showStatus("Memuat daftar server…")
        Thread {
            val res = try { Result.success(LobbyApi.list(url)) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                loading = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                res.onSuccess { showListing(it) }
                res.onFailure {
                    listing = null
                    showStatus("Tidak bisa memuat daftar server.\n${it.message ?: it.javaClass.simpleName}\n\nCek alamat lobby (tombol Atur) dan koneksi internet.")
                }
            }
        }.start()
    }

    private fun showListing(l: LobbyApi.Listing) {
        listing = l
        rebuild()
    }

    /**
     * Susun ulang daftar: server di jaringan ZeroTier (otomatis, dari siaran) + daftar lobby.
     * Dipanggil saat lobby selesai dimuat dan tiap 2 detik; daftar hanya digambar ulang bila isinya berubah.
     */
    private fun rebuild() {
        if (loading) return
        val l = listing
        val lan = ZtDiscovery.servers(System.currentTimeMillis())
            .filter { s -> l == null || (l.official + l.rooms).none { it.host == s.host && it.port == s.port } }   // yang sudah ada di lobby tidak dobel
            .map { lanRoom(it) }
        if (l == null && lan.isEmpty() && !ZtState.running) {
            if (list.visibility == View.VISIBLE && items.isNotEmpty() && statusMsg.isNotEmpty()) showStatus(statusMsg)   // server terakhir hilang
            return
        }
        val out = ArrayList<Item>()
        if (ZtState.running) {
            val now = System.currentTimeMillis()
            val servers = ZtDiscovery.servers(now)
            val players = ZtDiscovery.players(now)
            out += Item.Header("Pemain di jaringan ZeroTier (${players.size})")
            if (players.isEmpty()) out += Item.Header(lanDiag()) else players.forEach { p ->
                val sv = servers.firstOrNull { it.host == p.ip }
                val info = when {
                    sv == null -> "${p.ip} · online, belum main · ketuk untuk ajak main"
                    sv.invite.isNotEmpty() && sv.invite == ZtState.firstIp() -> "${p.ip} · MENGAJAK ANDA: ${sv.title} · ketuk untuk gabung"
                    else -> "${p.ip} · host: ${sv.title} (${sv.players}/${sv.max}) · ketuk untuk gabung"
                }
                out += Item.Player(p.ip, p.name, info, sv?.key())
            }
        }
        if (lan.isNotEmpty()) {
            out += Item.Header("Server di jaringan ZeroTier (otomatis)")
            lan.forEach { out += Item.Row(it) }
        }
        if (l != null) {
            out += Item.Header("Server resmi")
            if (l.official.isEmpty()) out += Item.Header("   (belum ada)") else l.official.forEach { out += Item.Row(it) }
            if (l.networks.isNotEmpty()) {
                out += Item.Header("Jaringan ZeroTier (masuk dengan persetujuan pemilik)")
                l.networks.forEach { out += Item.Net(it) }
            }
            out += Item.Header("Server pemain")
            if (l.rooms.isEmpty()) out += Item.Header("   (belum ada — tekan \"Buat server\")") else l.rooms.forEach { out += Item.Row(it) }
        }
        if (out == items && status.visibility == View.GONE) return
        items = out
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        status.visibility = View.GONE
        list.visibility = View.VISIBLE
    }

    /** Keterangan saat belum ada server: bantu menebak di mana siaran macet. */
    private fun lanDiag(): String {
        val ip = ZtState.firstIp() ?: return "   (${noIpReason()})"
        val peers = com.allinone.emulator.net.ZeroTierVpnService.instance?.peerInfo()
        return "   (mencari pemain lain… IP Anda $ip · frame masuk ${ZtState.framesIn} · siaran diterima ${ZtDiscovery.heardCount()}" +
            (if (peers != null) " · $peers" else "") + "). " +
            "Pastikan HP teman juga menyalakan ZeroTier di aplikasi ini, Node ID HP teman juga sudah di-Auth, dan jaringan mengaktifkan Enable Broadcast."
    }

    /** Alasan sebenarnya HP ini belum punya IP ZeroTier, dari status jaringan yang dilaporkan mesin (bukan tebakan tunggal). */
    private fun noIpReason(): String {
        val node = ZtStore.nodeId(this).ifBlank { "(belum dibuat)" }
        val nets = ZtState.nets.values.toList()
        val sb = StringBuilder()
        if (!ZtState.online) sb.append("ZeroTier OFFLINE: HP ini belum terhubung ke server ZeroTier (cek internet/Wi-Fi). ")
        if (nets.isEmpty()) {
            sb.append("Belum ada jaringan yang dinyalakan. Ketuk ZEROTIER lalu tambah/nyalakan jaringan.")
        } else for (n in nets) {
            sb.append(when (n.status) {
                "ACCESS_DENIED" -> "Jaringan \"${n.name}\": Node ID HP INI ($node) BELUM di-Auth. Tiap HP punya Node ID sendiri: centang Auth untuk $node di my.zerotier.com, lalu tunggu ±1 menit. "
                "NOT_FOUND" -> "Jaringan \"${n.name}\": Network ID tidak ditemukan, cek Network ID-nya. "
                "REQUESTING_CONFIGURATION" -> "Jaringan \"${n.name}\": meminta konfigurasi. Bila lebih dari 1 menit, cek Auth untuk Node ID $node. "
                "OK" -> "Jaringan \"${n.name}\": tersambung tapi tidak ada IPv4. Aktifkan IPv4 Auto-Assign (Easy Setup / Auto-Assign from Range) di pengaturan jaringan. "
                else -> "Jaringan \"${n.name}\": status ${n.status}. "
            })
        }
        if (ZtState.error.isNotEmpty()) sb.append(ZtState.error).append(' ')
        if (ZtState.lastLog.isNotEmpty()) sb.append("Log mesin: ").append(ZtState.lastLog)
        return sb.toString().trim()
    }

    private fun lanRoom(s: ZtDiscovery.Server) = LobbyApi.Room(
        id = "lan:${s.key()}", name = s.name, host = s.host, port = s.port,
        title = s.title, console = s.console, players = s.players, maxPlayers = s.max,
        official = false, note = "Ditemukan otomatis lewat siaran jaringan ZeroTier.", owner = s.owner,
        online = true, net = "zerotier"
    )

    private fun showStatus(msg: String) {
        statusMsg = msg
        items = emptyList()
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (items[position] is Item.Header) 0 else 1
        override fun isEnabled(position: Int) = items[position] !is Item.Header

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return when (val it = items[position]) {
                is Item.Header -> ((convertView as? TextView) ?: TextView(this@LobbyActivity).apply {
                    setTypeface(typeface, Typeface.BOLD)
                    textSize = 14f
                    setPadding(dp(16), dp(10), dp(16), dp(6))
                    setBackgroundColor(0x22888888)
                }).also { v -> v.text = it.text }
                is Item.Player -> {
                    val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                    v.findViewById<TextView>(android.R.id.text1).text = (if (it.serverKey != null) "🎮 " else "● ") + it.name
                    v.findViewById<TextView>(android.R.id.text2).text = it.info
                    v
                }
                is Item.Net -> {
                    val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                    v.findViewById<TextView>(android.R.id.text1).text = "${it.net.name}  [ZeroTier]"
                    v.findViewById<TextView>(android.R.id.text2).text = "Network ID ${it.net.id} · ketuk untuk minta akses"
                    v
                }
                is Item.Row -> {
                    val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                    val r = it.room
                    v.findViewById<TextView>(android.R.id.text1).text =
                        (if (r.official) "★ " else "") + r.name + netBadge(r.net) + (if (!r.online) "  (offline)" else if (r.full) "  (penuh)" else "")
                    val label = consoleOrNull(r.console)?.label ?: r.console
                    v.findViewById<TextView>(android.R.id.text2).text =
                        "${r.title} · $label · ${r.players}/${r.maxPlayers} pemain" +
                            (if (r.owner.isNotBlank()) " · ${r.owner}" else "")
                    v
                }
            }
        }
    }

    // ---------------------------------------------------------------- pemain di jaringan

    private fun onPlayer(p: Item.Player) {
        val sv = p.serverKey?.let { k -> ZtDiscovery.servers(System.currentTimeMillis()).firstOrNull { it.key() == k } }
        if (sv != null) { showRoom(lanRoom(sv)); return }
        AlertDialog.Builder(this)
            .setTitle("Ajak ${p.name} main")
            .setMessage("${p.name} (${p.ip}) sedang online di jaringan ZeroTier yang sama.\n\n" +
                "Pilih game: server dibuat otomatis dan ${p.name} langsung mendapat ajakan di layar Multiplayer Online. " +
                "${p.name} harus punya game yang sama di library.")
            .setPositiveButton("Pilih game") { _, _ -> createServer(p.ip) }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Ada pemain yang mengajak kita (server dengan invite = IP ZeroTier kita): tawarkan gabung sekali per server. */
    private fun checkInvites() {
        val me = ZtState.firstIp() ?: return
        if (inviteDialog?.isShowing == true || isFinishing || isDestroyed) return
        val sv = ZtDiscovery.servers(System.currentTimeMillis())
            .firstOrNull { it.invite == me && it.players < it.max && seenInvites.add(it.key()) } ?: return
        val who = sv.owner.ifBlank { sv.host }
        inviteDialog = AlertDialog.Builder(this)
            .setTitle("$who mengajak main")
            .setMessage("${sv.title}\n\nGabung sekarang?")
            .setPositiveButton("Gabung") { _, _ -> join(lanRoom(sv)) }
            .setNegativeButton("Nanti", null)
            .show()
    }

    // ---------------------------------------------------------------- gabung

    private fun showRoom(r: LobbyApi.Room) {
        val label = consoleOrNull(r.console)?.label ?: r.console
        val msg = buildString {
            append("Game: ${r.title}\nKonsol: $label\nPemain: ${r.players}/${r.maxPlayers}\nAlamat: ${r.host}:${r.port}")
            if (r.owner.isNotBlank()) append("\nDibuat oleh: ${r.owner}")
            if (r.note.isNotBlank()) append("\n\n${r.note}")
            append("\n\nAnda harus punya game yang sama persis (nama file dan ROM sama) di library.")
        }
        val b = AlertDialog.Builder(this).setTitle(r.name).setMessage(msg).setNegativeButton("Batal", null)
        when {
            !r.online -> b.setPositiveButton("Offline", null)
            r.full -> b.setPositiveButton("Penuh", null)
            else -> b.setPositiveButton("Gabung") { _, _ -> join(r) }
        }
        b.show()
    }

    private fun consoleOrNull(name: String): Console? = Console.values().firstOrNull { it.name == name }

    private fun coreExists(c: Console) = File(applicationInfo.nativeLibraryDir, c.core).exists()

    private fun join(r: LobbyApi.Room) {
        val console = consoleOrNull(r.console)
        if (console == null || r.title.isBlank() || r.host.isBlank()) {
            Toast.makeText(this, "Data server ini tidak lengkap atau butuh aplikasi versi lebih baru.", Toast.LENGTH_LONG).show()
            return
        }
        if (!coreExists(console)) {
            Toast.makeText(this, "Core ${console.label} belum ada di APK ini.", Toast.LENGTH_LONG).show()
            return
        }
        // Cocokkan game dengan library pemain: nama sama, konsol sama (semua jenis arcade dianggap satu kelompok; core tetap ikut server)
        val mine = RomLibrary.list(this).firstOrNull {
            it.title.equals(r.title, ignoreCase = true) && (it.console == console || (it.console.isArcade && console.isArcade))
        }
        if (mine == null) {
            AlertDialog.Builder(this)
                .setTitle("Game belum ada di library")
                .setMessage("Server ini memainkan \"${r.title}\" (${console.label}).\n\nImpor ROM yang sama ke library Anda, lalu coba gabung lagi.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        launchEmulator(Game(mine.file, console)) {
            putExtra(EmulatorActivity.EXTRA_NP_MODE, "join")
            putExtra(EmulatorActivity.EXTRA_NP_IP, r.host)
            putExtra(EmulatorActivity.EXTRA_NP_PORT, r.port)
        }
    }

    private fun launchEmulator(g: Game, extras: Intent.() -> Unit) {
        getSharedPreferences("crash", MODE_PRIVATE).edit()
            .putString("lastGame", "${g.file.name} (${g.console.label}) [multiplayer]").apply()
        startActivity(
            Intent(this, EmulatorActivity::class.java)
                .putExtra(EmulatorActivity.EXTRA_ROM, g.file.absolutePath)
                .putExtra(EmulatorActivity.EXTRA_CONSOLE, g.console.name)
                .apply(extras)
        )
    }

    // ---------------------------------------------------------------- buat server

    private fun createServer(invite: String = "") {
        // Alamat lobby tidak wajib: tanpa alamat, server tetap jalan (langsung via IP) hanya tidak tampil di daftar.
        val games = RomLibrary.list(this)
        if (games.isEmpty()) {
            Toast.makeText(this, "Library masih kosong. Impor ROM dulu di menu awal.", Toast.LENGTH_LONG).show()
            return
        }
        val labels = games.map { "${it.title} (${it.console.label})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih game untuk server Anda")
            .setItems(labels) { _, i -> serverForm(games[i], invite) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun serverForm(g: Game, invite: String = "") {
        val name = EditText(this).apply {
            hint = "Nama server"
            setSingleLine(true)
            setText("${settings.playerName} - ${g.title}".take(40))
        }
        val ip = EditText(this).apply {
            hint = "IP VPN/LAN (kosongkan = otomatis)"
            setSingleLine(true)
            setText(autoHostIp().first)
        }
        val vpnSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@LobbyActivity, android.R.layout.simple_spinner_dropdown_item, vpnLabels)
            setSelection(autoHostIp().second)
        }
        val delays = arrayOf(
            "1 frame (koneksi sangat bagus)", "2 frame (bawaan, Wi-Fi/LAN)", "3 frame (internet stabil)",
            "4 frame (kurang stabil)", "5 frame (VPN, disarankan)", "6 frame (ping tinggi)"
        )
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@LobbyActivity, android.R.layout.simple_spinner_dropdown_item, delays)
            setSelection(1)
        }
        val note = TextView(this).apply {
            textSize = 12f
            text = "Lewat internet: buka port ${NetplayUi.PORT} (TCP + UDP) di router, atau pakai VPN (ZeroTier/Tailscale) lalu isi IP VPN di atas dan pilih jenis VPN-nya agar server diberi tanda di daftar. " +
                "Server hanya tampil di daftar bila alamat lobby sudah diisi (tombol Atur) dan port terjangkau; tanpa itu, bagikan IP yang tampil di layar game ke teman Anda."
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(name); addView(ip); addView(vpnSpin); addView(spin); addView(note)
        }
        AlertDialog.Builder(this)
            .setTitle("Buat server: ${g.title}")
            .setView(box)
            .setPositiveButton("Mulai") { _, _ ->
                val room = name.text.toString().trim().ifBlank { g.title }.take(40)
                // Simpan otomatis ke pengaturan multiplayer supaya host berikutnya tidak perlu mengisi lagi.
                ip.text.toString().trim().let { settings.vpnIp = it }
                settings.vpnType = vpnSpin.selectedItemPosition
                launchEmulator(g) {
                    putExtra(EmulatorActivity.EXTRA_NP_MODE, "host")
                    putExtra(EmulatorActivity.EXTRA_NP_ROOM, room)
                    putExtra(EmulatorActivity.EXTRA_NP_DELAY, spin.selectedItemPosition + 1)
                    putExtra(EmulatorActivity.EXTRA_NP_PUBLIC_IP, ip.text.toString().trim())
                    putExtra(EmulatorActivity.EXTRA_NP_INVITE, invite)
                    putExtra(EmulatorActivity.EXTRA_NP_VPN,
                        when (vpnSpin.selectedItemPosition) { 1 -> "zerotier"; 2 -> "tailscale"; else -> "" })
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------------------------------------------------------------- pengaturan

    private fun settingsDialog() {
        val url = EditText(this).apply {
            hint = "Alamat lobby, mis. http://123.45.67.89:8080"
            setSingleLine(true)
            setText(settings.lobbyUrl)
        }
        val nick = EditText(this).apply {
            hint = "Nama pemain"
            setSingleLine(true)
            setText(settings.playerName)
        }
        val node = EditText(this).apply {
            hint = if (ZtEngine.available()) "Node ID (otomatis dari ZeroTier aplikasi)" else "Node ID ZeroTier One (10 karakter)"
            setSingleLine(true)
            setText(settings.zeroNodeId)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(url); addView(nick); addView(node)
        }
        AlertDialog.Builder(this)
            .setTitle("Pengaturan Multiplayer Online")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                settings.lobbyUrl = url.text.toString()
                settings.playerName = nick.text.toString()
                val n = node.text.toString().trim().lowercase()
                if (n.isEmpty() || nodeRegex.matches(n)) settings.zeroNodeId = n
                else Toast.makeText(this, "Node ID harus 10 karakter heksadesimal (0-9, a-f); tidak disimpan", Toast.LENGTH_LONG).show()
                load()
            }
            .setNeutralButton(if (ZtEngine.available()) "Pakai ZeroTier aplikasi" else "Ambil dari ZeroTier One") { _, _ ->
                settings.lobbyUrl = url.text.toString()
                settings.playerName = nick.text.toString()
                fetchNodeId()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------------------------------------------------------------- jaringan ZeroTier (minta akses / persetujuan)

    private val nodeRegex = Regex("^[0-9a-f]{10}$")

    /**
     * Android tidak mengizinkan aplikasi membaca data aplikasi lain, dan ZeroTier One tidak menyediakan API untuk itu.
     * Jalan keluarnya: buka ZeroTier One, pemain mengetuk Node ID (tersalin ke clipboard), lalu begitu kembali ke sini
     * aplikasi membaca clipboard dan menawarkan Node ID itu. Clipboard hanya dibaca setelah pemain menekan tombolnya.
     */
    private fun fetchNodeId() {
        if (ZtEngine.available()) {
            // ZeroTier tertanam: Node ID dibuat aplikasi ini sendiri saat jaringan pertama kali dinyalakan.
            val id = ZtStore.nodeId(this)
            if (id.isBlank()) {
                Toast.makeText(this, "Node ID belum dibuat. Ketuk ZEROTIER, tambah jaringan lalu nyalakan; Node ID muncul otomatis.", Toast.LENGTH_LONG).show()
            } else {
                settings.zeroNodeId = id
                Toast.makeText(this, "Node ID: $id", Toast.LENGTH_LONG).show()
                load()
            }
            return
        }
        val launch = packageManager.getLaunchIntentForPackage("com.zerotier.one")
        if (launch == null) {
            Toast.makeText(this, "ZeroTier One belum terpasang", Toast.LENGTH_LONG).show()
            return
        }
        waitingNode = true
        Toast.makeText(this, "Ketuk Node ID di bagian bawah ZeroTier One untuk menyalinnya, lalu kembali ke sini", Toast.LENGTH_LONG).show()
        startActivity(launch)
    }

    private fun clipboardNode(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.trim()?.lowercase()
        return t?.takeIf { nodeRegex.matches(it) }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Clipboard baru boleh dibaca Android 10+ saat jendela punya fokus, jadi dicek di sini (bukan di onResume).
        if (!hasFocus || !waitingNode) return
        waitingNode = false
        val node = clipboardNode()
        if (node == null) {
            Toast.makeText(this, "Node ID belum tersalin. Di ZeroTier One, ketuk Node ID (10 karakter) lalu coba lagi.", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Pakai Node ID ini?")
            .setMessage("Node ID dari ZeroTier One: $node")
            .setPositiveButton("Pakai") { _, _ ->
                settings.zeroNodeId = node
                Toast.makeText(this, "Node ID disimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun bg(work: () -> Unit) = Thread {
        try { work() } catch (e: LobbyApi.Rejected) { toast(e.message ?: "Ditolak") }
        catch (e: Exception) { toast("Gagal: ${e.message ?: e.javaClass.simpleName}") }
    }.start()

    private fun statusText(s: String) = when (s) {
        "pending" -> "Permintaan terkirim. Menunggu persetujuan pemilik."
        "approved" -> "Disetujui! Nyalakan jaringan ini di ZeroTier One, lalu pakai IP ZeroTier Anda."
        "denied" -> "Permintaan ditolak pemilik."
        else -> "Belum ada permintaan dari Node ID ini."
    }

    private fun showNetwork(n: LobbyApi.Network) {
        val node = ZtStore.nodeId(this).ifBlank { settings.zeroNodeId }
        val msg = "Network ID: ${n.id}\n" +
            (if (node.isBlank()) "\nNode ID Anda belum diisi. " +
                (if (ZtEngine.available()) "Tekan Minta akses: ZeroTier di aplikasi ini akan dinyalakan dan Node ID dibuat otomatis."
                else "Tekan Minta akses untuk mengambilnya dari ZeroTier One (atau isi manual di Atur).")
            else "\nNode ID Anda: $node") +
            "\n\nSetelah pemilik menyetujui, " +
                (if (ZtEngine.available()) "jaringan tersambung otomatis lewat tombol ZeroTier di layar lobby." else "nyalakan toggle jaringan ini di ZeroTier One.")
        AlertDialog.Builder(this).setTitle(n.name).setMessage(msg)
            .setPositiveButton("Minta akses") { _, _ ->
                if (node.isBlank()) {
                    if (ZtEngine.available()) joinEmbedded(n) else fetchNodeId()
                    return@setPositiveButton
                }
                val url = settings.lobbyUrl
                bg { toast(statusText(LobbyApi.requestAccess(url, n.id, node, settings.playerName))) }
            }
            .setNeutralButton("Cek status") { _, _ ->
                if (node.isBlank()) { settingsDialog(); return@setNeutralButton }
                val url = settings.lobbyUrl
                bg { toast(statusText(LobbyApi.accessStatus(url, n.id, node))) }
            }
            .setNegativeButton("Lainnya") { _, _ ->
                AlertDialog.Builder(this).setTitle(n.name)
                    .setItems(arrayOf("Salin Network ID", "Buka ZeroTier One", "Gabung lewat ZeroTier di aplikasi")) { _, i ->
                        if (i == 0) {
                            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                                .setPrimaryClip(ClipData.newPlainText("Network ID", n.id))
                            Toast.makeText(this, "Network ID disalin", Toast.LENGTH_SHORT).show()
                        } else if (i == 2) {
                            joinEmbedded(n)
                        } else {
                            val launch = packageManager.getLaunchIntentForPackage("com.zerotier.one")
                            if (launch != null) startActivity(launch)
                            else Toast.makeText(this, "ZeroTier One belum terpasang", Toast.LENGTH_LONG).show()
                        }
                    }.setNegativeButton("Tutup", null).show()
            }
            .show()
    }

    /** Menambah jaringan ke ZeroTier tertanam dan membuka layarnya (izin VPN diminta di sana). */
    private fun joinEmbedded(n: LobbyApi.Network) {
        if (!ZtEngine.available()) {
            Toast.makeText(this, "Mesin ZeroTier tidak ikut di build ini. Pakai aplikasi ZeroTier One.", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(Intent(this, ZeroTierActivity::class.java)
            .putExtra(ZeroTierActivity.EXTRA_ADD_ID, n.id).putExtra(ZeroTierActivity.EXTRA_ADD_NAME, n.name))
    }

    /** Layar pemilik: daftar permintaan masuk, tap untuk setujui/tolak. Setelah setuju, centang Auth di ZeroTier Central. */
    private fun approvals() {
        val url = settings.lobbyUrl
        val key = settings.adminKey
        if (url.isBlank() || key.isBlank()) { settingsDialog(); return }
        bg {
            val pend = LobbyApi.pending(url, key)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (pend.isEmpty()) { Toast.makeText(this, "Tidak ada permintaan menunggu", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
                val labels = pend.map { "${it.owner.ifBlank { "(tanpa nama)" }} -> ${it.networkName}\nNode ${it.node}" }.toTypedArray()
                AlertDialog.Builder(this).setTitle("Permintaan masuk (${pend.size})")
                    .setItems(labels) { _, i -> decideDialog(pend[i]) }
                    .setNegativeButton("Tutup", null).show()
            }
        }
    }

    private fun decideDialog(p: LobbyApi.Pending) {
        val url = settings.lobbyUrl
        val key = settings.adminKey
        AlertDialog.Builder(this).setTitle("${p.owner.ifBlank { "Pemain" }} -> ${p.networkName}")
            .setMessage("Node ID: ${p.node}\n\nSetelah disetujui, centang Auth untuk node ini di my.zerotier.com agar pemain bisa tersambung.")
            .setPositiveButton("Setujui") { _, _ ->
                bg { LobbyApi.decide(url, key, p.network, p.node, true); toast("Disetujui. Jangan lupa centang Auth di ZeroTier Central.") }
            }
            .setNeutralButton("Tolak") { _, _ ->
                bg { LobbyApi.decide(url, key, p.network, p.node, false); toast("Ditolak") }
            }
            .setNegativeButton("Nanti", null).show()
    }

    /** Penanda jenis jaringan di samping nama server (LAN/internet tidak ditandai). */
    private fun netBadge(net: String) = when (net) {
        "zerotier" -> "  [ZeroTier]"
        "tailscale" -> "  [Tailscale]"
        else -> ""
    }

    /**
     * IP host otomatis + jenis VPN (0 = tebak, 1 = ZeroTier, 2 = Tailscale).
     * Urutan: IP ZeroTier tertanam yang sudah tersambung, lalu IPv4 lokal terbaik saat ini, lalu IP tersimpan (10.x / 100.64-127.x / 192.168.x).
     */
    private fun autoHostIp(): Pair<String, Int> {
        ZtState.firstIp()?.let { return it to 1 }
        val ips = try {
            NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
                .filter { it is Inet4Address && !it.isLoopbackAddress }.mapNotNull { it.hostAddress }
        } catch (_: Exception) { emptyList() }
        val best = ips.firstOrNull { it.startsWith("10.") } ?: ips.firstOrNull { it.startsWith("192.168.") } ?: ips.firstOrNull() ?: ""
        if (best.isEmpty()) return settings.vpnIp to settings.vpnType
        val type = if (Regex("^100\\.(6[4-9]|[7-9]\\d|1[01]\\d|12[0-7])\\.").containsMatchIn(best)) 2 else 0
        return best to type
    }

    private val vpnLabels = arrayOf("VPN: otomatis (tebak dari IP)", "VPN: ZeroTier", "VPN: Tailscale")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
