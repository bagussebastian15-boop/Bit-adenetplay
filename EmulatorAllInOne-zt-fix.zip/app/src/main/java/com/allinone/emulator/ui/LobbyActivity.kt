package com.allinone.emulator.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Game
import com.allinone.emulator.data.LobbyApi
import com.allinone.emulator.data.RomLibrary
import com.allinone.emulator.data.Settings
import com.allinone.emulator.net.ZtEngine
import com.allinone.emulator.net.ZtState
import com.allinone.emulator.net.ZtStore
import java.io.File

/**
 * Menu "Multiplayer Online": daftar server resmi (dari lobby) + server buatan pemain, tombol Gabung.
 * Daftar hanya menunjukkan ALAMAT; permainannya tetap peer-to-peer lewat netplay rollback.
 */
class LobbyActivity : AppCompatActivity() {

    private sealed class Item {
        data class Header(val text: String) : Item()
        data class Row(val room: LobbyApi.Room) : Item()
        data class Net(val net: LobbyApi.Network) : Item()
    }

    private lateinit var settings: Settings
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var items: List<Item> = emptyList()
    private var loading = false
    private lateinit var approvalBtn: Button
    private var waitingNode = false   // true setelah membuka ZeroTier One untuk menyalin Node ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(8), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "Multiplayer Online"; textSize = 18f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(Button(this).apply { text = "Buat server"; setOnClickListener { createServer() } })
        bar.addView(Button(this).apply { text = "Segarkan"; setOnClickListener { load() } })
        bar.addView(Button(this).apply { text = "ZeroTier"; setOnClickListener { startActivity(Intent(this@LobbyActivity, ZeroTierActivity::class.java)) } })
        approvalBtn = Button(this).apply { text = "Persetujuan"; setOnClickListener { approvals() } }
        bar.addView(approvalBtn)
        bar.addView(Button(this).apply { text = "Atur"; setOnClickListener { settingsDialog() } })

        list = ListView(this)
        status = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val body = FrameLayout(this)
        body.addView(list)
        body.addView(status, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)

        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            when (val it = items.getOrNull(pos)) {
                is Item.Row -> showRoom(it.room)
                is Item.Net -> showNetwork(it.net)
                else -> {}
            }
        }
    }

    override fun onResume() {
        super.onResume()
        approvalBtn.visibility = if (settings.adminKey.isBlank()) View.GONE else View.VISIBLE
        if (settings.lobbyUrl.isBlank()) {
            showStatus("Alamat lobby server belum diisi.\nTekan \"Atur\" lalu isi alamatnya.")
        } else load()
    }

    // ---------------------------------------------------------------- daftar server

    private fun load() {
        val url = settings.lobbyUrl
        if (url.isBlank()) { settingsDialog(); return }
        if (loading) return
        loading = true
        showStatus("Memuat daftar server…")
        Thread {
            val res = try { Result.success(LobbyApi.list(url)) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                loading = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                res.onSuccess { showListing(it) }
                res.onFailure {
                    showStatus("Tidak bisa memuat daftar server.\n${it.message ?: it.javaClass.simpleName}\n\nCek alamat lobby (tombol Atur) dan koneksi internet.")
                }
            }
        }.start()
    }

    private fun showListing(l: LobbyApi.Listing) {
        val out = ArrayList<Item>()
        out += Item.Header("Server resmi")
        if (l.official.isEmpty()) out += Item.Header("   (belum ada)") else l.official.forEach { out += Item.Row(it) }
        if (l.networks.isNotEmpty()) {
            out += Item.Header("Jaringan ZeroTier (masuk dengan persetujuan pemilik)")
            l.networks.forEach { out += Item.Net(it) }
        }
        out += Item.Header("Server pemain")
        if (l.rooms.isEmpty()) out += Item.Header("   (belum ada — tekan \"Buat server\")") else l.rooms.forEach { out += Item.Row(it) }
        items = out
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        status.visibility = View.GONE
        list.visibility = View.VISIBLE
    }

    private fun showStatus(msg: String) {
        items = emptyList()
        (list.adapter as BaseAdapter).notifyDataSetChanged()
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (items[position] is Item.Header) 0 else 1
        override fun isEnabled(position: Int) = items[position] !is Item.Header

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return when (val it = items[position]) {
                is Item.Header -> ((convertView as? TextView) ?: TextView(this@LobbyActivity).apply {
                    setTypeface(typeface, Typeface.BOLD)
                    textSize = 14f
                    setPadding(dp(16), dp(10), dp(16), dp(6))
                    setBackgroundColor(0x22888888)
                }).also { v -> v.text = it.text }
                is Item.Net -> {
                    val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                    v.findViewById<TextView>(android.R.id.text1).text = "${it.net.name}  [ZeroTier]"
                    v.findViewById<TextView>(android.R.id.text2).text = "Network ID ${it.net.id} · ketuk untuk minta akses"
                    v
                }
                is Item.Row -> {
                    val v = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                    val r = it.room
                    v.findViewById<TextView>(android.R.id.text1).text =
                        (if (r.official) "★ " else "") + r.name + netBadge(r.net) + (if (!r.online) "  (offline)" else if (r.full) "  (penuh)" else "")
                    val label = consoleOrNull(r.console)?.label ?: r.console
                    v.findViewById<TextView>(android.R.id.text2).text =
                        "${r.title} · $label · ${r.players}/${r.maxPlayers} pemain" +
                            (if (r.owner.isNotBlank()) " · ${r.owner}" else "")
                    v
                }
            }
        }
    }

    // ---------------------------------------------------------------- gabung

    private fun showRoom(r: LobbyApi.Room) {
        val label = consoleOrNull(r.console)?.label ?: r.console
        val msg = buildString {
            append("Game: ${r.title}\nKonsol: $label\nPemain: ${r.players}/${r.maxPlayers}\nAlamat: ${r.host}:${r.port}")
            if (r.owner.isNotBlank()) append("\nDibuat oleh: ${r.owner}")
            if (r.note.isNotBlank()) append("\n\n${r.note}")
            append("\n\nAnda harus punya game yang sama persis (nama file dan ROM sama) di library.")
        }
        val b = AlertDialog.Builder(this).setTitle(r.name).setMessage(msg).setNegativeButton("Batal", null)
        when {
            !r.online -> b.setPositiveButton("Offline", null)
            r.full -> b.setPositiveButton("Penuh", null)
            else -> b.setPositiveButton("Gabung") { _, _ -> join(r) }
        }
        b.show()
    }

    private fun consoleOrNull(name: String): Console? = Console.values().firstOrNull { it.name == name }

    private fun coreExists(c: Console) = File(applicationInfo.nativeLibraryDir, c.core).exists()

    private fun join(r: LobbyApi.Room) {
        val console = consoleOrNull(r.console)
        if (console == null || r.title.isBlank() || r.host.isBlank()) {
            Toast.makeText(this, "Data server ini tidak lengkap atau butuh aplikasi versi lebih baru.", Toast.LENGTH_LONG).show()
            return
        }
        if (!coreExists(console)) {
            Toast.makeText(this, "Core ${console.label} belum ada di APK ini.", Toast.LENGTH_LONG).show()
            return
        }
        // Cocokkan game dengan library pemain: nama sama, konsol sama (semua jenis arcade dianggap satu kelompok; core tetap ikut server)
        val mine = RomLibrary.list(this).firstOrNull {
            it.title.equals(r.title, ignoreCase = true) && (it.console == console || (it.console.isArcade && console.isArcade))
        }
        if (mine == null) {
            AlertDialog.Builder(this)
                .setTitle("Game belum ada di library")
                .setMessage("Server ini memainkan \"${r.title}\" (${console.label}).\n\nImpor ROM yang sama ke library Anda, lalu coba gabung lagi.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        launchEmulator(Game(mine.file, console)) {
            putExtra(EmulatorActivity.EXTRA_NP_MODE, "join")
            putExtra(EmulatorActivity.EXTRA_NP_IP, r.host)
            putExtra(EmulatorActivity.EXTRA_NP_PORT, r.port)
        }
    }

    private fun launchEmulator(g: Game, extras: Intent.() -> Unit) {
        getSharedPreferences("crash", MODE_PRIVATE).edit()
            .putString("lastGame", "${g.file.name} (${g.console.label}) [multiplayer]").apply()
        startActivity(
            Intent(this, EmulatorActivity::class.java)
                .putExtra(EmulatorActivity.EXTRA_ROM, g.file.absolutePath)
                .putExtra(EmulatorActivity.EXTRA_CONSOLE, g.console.name)
                .apply(extras)
        )
    }

    // ---------------------------------------------------------------- buat server

    private fun createServer() {
        if (settings.lobbyUrl.isBlank()) { settingsDialog(); return }
        val games = RomLibrary.list(this)
        if (games.isEmpty()) {
            Toast.makeText(this, "Library masih kosong. Impor ROM dulu di menu awal.", Toast.LENGTH_LONG).show()
            return
        }
        val labels = games.map { "${it.title} (${it.console.label})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih game untuk server Anda")
            .setItems(labels) { _, i -> serverForm(games[i]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun serverForm(g: Game) {
        val name = EditText(this).apply {
            hint = "Nama server"
            setSingleLine(true)
            setText("${settings.playerName} - ${g.title}".take(40))
        }
        val ip = EditText(this).apply {
            hint = "IP VPN/LAN (kosongkan = otomatis)"
            setSingleLine(true)
            setText(ZtState.firstIp() ?: settings.vpnIp)
        }
        val vpnSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@LobbyActivity, android.R.layout.simple_spinner_dropdown_item, vpnLabels)
            setSelection(if (ZtState.firstIp() != null) 1 else settings.vpnType)
        }
        val delays = arrayOf(
            "1 frame (koneksi sangat bagus)", "2 frame (bawaan, Wi-Fi/LAN)", "3 frame (internet stabil)",
            "4 frame (kurang stabil)", "5 frame (VPN, disarankan)", "6 frame (ping tinggi)"
        )
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@LobbyActivity, android.R.layout.simple_spinner_dropdown_item, delays)
            setSelection(1)
        }
        val note = TextView(this).apply {
            textSize = 12f
            text = "Lewat internet: buka port ${NetplayUi.PORT} (TCP + UDP) di router, atau pakai VPN (ZeroTier/Tailscale) lalu isi IP VPN di atas dan pilih jenis VPN-nya agar server diberi tanda di daftar. " +
                "Server hanya tampil di daftar bila port terjangkau."
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(name); addView(ip); addView(vpnSpin); addView(spin); addView(note)
        }
        AlertDialog.Builder(this)
            .setTitle("Buat server: ${g.title}")
            .setView(box)
            .setPositiveButton("Mulai") { _, _ ->
                val room = name.text.toString().trim().ifBlank { g.title }.take(40)
                launchEmulator(g) {
                    putExtra(EmulatorActivity.EXTRA_NP_MODE, "host")
                    putExtra(EmulatorActivity.EXTRA_NP_ROOM, room)
                    putExtra(EmulatorActivity.EXTRA_NP_DELAY, spin.selectedItemPosition + 1)
                    putExtra(EmulatorActivity.EXTRA_NP_PUBLIC_IP, ip.text.toString().trim())
                    putExtra(EmulatorActivity.EXTRA_NP_VPN,
                        when (vpnSpin.selectedItemPosition) { 1 -> "zerotier"; 2 -> "tailscale"; else -> "" })
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------------------------------------------------------------- pengaturan

    private fun settingsDialog() {
        val url = EditText(this).apply {
            hint = "Alamat lobby, mis. http://123.45.67.89:8080"
            setSingleLine(true)
            setText(settings.lobbyUrl)
        }
        val nick = EditText(this).apply {
            hint = "Nama pemain"
            setSingleLine(true)
            setText(settings.playerName)
        }
        val node = EditText(this).apply {
            hint = if (ZtEngine.available()) "Node ID (otomatis dari ZeroTier aplikasi)" else "Node ID ZeroTier One (10 karakter)"
            setSingleLine(true)
            setText(settings.zeroNodeId)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(url); addView(nick); addView(node)
        }
        AlertDialog.Builder(this)
            .setTitle("Pengaturan Multiplayer Online")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                settings.lobbyUrl = url.text.toString()
                settings.playerName = nick.text.toString()
                val n = node.text.toString().trim().lowercase()
                if (n.isEmpty() || nodeRegex.matches(n)) settings.zeroNodeId = n
                else Toast.makeText(this, "Node ID harus 10 karakter heksadesimal (0-9, a-f); tidak disimpan", Toast.LENGTH_LONG).show()
                load()
            }
            .setNeutralButton(if (ZtEngine.available()) "Pakai ZeroTier aplikasi" else "Ambil dari ZeroTier One") { _, _ ->
                settings.lobbyUrl = url.text.toString()
                settings.playerName = nick.text.toString()
                fetchNodeId()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------------------------------------------------------------- jaringan ZeroTier (minta akses / persetujuan)

    private val nodeRegex = Regex("^[0-9a-f]{10}$")

    /**
     * Android tidak mengizinkan aplikasi membaca data aplikasi lain, dan ZeroTier One tidak menyediakan API untuk itu.
     * Jalan keluarnya: buka ZeroTier One, pemain mengetuk Node ID (tersalin ke clipboard), lalu begitu kembali ke sini
     * aplikasi membaca clipboard dan menawarkan Node ID itu. Clipboard hanya dibaca setelah pemain menekan tombolnya.
     */
    private fun fetchNodeId() {
        if (ZtEngine.available()) {
            // ZeroTier tertanam: Node ID dibuat aplikasi ini sendiri saat jaringan pertama kali dinyalakan.
            val id = ZtStore.nodeId(this)
            if (id.isBlank()) {
                Toast.makeText(this, "Node ID belum dibuat. Ketuk ZEROTIER, tambah jaringan lalu nyalakan; Node ID muncul otomatis.", Toast.LENGTH_LONG).show()
            } else {
                settings.zeroNodeId = id
                Toast.makeText(this, "Node ID: $id", Toast.LENGTH_LONG).show()
                load()
            }
            return
        }
        val launch = packageManager.getLaunchIntentForPackage("com.zerotier.one")
        if (launch == null) {
            Toast.makeText(this, "ZeroTier One belum terpasang", Toast.LENGTH_LONG).show()
            return
        }
        waitingNode = true
        Toast.makeText(this, "Ketuk Node ID di bagian bawah ZeroTier One untuk menyalinnya, lalu kembali ke sini", Toast.LENGTH_LONG).show()
        startActivity(launch)
    }

    private fun clipboardNode(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.trim()?.lowercase()
        return t?.takeIf { nodeRegex.matches(it) }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Clipboard baru boleh dibaca Android 10+ saat jendela punya fokus, jadi dicek di sini (bukan di onResume).
        if (!hasFocus || !waitingNode) return
        waitingNode = false
        val node = clipboardNode()
        if (node == null) {
            Toast.makeText(this, "Node ID belum tersalin. Di ZeroTier One, ketuk Node ID (10 karakter) lalu coba lagi.", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Pakai Node ID ini?")
            .setMessage("Node ID dari ZeroTier One: $node")
            .setPositiveButton("Pakai") { _, _ ->
                settings.zeroNodeId = node
                Toast.makeText(this, "Node ID disimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun bg(work: () -> Unit) = Thread {
        try { work() } catch (e: LobbyApi.Rejected) { toast(e.message ?: "Ditolak") }
        catch (e: Exception) { toast("Gagal: ${e.message ?: e.javaClass.simpleName}") }
    }.start()

    private fun statusText(s: String) = when (s) {
        "pending" -> "Permintaan terkirim. Menunggu persetujuan pemilik."
        "approved" -> "Disetujui! Nyalakan jaringan ini di ZeroTier One, lalu pakai IP ZeroTier Anda."
        "denied" -> "Permintaan ditolak pemilik."
        else -> "Belum ada permintaan dari Node ID ini."
    }

    private fun showNetwork(n: LobbyApi.Network) {
        val node = ZtStore.nodeId(this).ifBlank { settings.zeroNodeId }
        val msg = "Network ID: ${n.id}\n" +
            (if (node.isBlank()) "\nNode ID Anda belum diisi. " +
                (if (ZtEngine.available()) "Tekan Minta akses: ZeroTier di aplikasi ini akan dinyalakan dan Node ID dibuat otomatis."
                else "Tekan Minta akses untuk mengambilnya dari ZeroTier One (atau isi manual di Atur).")
            else "\nNode ID Anda: $node") +
            "\n\nSetelah pemilik menyetujui, " +
                (if (ZtEngine.available()) "jaringan tersambung otomatis lewat tombol ZeroTier di layar lobby." else "nyalakan toggle jaringan ini di ZeroTier One.")
        AlertDialog.Builder(this).setTitle(n.name).setMessage(msg)
            .setPositiveButton("Minta akses") { _, _ ->
                if (node.isBlank()) {
                    if (ZtEngine.available()) joinEmbedded(n) else fetchNodeId()
                    return@setPositiveButton
                }
                val url = settings.lobbyUrl
                bg { toast(statusText(LobbyApi.requestAccess(url, n.id, node, settings.playerName))) }
            }
            .setNeutralButton("Cek status") { _, _ ->
                if (node.isBlank()) { settingsDialog(); return@setNeutralButton }
                val url = settings.lobbyUrl
                bg { toast(statusText(LobbyApi.accessStatus(url, n.id, node))) }
            }
            .setNegativeButton("Lainnya") { _, _ ->
                AlertDialog.Builder(this).setTitle(n.name)
                    .setItems(arrayOf("Salin Network ID", "Buka ZeroTier One", "Gabung lewat ZeroTier di aplikasi")) { _, i ->
                        if (i == 0) {
                            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                                .setPrimaryClip(ClipData.newPlainText("Network ID", n.id))
                            Toast.makeText(this, "Network ID disalin", Toast.LENGTH_SHORT).show()
                        } else if (i == 2) {
                            joinEmbedded(n)
                        } else {
                            val launch = packageManager.getLaunchIntentForPackage("com.zerotier.one")
                            if (launch != null) startActivity(launch)
                            else Toast.makeText(this, "ZeroTier One belum terpasang", Toast.LENGTH_LONG).show()
                        }
                    }.setNegativeButton("Tutup", null).show()
            }
            .show()
    }

    /** Menambah jaringan ke ZeroTier tertanam dan membuka layarnya (izin VPN diminta di sana). */
    private fun joinEmbedded(n: LobbyApi.Network) {
        if (!ZtEngine.available()) {
            Toast.makeText(this, "Mesin ZeroTier tidak ikut di build ini. Pakai aplikasi ZeroTier One.", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(Intent(this, ZeroTierActivity::class.java)
            .putExtra(ZeroTierActivity.EXTRA_ADD_ID, n.id).putExtra(ZeroTierActivity.EXTRA_ADD_NAME, n.name))
    }

    /** Layar pemilik: daftar permintaan masuk, tap untuk setujui/tolak. Setelah setuju, centang Auth di ZeroTier Central. */
    private fun approvals() {
        val url = settings.lobbyUrl
        val key = settings.adminKey
        if (url.isBlank() || key.isBlank()) { settingsDialog(); return }
        bg {
            val pend = LobbyApi.pending(url, key)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (pend.isEmpty()) { Toast.makeText(this, "Tidak ada permintaan menunggu", Toast.LENGTH_SHORT).show(); return@runOnUiThread }
                val labels = pend.map { "${it.owner.ifBlank { "(tanpa nama)" }} -> ${it.networkName}\nNode ${it.node}" }.toTypedArray()
                AlertDialog.Builder(this).setTitle("Permintaan masuk (${pend.size})")
                    .setItems(labels) { _, i -> decideDialog(pend[i]) }
                    .setNegativeButton("Tutup", null).show()
            }
        }
    }

    private fun decideDialog(p: LobbyApi.Pending) {
        val url = settings.lobbyUrl
        val key = settings.adminKey
        AlertDialog.Builder(this).setTitle("${p.owner.ifBlank { "Pemain" }} -> ${p.networkName}")
            .setMessage("Node ID: ${p.node}\n\nSetelah disetujui, centang Auth untuk node ini di my.zerotier.com agar pemain bisa tersambung.")
            .setPositiveButton("Setujui") { _, _ ->
                bg { LobbyApi.decide(url, key, p.network, p.node, true); toast("Disetujui. Jangan lupa centang Auth di ZeroTier Central.") }
            }
            .setNeutralButton("Tolak") { _, _ ->
                bg { LobbyApi.decide(url, key, p.network, p.node, false); toast("Ditolak") }
            }
            .setNegativeButton("Nanti", null).show()
    }

    /** Penanda jenis jaringan di samping nama server (LAN/internet tidak ditandai). */
    private fun netBadge(net: String) = when (net) {
        "zerotier" -> "  [ZeroTier]"
        "tailscale" -> "  [Tailscale]"
        else -> ""
    }

    private val vpnLabels = arrayOf("VPN: otomatis (tebak dari IP)", "VPN: ZeroTier", "VPN: Tailscale")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
