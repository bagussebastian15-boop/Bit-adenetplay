package com.allinone.emulator.net

import java.util.concurrent.ConcurrentHashMap

/** Status ZeroTier tertanam yang dibaca layar (diisi ZeroTierVpnService). Satu proses, jadi cukup objek tunggal. */
object ZtState {
    data class Net(val name: String, val status: String, val ip: String)

    @Volatile var running = false
    @Volatile var online = false
    @Volatile var nodeId = ""
    @Volatile var error = ""
    /** Jumlah frame Ethernet yang pernah masuk dari jaringan ZeroTier sejak mesin menyala (untuk diagnosis). */
    @Volatile var framesIn = 0L
    /** Kunci = Network ID (16 heksadesimal huruf kecil). */
    val nets = ConcurrentHashMap<String, Net>()

    /** IPv4 ZeroTier pertama yang sudah tersambung (untuk diisi otomatis di form Buat server), atau null. */
    fun firstIp(): String? = nets.values.firstOrNull { it.status == "OK" && it.ip.isNotEmpty() }?.ip

    fun reset() {
        running = false; online = false; nets.clear(); framesIn = 0L
    }
}
