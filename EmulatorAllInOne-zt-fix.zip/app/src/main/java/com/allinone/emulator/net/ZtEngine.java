package com.allinone.emulator.net;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Collection;

/**
 * Mesin ZeroTier tertanam: menjalankan node ZeroTier (pembungkus JNI resmi com.zerotier.sdk) tanpa aplikasi ZeroTier One.
 * Tanpa dependensi Android supaya bisa diuji di komputer (tests/run_ztengine_test.sh).
 *
 * SDK dipakai lewat REFLEKSI dan java.lang.reflect.Proxy, bukan lewat import. Alasannya: tanda tangan metode SDK sedikit berbeda
 * antarversi (jumlah argumen init, tipe int/long), dan SDK baru ikut di build bila skrip setup_zerotier_core.sh berhasil.
 * Argumen listener dikenali dari TIPE-nya (String/byte[]/long[]/InetSocketAddress), bukan dari urutan, supaya tahan perbedaan versi.
 * Tanpa SDK, available() = false dan aplikasi jalan normal tanpa VPN tertanam.
 */
public final class ZtEngine {

    /** Mengecualikan soket UDP dari VPN (VpnService.protect). */
    public interface Protector { void protect(DatagramSocket s); }

    public interface Listener {
        /** Konfigurasi jaringan berubah. ip = 0 bila belum ada alamat IPv4; status "REMOVED" bila jaringan dihapus. */
        void onNetwork(long nwid, String name, String status, long mac, int ip, int prefix, int mtu);
        /** Frame Ethernet untuk kita datang dari jaringan. */
        void onFrame(long nwid, long srcMac, long dstMac, int etherType, byte[] frame);
        void onOnline(boolean online);
        void onLog(String msg);
    }

    private static final String SDK = "com.zerotier.sdk.";
    private static final long ARP_GROUP = 0xFFFFFFFFFFFFL;
    /** Hanya untuk uji di komputer (tanpa .so). */
    static boolean skipNativeLoad = Boolean.getBoolean("zt.skipnative");

    private static Boolean avail;
    private static String why = "";

    public static synchronized boolean available() {
        if (avail != null) return avail;
        try {
            if (!skipNativeLoad) System.loadLibrary("ZeroTierOneJNI");
            Class.forName(SDK + "Node");
            avail = true;
        } catch (Throwable t) {
            why = t.getClass().getSimpleName() + ": " + t.getMessage();
            avail = false;
        }
        return avail;
    }

    public static synchronized String unavailableReason() { return why; }

    /** Node ID (10 heksadesimal) dari identity.public bila node pernah dijalankan; kalau belum, "". */
    public static String peekNodeId(File dir) {
        try {
            File f = new File(dir, "identity.public");
            if (!f.isFile() || f.length() > 4096) return "";
            byte[] raw = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int off = 0, n;
                while (off < raw.length && (n = in.read(raw, off, raw.length - off)) > 0) off += n;
            }
            String s = new String(raw, StandardCharsets.UTF_8).trim();
            int c = s.indexOf(':');
            String id = (c > 0 ? s.substring(0, c) : s).toLowerCase();
            return id.matches("[0-9a-f]{10}") ? id : "";
        } catch (Exception e) {
            return "";
        }
    }

    private final File dir;
    private final Protector protector;
    private final Listener listener;
    private final Object bgLock = new Object();
    private Object node;
    private Class<?> nodeClass;
    private DatagramSocket socket;
    /**
     * Semua callback ke aplikasi (jaringan, frame, online) dijalankan di thread ini, BUKAN di thread inti ZeroTier.
     * Callback datang saat inti memegang kunci internalnya (mis. konfigurasi tersimpan dikirim di dalam join()); bila aplikasi
     * memanggil balik node (multicastSubscribe, processVirtualNetworkFrame) dari dalam callback, inti kebuntuan: thread latar belakang
     * berhenti, UDP keluar tetap 0, OFFLINE selamanya. ZeroTier One resmi menghindarinya dengan mem-posting event ke thread lain.
     */
    private volatile java.util.concurrent.ExecutorService cb;
    private Thread recvThread, bgThread;
    private volatile boolean running;
    private long nextBg;
    /** Penghitung untuk diagnosis OFFLINE: paket UDP keluar/masuk lewat soket mesin, galat kirim. keluar>0 tapi masuk=0 berarti jaringan memblokir UDP ke server ZeroTier. */
    public volatile long udpIn, udpOut, sendErr;
    public volatile String lastSendError = "";
    /** true pada percobaan ulang: pakai port acak (bukan port bawaan) supaya soket/NAT lama yang macet tidak ikut terbawa. */
    public volatile boolean freshSocket;
    /** Diagnosis paket masuk terakhir: asal dan hasil processWirePacket (supaya terlihat di layar tanpa logcat). */
    public volatile String lastWire = "";

    public ZtEngine(File dir, Protector protector, Listener listener) {
        this.dir = dir;
        this.protector = protector;
        this.listener = listener;
    }

    private static long now() { return System.currentTimeMillis(); }

    public synchronized void start() throws Exception {
        if (running) return;
        if (!available()) throw new IllegalStateException("Mesin ZeroTier tidak tersedia: " + why);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Tidak bisa membuat " + dir);

        wipePeerCache();                        // mulai bersih seperti pertama kali: cache peers.d basi membuat node macet 1 paket keluar / 1 masuk setelah dimatikan-dihidupkan
        socket = freshSocket ? bindSocket(0) : bindSocket(9994);   // 9994 = port yang dipakai aplikasi ZeroTier One resmi (APK 1.16 dibongkar); bila dipakai, pakai port acak
        if (socket == null) socket = bindSocket(0);
        if (socket == null) throw new SocketException("Tidak bisa membuka soket UDP");

        cb = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "zt-cb");
            t.setDaemon(true);
            return t;
        });
        nodeClass = Class.forName(SDK + "Node");
        try {
            node = nodeClass.getConstructor(long.class).newInstance(now());
        } catch (NoSuchMethodException e) {
            node = nodeClass.getConstructor().newInstance();
        }
        Method init = findMethod(nodeClass, "init", -1);
        if (init == null) throw new NoSuchMethodException("Node.init tidak ditemukan di SDK ini");
        Class<?>[] pt = init.getParameterTypes();
        Object[] args = new Object[pt.length];
        for (int i = 0; i < pt.length; i++) {
            if (!pt[i].isInterface()) throw new IllegalStateException("Argumen init tak dikenal: " + pt[i]);
            // ZeroTier One resmi mengisi PathChecker dengan null (pemeriksaan jalur bawaan inti); proxy kita tidak memberi nilai tambah
            args[i] = pt[i].getSimpleName().equals("PathChecker") ? null : proxy(pt[i]);
        }
        Object rc = unwrap(init, node, args);
        if (rc != null && !resultOk(rc)) throw new IllegalStateException("Node.init gagal: " + rc);

        running = true;
        recvThread = new Thread(this::recvLoop, "zt-udp");
        bgThread = new Thread(this::bgLoop, "zt-bg");
        recvThread.setDaemon(true);
        bgThread.setDaemon(true);
        recvThread.start();
        bgThread.start();
    }

    /** Hapus cache peer (peers.d). Identity, planet, dan networks.d tetap dipertahankan. */
    private void wipePeerCache() {
        File pd = new File(dir, "peers.d");
        File[] fs = pd.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        pd.delete();
    }

    private DatagramSocket bindSocket(int port) {
        DatagramSocket s = null;
        try {
            s = new DatagramSocket(null);
            s.setReuseAddress(true);                  // sama dengan ZeroTier One resmi
            s.setSoTimeout(1000);                     // receive() bangun tiap 1 dtk (resmi juga begitu) supaya soket macet/loop tidak menggantung
            s.bind(new InetSocketAddress(InetAddress.getByAddress(new byte[4]), port));
            protector.protect(s);                     // urutan resmi: bind dulu, baru protect
            return s;
        } catch (IOException e) {
            if (s != null) s.close();
            return null;
        }
    }

    /** Panggil lagi VpnService.protect pada soket mesin (setelah TUN dibuat) supaya paket ZeroTier tidak masuk ke TUN sendiri. */
    public void reprotect() {
        DatagramSocket s = socket;
        if (s != null) try { protector.protect(s); } catch (Throwable ignored) { }
    }

    private void post(Runnable r) {
        java.util.concurrent.ExecutorService e = cb;
        if (e == null) return;
        try {
            e.execute(() -> {
                try { r.run(); } catch (Throwable t) { listener.onLog("callback: " + t); }
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) { }
    }

    public int localPort() { return socket == null ? 0 : socket.getLocalPort(); }

    public synchronized void stop() {
        if (!running && node == null) return;
        running = false;
        if (socket != null) socket.close();
        synchronized (bgLock) { bgLock.notifyAll(); }
        for (Thread t : new Thread[]{recvThread, bgThread}) {
            if (t != null) {
                t.interrupt();
                try { t.join(1500); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            }
        }
        java.util.concurrent.ExecutorService ex = cb;
        cb = null;
        if (ex != null) ex.shutdownNow();
        if (node != null) {
            Method close = findMethod(nodeClass, "close", 0);
            if (close != null) try { close.invoke(node); } catch (Throwable ignored) { }
            node = null;
        }
    }

    // ------------------------------------------------------------------ API untuk aplikasi

    public String nodeId() {
        Object a = call("address");
        return a instanceof Number ? String.format("%010x", ((Number) a).longValue()) : "";
    }

    public void join(long nwid) { call("join", nwid); }

    public void leave(long nwid) { call("leave", nwid); }

    /** Wajib agar ARP untuk IP kita sampai (ZeroTier memetakan ARP IPv4 ke grup multicast broadcast + ADI = IP). */
    public void subscribeArp(long nwid, int ip) { call("multicastSubscribe", nwid, ARP_GROUP, ip & 0xFFFFFFFFL); }

    /**
     * Ringkasan peer untuk diagnosis: jumlah peer, jumlah root, dan tiap peer biasa (anggota jaringan) beserta ping/jalur.
     * Nama metode SDK berbeda antarversi, jadi dicoba beberapa nama; null bila SDK tidak menyediakan peers().
     */
    public String peerSummary() {
        Object r = call("peers");
        java.util.List<Object> ps = new java.util.ArrayList<>();
        if (r instanceof Object[]) ps.addAll(Arrays.asList((Object[]) r));
        else if (r instanceof Collection) ps.addAll((Collection<?>) r);
        else return null;
        int roots = 0;
        StringBuilder members = new StringBuilder();
        int n = 0;
        for (Object p : ps) {
            Object role = getAny(p, "getRole", "role");
            if (role != null && !role.toString().contains("LEAF")) { roots++; continue; }
            n++;
            Object addr = getAny(p, "getAddress", "address");
            Object lat = getAny(p, "getLatency", "latency");
            Object paths = getAny(p, "getPaths", "paths");
            int pc = paths instanceof Object[] ? ((Object[]) paths).length : paths instanceof Collection ? ((Collection<?>) paths).size() : -1;
            if (n <= 6) members.append("\n  - ")
                .append(addr instanceof Number ? String.format("%010x", ((Number) addr).longValue()) : "?")
                .append(" · ").append(pc > 0 ? "jalur langsung" : pc == 0 ? "lewat relay" : "jalur ?")
                .append(lat instanceof Number && ((Number) lat).intValue() >= 0 ? " · " + lat + " ms" : "");
        }
        return roots + " root, " + n + " anggota terlihat" + members;
    }

    private static Object getAny(Object o, String... getters) {
        for (String g : getters) {
            Object v = get(o, g);
            if (v != null) return v;
        }
        return null;
    }

    /** Langganan eksplisit grup siaran (ff:ff:ff:ff:ff:ff, ADI 0) supaya pengumuman server dari host sampai ke kita. */
    public void subscribeBroadcast(long nwid) { call("multicastSubscribe", nwid, ARP_GROUP, 0L); }

    public void sendFrame(long nwid, long srcMac, long dstMac, int etherType, byte[] payload) {
        long[] dl = new long[1];
        call("processVirtualNetworkFrame", now(), nwid, srcMac, dstMac, etherType, 0, payload, dl);
        wake(dl[0]);
    }

    // ------------------------------------------------------------------ thread

    private void recvLoop() {
        byte[] buf = new byte[16384];
        DatagramPacket p = new DatagramPacket(buf, buf.length);
        while (running) {
            try {
                p.setLength(buf.length);
                socket.receive(p);
                udpIn++;
                byte[] d = Arrays.copyOf(buf, p.getLength());
                long[] dl = new long[1];
                Object rc = call("processWirePacket", now(), -1L, new InetSocketAddress(p.getAddress(), p.getPort()), d, dl);
                lastWire = p.getAddress().getHostAddress() + ":" + p.getPort() + " " + d.length + "B -> " + rc;
                wake(dl[0]);
            } catch (java.net.SocketTimeoutException e) {
                // normal: soket punya timeout 1 dtk; ulangi (loop memeriksa running)
            } catch (IOException e) {
                if (!running) return;
                lastSendError = "recv " + e.getClass().getSimpleName() + ": " + e.getMessage();
                try { Thread.sleep(200); } catch (InterruptedException ie) { return; }
            } catch (Throwable t) {
                listener.onLog("recv: " + t);
            }
        }
    }

    private void bgLoop() {
        while (running) {
            long[] dl = new long[1];
            call("processBackgroundTasks", now(), dl);
            synchronized (bgLock) {
                nextBg = dl[0] > 0 ? dl[0] : now() + 100;
                while (running) {
                    long wait = Math.min(nextBg - now(), 100);
                    if (wait <= 0) break;
                    try { bgLock.wait(wait); } catch (InterruptedException e) { return; }
                }
            }
        }
    }

    private void wake(long deadline) {
        synchronized (bgLock) {
            if (deadline > 0) nextBg = deadline;
            bgLock.notifyAll();
        }
    }

    // ------------------------------------------------------------------ refleksi

    private static Method findMethod(Class<?> c, String name, int arity) {
        for (Method m : c.getMethods())
            if (m.getName().equals(name) && (arity < 0 || m.getParameterTypes().length == arity)) return m;
        return null;
    }

    private static Object adapt(Class<?> t, Object v) {
        if (v instanceof Number) {
            Number n = (Number) v;
            if (t == long.class || t == Long.class) return n.longValue();
            if (t == int.class || t == Integer.class) return n.intValue();
            if (t == short.class || t == Short.class) return n.shortValue();
        }
        return v;
    }

    private static Object unwrap(Method m, Object target, Object[] args) throws Exception {
        try {
            return m.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable c = e.getCause();
            throw c instanceof Exception ? (Exception) c : new RuntimeException(c);
        }
    }

    private Object call(String name, Object... args) {
        Object n = node;
        if (n == null) return null;
        Method m = findMethod(nodeClass, name, args.length);
        if (m == null) {
            listener.onLog("SDK tidak punya " + name + "/" + args.length);
            return null;
        }
        Class<?>[] pt = m.getParameterTypes();
        Object[] a = new Object[args.length];
        for (int i = 0; i < a.length; i++) a[i] = adapt(pt[i], args[i]);
        try {
            return unwrap(m, n, a);
        } catch (Throwable t) {
            listener.onLog(name + ": " + t);
            return null;
        }
    }

    private static boolean resultOk(Object rc) {
        String s = rc.toString();
        return s.contains("OK") && !s.contains("ERROR");
    }

    private Object proxy(Class<?> iface) {
        return Proxy.newProxyInstance(iface.getClassLoader(), new Class<?>[]{iface}, new InvocationHandler() {
            @Override
            public Object invoke(Object self, Method m, Object[] a) {
                try {
                    return dispatch(self, m, a == null ? new Object[0] : a);
                } catch (Throwable t) {
                    listener.onLog(m.getName() + ": " + t);
                    return defaultFor(m.getReturnType());
                }
            }
        });
    }

    private static Object defaultFor(Class<?> rt) {
        if (rt == void.class) return null;
        if (rt == boolean.class) return Boolean.FALSE;
        if (rt == int.class) return -1;
        if (rt == long.class) return -1L;
        return null;
    }

    private static Object ret(Method m, long v) {
        Class<?> rt = m.getReturnType();
        if (rt == int.class || rt == Integer.class) return (int) v;
        if (rt == long.class || rt == Long.class) return v;
        if (rt == boolean.class) return v == 0;
        return null;
    }

    @SuppressWarnings("unchecked")
    private static <T> T arg(Object[] a, Class<T> type) {
        for (Object o : a) if (type.isInstance(o)) return (T) o;
        return null;
    }

    private static long[] numbers(Object[] a, int count) {
        long[] out = new long[count];
        int i = 0;
        for (Object o : a) if (o instanceof Number && i < count) out[i++] = ((Number) o).longValue();
        return out;
    }

    private Object dispatch(Object self, Method m, Object[] a) throws Exception {
        switch (m.getName()) {
            case "toString": return "ZtEngineProxy";
            case "hashCode": return System.identityHashCode(self);
            case "equals": return a.length == 1 && self == a[0];

            case "onDataStoreGet": {
                String name = arg(a, String.class);
                byte[] buf = arg(a, byte[].class);
                long[] outSize = arg(a, long[].class);
                long idx = numbers(a, 1)[0];
                return ret(m, dsGet(name, buf, idx, outSize));
            }
            case "onDataStorePut": {
                String name = arg(a, String.class);
                byte[] buf = arg(a, byte[].class);
                Boolean secure = arg(a, Boolean.class);
                return ret(m, dsPut(name, buf, secure != null && secure));
            }
            case "onDelete": return ret(m, dsPut(arg(a, String.class), null, false));

            case "onSendPacketRequested": {
                InetSocketAddress to = arg(a, InetSocketAddress.class);
                byte[] data = arg(a, byte[].class);
                if (to == null || data == null) return ret(m, -1);
                if (!(to.getAddress() instanceof Inet4Address)) return ret(m, 0);   // IPv6 belum dipakai
                try {
                    socket.send(new DatagramPacket(data, data.length, to));
                    udpOut++;
                    return ret(m, 0);
                } catch (IOException e) {
                    sendErr++;
                    lastSendError = e.getClass().getSimpleName() + ": " + e.getMessage();
                    return ret(m, -1);
                }
            }

            case "onVirtualNetworkFrame": {
                long[] n = numbers(a, 5);                       // nwid, srcMac, dstMac, etherType, vlanId
                byte[] frame = arg(a, byte[].class);
                if (frame != null) {
                    final long nw = n[0], sm = n[1], dm = n[2];
                    final int et = (int) n[3];
                    post(() -> listener.onFrame(nw, sm, dm, et, frame));
                }
                return null;
            }

            case "onNetworkConfigurationUpdated": {
                long nwid = numbers(a, 1)[0];
                Object op = null, cfg = null;
                for (Object o : a) {
                    if (o instanceof Number) continue;
                    if (o instanceof Enum) op = o; else cfg = o;
                }
                networkConfig(nwid, op, cfg);
                return ret(m, 0);
            }

            case "onEvent": {
                String ev = a.length > 0 && a[0] != null ? a[0].toString() : "";
                if (ev.contains("OFFLINE")) post(() -> listener.onOnline(false));
                else if (ev.contains("ONLINE")) post(() -> listener.onOnline(true));
                else if (ev.contains("FATAL")) listener.onLog("event: " + ev);
                return null;
            }
            case "onTrace": return null;

            case "onPathCheck": return Boolean.TRUE;
            case "onPathLookup": return null;
            default:
                listener.onLog("callback SDK tak dikenal: " + m.getName());
                return defaultFor(m.getReturnType());
        }
    }

    private void networkConfig(long nwid, Object op, Object cfg) {
        if (op != null && op.toString().contains("DESTROY")) {
            post(() -> listener.onNetwork(nwid, "", "REMOVED", 0, 0, 0, 0));
            return;
        }
        long mac = 0;
        String name = "", status = "";
        int ip = 0, prefix = 0, mtu = 2800;
        if (cfg != null) {
            Object v = get(cfg, "getMac");
            if (v instanceof Number) mac = ((Number) v).longValue();
            v = get(cfg, "getName");
            if (v != null) name = v.toString();
            v = get(cfg, "getStatus");
            if (v != null) status = v.toString().replace("NETWORK_STATUS_", "");
            v = get(cfg, "getMtu");
            if (v instanceof Number) mtu = ((Number) v).intValue();
            // SDK ZeroTier One 1.16 mengembalikan InetSocketAddress[] (ARRAY), versi lama ArrayList. Dua-duanya harus dibaca.
            for (Object o : asList(get(cfg, "getAssignedAddresses"))) {
                if (o instanceof InetSocketAddress && ((InetSocketAddress) o).getAddress() instanceof Inet4Address) {
                    InetSocketAddress sa = (InetSocketAddress) o;      // port = panjang prefix (konvensi SDK)
                    ip = EthBridge.ipToInt(sa.getAddress().getAddress(), 0);
                    prefix = sa.getPort();
                    break;
                }
            }
            if (ip != 0 && (prefix < 1 || prefix > 32)) {                // cadangan: ambil panjang prefix dari rute langsung (tanpa via)
                for (Object r : asList(get(cfg, "getRoutes"))) {
                    Object via = get(r, "getVia");
                    Object tg = get(r, "getTarget");
                    if (tg instanceof InetSocketAddress && ((InetSocketAddress) tg).getAddress() instanceof Inet4Address
                            && (via == null || (via instanceof InetSocketAddress && ((InetSocketAddress) via).getAddress().isAnyLocalAddress()))
                            && ((InetSocketAddress) tg).getPort() >= 1 && ((InetSocketAddress) tg).getPort() <= 32) {
                        prefix = ((InetSocketAddress) tg).getPort();
                        break;
                    }
                }
            }
        }
        final String fName = name, fStatus = status;
        final long fMac = mac;
        final int fIp = ip, fPrefix = prefix, fMtu = mtu;
        post(() -> listener.onNetwork(nwid, fName, fStatus, fMac, fIp, fPrefix, fMtu));
    }

    /** Array maupun Collection jadi List (SDK berbeda versi memakai tipe berbeda); null jadi daftar kosong. */
    private static java.util.List<Object> asList(Object v) {
        if (v instanceof Object[]) return Arrays.asList((Object[]) v);
        if (v instanceof Collection) return new java.util.ArrayList<Object>((Collection<?>) v);
        return java.util.Collections.emptyList();
    }

    private static Object get(Object o, String getter) {
        try {
            return o.getClass().getMethod(getter).invoke(o);
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ penyimpanan data node (identity, peers, networks.d, ...)

    private File file(String name, boolean forWrite) {
        if (name == null || name.isEmpty() || name.contains("..") || name.indexOf('\0') >= 0) return null;
        try {
            File base = dir.getCanonicalFile();
            File f = new File(base, name.startsWith("/") ? name.substring(1) : name).getCanonicalFile();
            if (!f.getPath().startsWith(base.getPath() + File.separator)) return null;
            if (forWrite && f.getParentFile() != null) f.getParentFile().mkdirs();
            return f;
        } catch (IOException e) {
            return null;
        }
    }

    private long dsGet(String name, byte[] buf, long index, long[] outSize) throws IOException {
        File f = file(name, false);
        if (f == null || !f.isFile()) return -1;
        if (outSize != null && outSize.length > 0) outSize[0] = f.length();
        if (buf == null) return 0;
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            r.seek(index);
            int n = r.read(buf, 0, buf.length);
            return n < 0 ? 0 : n;
        }
    }

    private long dsPut(String name, byte[] data, boolean secure) {
        File f = file(name, data != null);
        if (f == null) return -1;
        if (data == null) {
            f.delete();
            return 0;
        }
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(data);
        } catch (IOException e) {
            return -1;
        }
        if (!tmp.renameTo(f)) {
            f.delete();
            if (!tmp.renameTo(f)) return -1;
        }
        if (secure) {                                           // identity.secret: hanya pemilik aplikasi
            f.setReadable(false, false);
            f.setReadable(true, true);
            f.setWritable(false, false);
            f.setWritable(true, true);
        }
        return 0;
    }
}
