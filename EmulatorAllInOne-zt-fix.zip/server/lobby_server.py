#!/usr/bin/env python3
"""
Server lobby Multiplayer Online untuk EmulatorAllInOne.

Hanya DAFTAR alamat; game tetap peer-to-peer (netplay rollback, port 7755 TCP+UDP milik host).
  - "Server resmi"  : dibaca dari official_servers.json (bisa diubah tanpa merilis ulang aplikasi).
  - "Server pemain" : didaftarkan aplikasi saat pemain menekan "Buat server" (hilang otomatis bila tidak ada heartbeat).

Jalankan:  python3 lobby_server.py          (butuh Python 3.8+, tanpa pustaka tambahan)
Variabel lingkungan: PORT=8080  TTL=45  PROBE=1  TRUST_PROXY=0 (isi 1 bila di belakang nginx/Cloudflare)
  ZEROTIER_NETS=10.147.0.0/16,...  daftar jaringan ZeroTier Anda (CIDR, dipisah koma) untuk menandai server "ZeroTier"
  ADMIN_KEY=rahasia                kunci admin untuk menyetujui permintaan masuk jaringan ZeroTier (kosong = fitur persetujuan mati)
  NETWORKS_FILE / REQUESTS_FILE    daftar jaringan ZeroTier milik Anda (networks.json) / berkas penyimpan permintaan
Setiap server diberi field "net": zerotier | tailscale | lan | internet.
"""
import ipaddress
import json
import os
import re
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "8080"))
TTL = int(os.environ.get("TTL", "45"))                 # detik tanpa heartbeat -> server dihapus
PROBE = os.environ.get("PROBE", "1") != "0"            # cek port host benar-benar terbuka dari internet
TRUST_PROXY = os.environ.get("TRUST_PROXY", "0") == "1"
MAX_ROOMS = 200
MAX_PER_IP = 3
RATE_PER_MIN = 30
ADMIN_KEY = os.environ.get("ADMIN_KEY", "")
NETWORKS_FILE = os.environ.get("NETWORKS_FILE", os.path.join(HERE, "networks.json"))
REQUESTS_FILE = os.environ.get("REQUESTS_FILE", os.path.join(HERE, "requests.json"))
MAX_REQUESTS = 500
REQUEST_TTL = 30 * 86400      # permintaan yang tidak diputuskan dihapus setelah 30 hari
HEX16 = re.compile(r"^[0-9a-f]{16}$")
HEX10 = re.compile(r"^[0-9a-f]{10}$")
OFFICIAL_FILE = os.environ.get("OFFICIAL_FILE", os.path.join(HERE, "official_servers.json"))

CONSOLES = {"GBA", "SNES", "GENESIS", "ARCADE_MAME", "ARCADE_FBNEO", "ARCADE_FBA2012",
            "ARCADE_MAME2000", "ARCADE_MAME2003", "ARCADE_MAME2003P"}
CGNAT = ipaddress.ip_network("100.64.0.0/10")          # Tailscale (rentang CGNAT)
# Rentang ZeroTier tidak tetap: tiap jaringan di ZeroTier Central memilih sendiri. Bawaan = rentang yang umum dipakai
# ZeroTier Central; isi ZEROTIER_NETS dengan rentang jaringan Anda yang sebenarnya agar penandaan akurat.
_ZT_DEFAULT = ("10.147.0.0/16,10.144.0.0/16,10.241.0.0/16,10.242.0.0/16,10.243.0.0/16,10.244.0.0/16,"
               "172.22.0.0/16,172.23.0.0/16,172.24.0.0/16,172.25.0.0/16,172.26.0.0/16,172.27.0.0/16,"
               "172.28.0.0/16,172.29.0.0/16,172.30.0.0/16,192.168.191.0/24,192.168.192.0/24,192.168.193.0/24,"
               "192.168.194.0/24,192.168.195.0/24,192.168.196.0/24")


def _nets(text):
    out = []
    for part in text.split(","):
        part = part.strip()
        if part:
            try:
                out.append(ipaddress.ip_network(part, strict=False))
            except ValueError:
                pass
    return out


ZEROTIER_NETS = _nets(os.environ.get("ZEROTIER_NETS") or _ZT_DEFAULT)

lock = threading.Lock()
rooms = {}        # token -> dict
hits = {}         # ip -> [timestamps]
probe_cache = {}  # (host, port) -> (time, online)


def path_only(p):
    return p.split("?")[0]


def clean(v, n):
    return re.sub(r"[\x00-\x1f\x7f]", "", str(v or "")).strip()[:n]


def v4(addr):
    """Kembalikan IPv4Address (menerima ::ffff:a.b.c.d) atau None."""
    try:
        a = ipaddress.ip_address(addr)
    except ValueError:
        return None
    if isinstance(a, ipaddress.IPv6Address) and a.ipv4_mapped:
        a = a.ipv4_mapped
    return a if isinstance(a, ipaddress.IPv4Address) else None


def is_lan_or_vpn(a):
    return a.is_private or a in CGNAT


def net_kind(a, hint=""):
    """Jenis jaringan alamat host: zerotier | tailscale | lan | internet.
    hint ("zerotier"/"tailscale") = pilihan eksplisit pemain; hanya dipakai untuk alamat non-publik."""
    if a is None:
        return "internet"
    if a.is_global:
        return "internet"
    if hint in ("zerotier", "tailscale"):
        return hint
    if any(a in n for n in ZEROTIER_NETS):
        return "zerotier"
    if a in CGNAT:
        return "tailscale"
    return "lan"


def tcp_open(host, port, timeout=3.0):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def official_list():
    try:
        with open(OFFICIAL_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return []
    out = []
    for i, e in enumerate(data if isinstance(data, list) else []):
        if not isinstance(e, dict) or e.get("console") not in CONSOLES:
            continue
        host, port = clean(e.get("host"), 100), int(e.get("port", 7755))
        hint = "zerotier" if e.get("zerotier") is True else clean(e.get("net"), 12).lower()
        out.append({
            "id": "official-%d" % i, "name": clean(e.get("name"), 40) or "Server resmi",
            "host": host, "port": port, "title": clean(e.get("title"), 80), "console": e["console"],
            "players": int(e.get("players", 0)), "max": 2, "note": clean(e.get("note"), 200),
            "online": official_online(host, port), "net": official_net(host, hint),
        })
    return out


def official_net(host, hint):
    """Jenis jaringan entri resmi: dari penanda di JSON (zerotier/tailscale/lan) atau dari alamatnya."""
    if hint in ("zerotier", "tailscale", "lan", "internet"):
        return hint
    a = v4(host)
    if a is None:
        try:
            a = v4(socket.getaddrinfo(host, None, socket.AF_INET, socket.SOCK_STREAM)[0][4][0])
        except OSError:
            return "internet"
    return net_kind(a)


def official_online(host, port):
    """Cek TCP ke server resmi (di-cache 30 dtk). Alamat LAN/VPN tidak bisa dicek dari sini -> dianggap online."""
    if not PROBE:
        return True
    now = time.time()
    hit = probe_cache.get((host, port))
    if hit and now - hit[0] < 30:
        return hit[1]
    try:
        ip = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)[0][4][0]
        a = v4(ip)
        ok = True if (a is None or not a.is_global) else tcp_open(ip, port, 1.5)
    except OSError:
        ok = False
    probe_cache[(host, port)] = (now, ok)
    return ok


def networks_list():
    """Jaringan ZeroTier milik pemilik lobby (networks.json): [{id, name}]."""
    try:
        with open(NETWORKS_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return []
    out = []
    for e in data if isinstance(data, list) else []:
        if isinstance(e, dict):
            nid = clean(e.get("id"), 16).lower()
            if HEX16.match(nid):
                out.append({"id": nid, "name": clean(e.get("name"), 40) or nid})
    return out


def load_requests():
    try:
        with open(REQUESTS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_requests(reqs):
    tmp = REQUESTS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(reqs, f, ensure_ascii=False)
    os.replace(tmp, REQUESTS_FILE)


def purge():
    now = time.time()
    for t in [t for t, r in rooms.items() if now - r["ts"] > TTL]:
        del rooms[t]


def public(r):
    return {k: r[k] for k in ("id", "name", "host", "port", "title", "console", "players", "max", "owner", "net")}


class Err(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code, self.msg = code, msg


class H(BaseHTTPRequestHandler):
    server_version = "Lobby/1.0"

    def log_message(self, fmt, *a):
        pass

    def ip(self):
        if TRUST_PROXY and self.headers.get("X-Forwarded-For"):
            return self.headers["X-Forwarded-For"].split(",")[0].strip()
        return self.client_address[0]

    def send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 4096:
            raise Err(400, "Permintaan terlalu besar")
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            raise Err(400, "JSON tidak valid")
        if not isinstance(d, dict):
            raise Err(400, "JSON tidak valid")
        return d

    def rate(self):
        ip, now = self.ip(), time.time()
        with lock:
            h = [t for t in hits.get(ip, []) if now - t < 60]
            h.append(now)
            hits[ip] = h
            if len(hits) > 5000:
                hits.clear()
        if len(h) > RATE_PER_MIN:
            raise Err(429, "Terlalu banyak permintaan, coba sebentar lagi")

    def do_GET(self):
        try:
            if self.path.split("?")[0] == "/api/rooms":
                with lock:
                    purge()
                    mine = sorted(rooms.values(), key=lambda r: -r["created"])
                    pub = [public(r) for r in mine]
                self.send(200, {"official": official_list(), "rooms": pub, "networks": networks_list()})
            elif path_only(self.path) == "/api/admin/requests":
                self.rate()
                self.admin_check()
                with lock:
                    reqs = load_requests()
                    pend = [{x: y for x, y in v.items() if x != "from"} for v in reqs.values() if v.get("status") == "pending"]
                names = {n["id"]: n["name"] for n in networks_list()}
                for p in pend:
                    p["network_name"] = names.get(p["network"], p["network"])
                pend.sort(key=lambda p: p["ts"])
                self.send(200, {"pending": pend})
            elif self.path == "/":
                self.send(200, {"ok": True, "service": "emulator-lobby"})
            else:
                raise Err(404, "Tidak ditemukan")
        except Err as e:
            self.send(e.code, {"error": e.msg})

    def do_POST(self):
        try:
            self.rate()
            path = self.path.split("?")[0]
            d = self.body()
            if path == "/api/rooms":
                self.send(200, self.register(d))
            elif path == "/api/rooms/heartbeat":
                with lock:
                    r = rooms.get(clean(d.get("token"), 64))
                    if not r:
                        raise Err(404, "Server sudah tidak terdaftar")
                    r["ts"] = time.time()
                    r["players"] = 2 if int(d.get("players", 1)) >= 2 else 1
                self.send(200, {"ok": True})
            elif path == "/api/networks/request":
                self.send(200, self.net_request(d))
            elif path == "/api/networks/status":
                nid, node = self.net_ids(d)
                with lock:
                    r = load_requests().get(nid + ":" + node)
                self.send(200, {"status": r["status"] if r else "none"})
            elif path == "/api/admin/decide":
                self.admin_check()
                nid, node = self.net_ids(d)
                approve = d.get("approve") is True
                with lock:
                    reqs = load_requests()
                    r = reqs.get(nid + ":" + node)
                    if not r:
                        raise Err(404, "Permintaan tidak ditemukan")
                    r["status"] = "approved" if approve else "denied"
                    save_requests(reqs)
                self.send(200, {"ok": True, "status": r["status"]})
            elif path == "/api/rooms/close":
                with lock:
                    rooms.pop(clean(d.get("token"), 64), None)
                self.send(200, {"ok": True})
            else:
                raise Err(404, "Tidak ditemukan")
        except Err as e:
            self.send(e.code, {"error": e.msg})
        except (ValueError, TypeError):
            self.send(400, {"error": "Data tidak valid"})

    def admin_check(self):
        key = self.headers.get("X-Admin-Key", "")
        if not ADMIN_KEY:
            raise Err(403, "Fitur persetujuan belum aktif di lobby (ADMIN_KEY belum diisi)")
        if not secrets.compare_digest(key.encode(), ADMIN_KEY.encode()):
            raise Err(403, "Kunci admin salah")

    def net_ids(self, d):
        nid, node = clean(d.get("network"), 16).lower(), clean(d.get("node"), 10).lower()
        if nid not in {n["id"] for n in networks_list()}:
            raise Err(400, "Jaringan tidak dikenal")
        if not HEX10.match(node):
            raise Err(400, "Node ID harus 10 karakter heksadesimal (0-9, a-f)")
        return nid, node

    def net_request(self, d):
        nid, node = self.net_ids(d)
        now = time.time()
        with lock:
            reqs = load_requests()
            for k in [k for k, v in reqs.items() if now - v.get("ts", 0) > REQUEST_TTL]:
                del reqs[k]
            cur = reqs.get(nid + ":" + node)
            if cur:
                return {"ok": True, "status": cur["status"]}
            if len(reqs) >= MAX_REQUESTS:
                raise Err(429, "Daftar permintaan penuh, coba lagi nanti")
            if sum(1 for v in reqs.values() if v.get("from") == self.ip() and v["status"] == "pending") >= 5:
                raise Err(429, "Terlalu banyak permintaan menunggu dari alamat Anda")
            reqs[nid + ":" + node] = {"network": nid, "node": node, "owner": clean(d.get("owner"), 24),
                                      "status": "pending", "ts": now, "from": self.ip()}
            save_requests(reqs)
        return {"ok": True, "status": "pending"}

    def register(self, d):
        console = clean(d.get("console"), 30)
        title = clean(d.get("title"), 80)
        if console not in CONSOLES or not title:
            raise Err(400, "Game atau konsol tidak valid")
        port = int(d.get("port", 7755))
        if not 1024 <= port <= 65535:
            raise Err(400, "Port harus 1024-65535")
        src = v4(self.ip())
        manual = clean(d.get("ip"), 45)
        vpn = clean(d.get("vpn"), 12).lower()
        if vpn not in ("zerotier", "tailscale"):
            vpn = ""
        if manual:
            a = v4(manual)
            if a is None or not is_lan_or_vpn(a):
                raise Err(400, "IP manual hanya boleh alamat LAN/VPN (mis. 192.168.x.x, 10.x.x.x, 100.64-127.x.x)")
            host = str(a)
            kind = net_kind(a, vpn)
        else:
            if src is None:
                raise Err(400, "Server hanya mendukung IPv4")
            if src.is_loopback:
                raise Err(400, "Alamat sumber tidak valid (bila lobby di belakang proxy, jalankan dengan TRUST_PROXY=1)")
            host = str(src)
            kind = net_kind(src)
            # Alamat publik: pastikan port benar-benar terbuka dari internet, supaya daftar tidak berisi server mati
            if PROBE and src.is_global and not tcp_open(host, port):
                raise Err(400, "Port %d (TCP+UDP) di %s tidak terjangkau dari internet. Buka port di router atau pakai VPN." % (port, host))
        owner_ip = self.ip()
        with lock:
            purge()
            if len(rooms) >= MAX_ROOMS:
                raise Err(429, "Daftar server penuh")
            if sum(1 for r in rooms.values() if r["creator"] == owner_ip) >= MAX_PER_IP:
                raise Err(429, "Terlalu banyak server dari alamat Anda")
            token = secrets.token_urlsafe(18)
            now = time.time()
            rooms[token] = {
                "id": secrets.token_hex(4), "name": clean(d.get("name"), 40) or title, "host": host, "port": port,
                "title": title, "console": console, "players": 1, "max": 2, "owner": clean(d.get("owner"), 24), "net": kind,
                "ts": now, "created": now, "creator": owner_ip,
            }
        return {"token": token, "id": rooms[token]["id"]}


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    print("Lobby berjalan di port %d (TTL %ds, probe=%s)" % (PORT, TTL, PROBE))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
