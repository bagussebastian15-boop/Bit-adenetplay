#!/usr/bin/env bash
# Mengunduh core libretro (build Android) dari buildbot resmi libretro
# ke app/src/main/jniLibs/<abi>/lib<core>_libretro_android.so
# Server libretro kadang memutus koneksi ("Connection reset by peer"), jadi tiap file dicoba ulang beberapa kali.
# Opsional: ABIS="arm64-v8a armeabi-v7a" bash scripts/fetch_cores.sh  (hanya ABI tertentu, lebih cepat)
# Core nightly (mis. fbneo) SELALU diunduh ulang agar memakai build terbaru, walau file lama sudah ada.
# Ubah daftarnya lewat env: REFRESH="fbneo mame2010" bash scripts/fetch_cores.sh  (kosongkan: REFRESH=" " untuk tidak menimpa apa pun)
set -euo pipefail
REFRESH="${REFRESH-fbneo}"

BASE="https://buildbot.libretro.com/nightly/android/latest"
CORES=(mgba snes9x genesis_plus_gx mame2010 fbneo)
# Core arcade tambahan (pilihan tekan lama). Bila tidak tersedia di buildbot untuk ABI tertentu, dilewati tanpa menggagalkan build.
OPTIONAL=(fbalpha2012 mame2000 mame2003 mame2003_plus)
if [ -n "${ABIS:-}" ]; then read -r -a ABI_LIST <<< "$ABIS"; else ABI_LIST=(armeabi-v7a arm64-v8a x86 x86_64); fi
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/jniLibs"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

download() {  # download <url> <output>
  local url="$1" out="$2" max="${3:-8}" try
  for try in $(seq 1 "$max"); do
    if curl -fsSL --http1.1 --connect-timeout 20 --max-time 180 \
         -A "Mozilla/5.0 (X11; Linux x86_64) fetch_cores" "$url" -o "$out"; then
      return 0
    fi
    echo "   gagal (percobaan $try/$max), ulangi dalam $((try * 5)) detik..." >&2
    sleep $((try * 5))
  done
  return 1
}

for abi in "${ABI_LIST[@]}"; do
  mkdir -p "$DEST/$abi"
  for core in "${CORES[@]}" "${OPTIONAL[@]}"; do
    opt=0; [[ " ${OPTIONAL[*]} " == *" $core "* ]] && opt=1
    target="$DEST/$abi/lib${core}_libretro_android.so"
    if [ -s "$target" ] && [[ " $REFRESH " != *" $core "* ]]; then echo "-> sudah ada: $abi/$core"; continue; fi
    url="$BASE/$abi/${core}_libretro_android.so.zip"
    echo "-> $url"
    if ! download "$url" "$TMP/$core.zip" "$([ "$opt" = 1 ] && echo 2 || echo 8)"; then
      [ "$opt" = 1 ] && { echo "   (opsional) $core tidak tersedia untuk $abi, dilewati" >&2; continue; }
      echo "Gagal mengunduh $url" >&2; exit 1
    fi
    rm -rf "$TMP/x" && mkdir -p "$TMP/x"
    unzip -oq "$TMP/$core.zip" -d "$TMP/x"
    mv -f "$TMP/x/${core}_libretro_android.so" "$target"
    sleep 1
  done
done
echo "Selesai: core tersimpan di $DEST"
