#!/usr/bin/env python3
"""Uji server lobby: penandaan jaringan (ZeroTier/Tailscale/LAN/internet) + alur daftar/heartbeat/tutup lewat HTTP."""
import ipaddress
import json
import os
import sys
import threading
import urllib.request
import urllib.error

os.environ["PROBE"] = "0"
os.environ["ZEROTIER_NETS"] = "10.147.17.0/24,192.168.191.0/24"
os.environ["OFFICIAL_FILE"] = os.path.join(os.path.dirname(__file__), "_official_test.json")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "server"))

with open(os.environ["OFFICIAL_FILE"], "w") as f:
    json.dump([
        {"name": "ZT resmi", "host": "10.147.17.5", "port": 7755, "title": "Game", "console": "SNES"},
        {"name": "Tanda manual", "host": "172.16.0.9", "port": 7755, "title": "Game", "console": "GBA", "zerotier": True},
        {"name": "Tailscale", "host": "100.100.1.1", "port": 7755, "title": "Game", "console": "GENESIS"},
    ], f)

import lobby_server as L  # noqa: E402

A = ipaddress.ip_address
fails = 0


def check(name, got, want):
    global fails
    ok = got == want
    fails += not ok
    print(("ok   " if ok else "GAGAL"), name, "" if ok else "-> %r (harusnya %r)" % (got, want))


check("zerotier by range", L.net_kind(A("10.147.17.8")), "zerotier")
check("zerotier 192.168.191", L.net_kind(A("192.168.191.4")), "zerotier")
check("tailscale", L.net_kind(A("100.101.5.5")), "tailscale")
check("lan", L.net_kind(A("192.168.1.20")), "lan")
check("internet", L.net_kind(A("8.8.8.8")), "internet")
check("hint zerotier di luar rentang", L.net_kind(A("172.16.0.9"), "zerotier"), "zerotier")
check("hint diabaikan utk IP publik", L.net_kind(A("8.8.8.8"), "zerotier"), "internet")

srv = L.ThreadingHTTPServer(("127.0.0.1", 0), L.H)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
base = "http://127.0.0.1:%d" % port


def call(method, path, body=None):
    req = urllib.request.Request(base + path, method=method,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


st, r = call("POST", "/api/rooms", {"console": "SNES", "title": "Mario", "ip": "10.147.17.9", "owner": "A"})
check("daftar ZeroTier ok", st, 200)
tok = r["token"]
st, r = call("POST", "/api/rooms", {"console": "SNES", "title": "Mario2", "ip": "172.16.0.9", "vpn": "zerotier"})
check("daftar dengan hint ok", st, 200)
st, r = call("POST", "/api/rooms", {"console": "SNES", "title": "X", "ip": "8.8.8.8"})
check("IP publik manual ditolak", st, 400)

st, r = call("GET", "/api/rooms")
nets = sorted(x["net"] for x in r["rooms"])
check("rooms net", nets, ["zerotier", "zerotier"])
check("official net", [x["net"] for x in r["official"]], ["zerotier", "zerotier", "tailscale"])

st, _ = call("POST", "/api/rooms/heartbeat", {"token": tok, "players": 2})
check("heartbeat", st, 200)
st, _ = call("POST", "/api/rooms/close", {"token": tok})
check("tutup", st, 200)
st, r = call("GET", "/api/rooms")
check("sisa 1 room", len(r["rooms"]), 1)

os.remove(os.environ["OFFICIAL_FILE"])
print("SEMUA LULUS" if not fails else "%d GAGAL" % fails)
sys.exit(1 if fails else 0)
